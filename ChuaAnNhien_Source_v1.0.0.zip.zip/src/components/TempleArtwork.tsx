import type { CSSProperties } from 'react';

type Props = {
  mini?: boolean;
  gateOpening?: boolean;
  incenseSticks?: 0 | 1 | 3;
  smoke?: boolean;
  natureMotion?: boolean;
  onGate?: () => void;
  onBell?: () => void;
  onWoodblock?: () => void;
  bellRinging?: boolean;
  woodblockHit?: boolean;
  incenseLit?: boolean;
  assembling?: boolean;
  folding?: boolean;
  onIncense?: () => void;
  onMeditation?: () => void;
};

export function TempleArtwork({ mini = false, gateOpening, incenseSticks = 0, smoke = true,
  natureMotion = true, onGate, onBell, onWoodblock, bellRinging, woodblockHit, incenseLit,
  assembling, folding, onIncense, onMeditation }: Props) {
  const cls = ['temple-artwork', mini ? 'is-mini' : 'is-full', natureMotion ? '' : 'motion-off', assembling ? 'is-assembling' : '', folding ? 'is-folding' : ''].join(' ');
  return (
    <svg className={cls} viewBox={mini ? '0 0 520 380' : '0 0 960 650'} role="img" aria-label={mini ? 'Cổng Chùa An Nhiên trong buổi chiều ấm áp' : 'Sân Chùa An Nhiên thanh tịnh'}>
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#ffbd69"/><stop offset=".48" stopColor="#f47d54"/><stop offset="1" stopColor="#6f4555"/></linearGradient>
        <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#819157"/><stop offset="1" stopColor="#304b38"/></linearGradient>
        <linearGradient id="roof" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#7b271d"/><stop offset=".55" stopColor="#b84a2d"/><stop offset="1" stopColor="#4b211b"/></linearGradient>
        <linearGradient id="wood" x1="0" y1="0" x2="1" y2="0"><stop stopColor="#552818"/><stop offset=".45" stopColor="#a85b31"/><stop offset="1" stopColor="#432017"/></linearGradient>
        <radialGradient id="lantern"><stop stopColor="#fff4b0"/><stop offset=".32" stopColor="#ffbd46"/><stop offset="1" stopColor="#dc3b22"/></radialGradient>
        <radialGradient id="sun"><stop stopColor="#fff7c4"/><stop offset=".55" stopColor="#ffd37a" stopOpacity=".8"/><stop offset="1" stopColor="#ffcb70" stopOpacity="0"/></radialGradient>
        <filter id="softGlow"><feGaussianBlur stdDeviation="7"/></filter>
        <filter id="shadow"><feDropShadow dx="0" dy="8" stdDeviation="7" floodOpacity=".32"/></filter>
      </defs>
      <rect width="100%" height="100%" fill="url(#sky)"/>
      <circle className="sun-glow" cx={mini ? 405 : 760} cy={mini ? 75 : 105} r={mini ? 92 : 135} fill="url(#sun)"/>
      <g className="cloud cloud-one" fill="#fff4db" opacity=".38"><ellipse cx={mini ? 100 : 180} cy={mini ? 65 : 112} rx="58" ry="18"/><ellipse cx={mini ? 142 : 230} cy={mini ? 57 : 101} rx="48" ry="23"/></g>
      <g className="cloud cloud-two" fill="#fff0da" opacity=".24"><ellipse cx={mini ? 360 : 680} cy={mini ? 118 : 155} rx="54" ry="16"/><ellipse cx={mini ? 395 : 730} cy={mini ? 108 : 147} rx="40" ry="21"/></g>
      <path d={mini ? 'M0 205 Q105 145 210 205 Q350 125 520 205V380H0Z' : 'M0 325Q155 220 320 315Q490 170 660 320Q800 215 960 315V650H0Z'} fill="#4a5d46" opacity=".78"/>
      <path d={mini ? 'M0 250 Q125 195 245 242 Q390 180 520 245V380H0Z' : 'M0 390Q190 315 360 380Q620 270 960 390V650H0Z'} fill="url(#ground)"/>

      {mini ? <MiniGate gateOpening={gateOpening} onGate={onGate} /> : <FullTemple />}
      {!mini && <>
        <BodhiTree />
        <Bell ringing={bellRinging} onClick={onBell}/>
        <Woodblock hit={woodblockHit} onClick={onWoodblock}/>
        <Incense sticks={incenseSticks} smoke={smoke} lit={incenseLit} onClick={onIncense}/>
        <MeditationMat onClick={onMeditation}/>
      </>}
      <g className="birds" fill="none" stroke="#493d3e" strokeWidth="3" strokeLinecap="round"><path d={mini ? 'M345 54q8-8 16 0q8-8 16 0' : 'M705 74q9-9 18 0q9-9 18 0'}/><path d={mini ? 'M390 43q6-6 12 0q6-6 12 0' : 'M758 58q7-7 14 0q7-7 14 0'}/></g>
    </svg>
  );
}

function MiniGate({ gateOpening, onGate }: { gateOpening?: boolean; onGate?: () => void }) {
  return <g className={`mini-gate ${gateOpening ? 'opening' : ''}`} role="button" tabIndex={0} onClick={onGate} onKeyDown={(e) => e.key === 'Enter' && onGate?.()} aria-label="Mở cổng chùa">
    <ellipse cx="260" cy="340" rx="148" ry="24" fill="#182d28" opacity=".35"/>
    <g filter="url(#shadow)"><path d="M94 167Q260 70 426 167L401 195H119Z" fill="url(#roof)"/><path d="M78 165Q260 92 442 165L420 176Q260 129 100 176Z" fill="#d99a4b"/>
    <path d="M130 187H390V318H130Z" fill="#8d4b2b"/><rect x="151" y="194" width="218" height="124" rx="4" fill="#39231e"/>
    <rect x="108" y="180" width="36" height="151" rx="7" fill="url(#wood)"/><rect x="376" y="180" width="36" height="151" rx="7" fill="url(#wood)"/>
    <rect x="188" y="185" width="144" height="42" rx="6" fill="#f0c16d"/><text x="260" y="213" fill="#62281e" fontSize="22" fontWeight="700" textAnchor="middle">AN NHIÊN</text></g>
    <g className="gate-doors"><path className="door-left" d="M154 228H260V318H154Z" fill="#683322" stroke="#c58545" strokeWidth="4"/><path className="door-right" d="M260 228H366V318H260Z" fill="#683322" stroke="#c58545" strokeWidth="4"/>
      {[176,205,234,286,315,344].map((x) => <circle key={x} cx={x} cy="270" r="4" fill="#e3a94b"/>)}
    </g>
    <Lantern x={126} y={222}/><Lantern x={394} y={222}/>
    <path d="M196 339Q260 300 324 339" fill="#bdb190"/><path d="M220 352Q260 328 300 352" fill="#d7c9a3"/>
  </g>;
}

function FullTemple() {
  return <g className="main-hall" filter="url(#shadow)">
    <ellipse cx="480" cy="556" rx="330" ry="46" fill="#1d342b" opacity=".26"/>
    <path d="M150 292Q480 95 810 292L770 330H190Z" fill="url(#roof)"/><path d="M123 287Q480 145 837 287L803 303Q480 215 157 303Z" fill="#dca24f"/>
    <path d="M230 320H730V510H230Z" fill="#9b5634"/><rect x="272" y="328" width="416" height="182" fill="#3b251f"/>
    {[238,310,650,722].map((x) => <rect key={x} x={x} y="316" width="34" height="208" rx="8" fill="url(#wood)"/>)}
    <rect x="390" y="254" width="180" height="54" rx="8" fill="#efc675"/><text x="480" y="289" fill="#692c20" fontSize="28" fontWeight="700" textAnchor="middle">CHÙA AN NHIÊN</text>
    <g className="hall-doors" fill="#6a3424" stroke="#c88a49" strokeWidth="5"><rect x="329" y="350" width="151" height="160"/><rect x="480" y="350" width="151" height="160"/></g>
    <path d="M300 526H660L710 570H250Z" fill="#b9a985"/><path d="M335 510H625L654 536H306Z" fill="#d4c29b"/>
    <Lantern x={255} y={360}/><Lantern x={705} y={360}/>
  </g>;
}

function Lantern({ x, y }: { x: number; y: number }) {
  return <g className="lantern" transform={`translate(${x} ${y})`}><ellipse r="30" fill="#ff9f36" opacity=".28" filter="url(#softGlow)"/><path d="M-10-23H10L16-12L13 14L6 24H-6L-13 14L-16-12Z" fill="url(#lantern)"/><path d="M0 24V34" stroke="#68271d" strokeWidth="3"/></g>;
}

function BodhiTree() { return <g className="bodhi-tree"><path d="M840 465Q835 310 884 240Q854 340 875 474" fill="none" stroke="#60402a" strokeWidth="30" strokeLinecap="round"/><g fill="#557846"><circle cx="848" cy="255" r="68"/><circle cx="895" cy="270" r="73"/><circle cx="866" cy="210" r="65"/><circle cx="927" cy="225" r="52"/></g><g className="tree-leaves" fill="#9bb35b"><circle cx="824" cy="220" r="18"/><circle cx="908" cy="183" r="22"/><circle cx="948" cy="242" r="17"/><circle cx="866" cy="274" r="20"/></g></g>; }

function Bell({ ringing, onClick }: { ringing?: boolean; onClick?: () => void }) {
  return <g className={`bell-object interactive ${ringing ? 'ringing' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && onClick?.()} aria-label="Rung chuông">
    <ellipse cx="148" cy="567" rx="91" ry="19" fill="#1b2d26" opacity=".28"/><path d="M88 562V373Q148 334 208 373V562" fill="none" stroke="#5d3927" strokeWidth="18"/>
    <path d="M108 470Q111 404 148 395Q185 404 188 470L204 516Q148 535 92 516Z" fill="#bd7734" stroke="#f2bd5d" strokeWidth="5"/><ellipse cx="148" cy="516" rx="57" ry="14" fill="#6f3a21"/><circle cx="148" cy="522" r="9" fill="#e5b257"/>
    <g className="bell-waves" fill="none" stroke="#ffd986" strokeWidth="4"><circle cx="148" cy="475" r="72"/><circle cx="148" cy="475" r="92"/></g>
  </g>;
}

function Woodblock({ hit, onClick }: { hit?: boolean; onClick?: () => void }) {
  return <g className={`woodblock-object interactive ${hit ? 'hit' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && onClick?.()} aria-label="Gõ mõ">
    <ellipse cx="798" cy="570" rx="89" ry="18" fill="#1b2d26" opacity=".3"/><path d="M760 538Q735 502 764 465Q808 433 848 469Q873 501 847 537Q810 559 760 538Z" fill="url(#wood)" stroke="#d89552" strokeWidth="5"/><path d="M784 466Q809 487 837 474" fill="none" stroke="#4c261b" strokeWidth="7" strokeLinecap="round"/><circle cx="751" cy="506" r="8" fill="#301a15"/>
    <g className="striker"><path d="M850 446L789 511" stroke="#6d3b25" strokeWidth="10" strokeLinecap="round"/><circle cx="859" cy="437" r="13" fill="#bc7541"/></g>
  </g>;
}

function Incense({ sticks, smoke, lit, onClick }: { sticks: 0 | 1 | 3; smoke?: boolean; lit?: boolean; onClick?: () => void }) {
  const positions = sticks === 3 ? [-15, 0, 15] : sticks === 1 ? [0] : [];
  return <g className={`incense-object interactive temple-piece piece-incense ${lit ? 'just-lit' : ''}`} role="button" tabIndex={0} onClick={onClick} onKeyDown={(e) => e.key === 'Enter' && onClick?.()} aria-label="Thắp nhang">
    <ellipse cx="480" cy="578" rx="105" ry="24" fill="#1b2d26" opacity=".25"/><path d="M400 510Q480 480 560 510L548 574Q480 605 412 574Z" fill="#a65a31" stroke="#e0a355" strokeWidth="5"/><ellipse cx="480" cy="510" rx="80" ry="24" fill="#4a3023"/><ellipse cx="480" cy="507" rx="67" ry="16" fill="#8f7a58"/>
    {positions.map((offset) => <g key={offset} style={{ '--offset': offset } as CSSProperties}><path d={`M${480 + offset} 505V395`} stroke="#a6402d" strokeWidth="4"/><circle cx={480 + offset} cy="393" r="5" fill="#ffb039"/><circle className="ember" cx={480 + offset} cy="393" r="10" fill="#ff6a24" opacity=".3"/>{smoke && <path className={`smoke smoke-${offset + 15}`} d={`M${480 + offset} 387C${463 + offset} 370 ${500 + offset} 354 ${480 + offset} 337S${463 + offset} 307 ${485 + offset} 282`} fill="none" stroke="#f7e7d2" strokeWidth="5" strokeLinecap="round" opacity=".55"/>}</g>)}
  </g>;
}

function MeditationMat({ onClick }: { onClick?: () => void }) {
  return <g className="meditation-mat interactive temple-piece piece-mat" role="button" tabIndex={0} onClick={onClick} onKeyDown={(e) => e.key === 'Enter' && onClick?.()} aria-label="Tĩnh tâm">
    <ellipse cx="670" cy="585" rx="62" ry="18" fill="#172a24" opacity=".25"/>
    <path d="M620 565Q670 548 720 565L712 588Q670 602 628 588Z" fill="#8b9c5c" stroke="#d8cf88" strokeWidth="4"/>
    <path d="M642 570Q670 561 698 570" fill="none" stroke="#e9dda0" strokeWidth="3" opacity=".65"/>
  </g>;
}
