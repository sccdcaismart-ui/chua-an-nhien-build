export type WindowMode = 'mini' | 'full';
export type FruitOffering = 'five-fruit' | 'citrus' | 'apples';

export interface DayHistory {
  date: string;
  points: number;
  woodblockHits: number;
  incenseCount: number;
  meditationSeconds: number;
  bellRings: number;
}

export interface SerenityData {
  version: 1;
  today: string;
  todayPoints: number;
  totalPoints: number;
  totalWoodblockHits: number;
  totalIncenseCount: number;
  totalMeditationSeconds: number;
  streakDays: number;
  lastActiveDate: string | null;
  firstIncenseAwardedOn: string | null;
  firstOfferingAwardedOn?: string | null;
  currentOffering?: FruitOffering | null;
  completedMeditations: string[];
  history: DayHistory[];
}

export interface Settings {
  masterVolume: number;
  woodblockVolume: number;
  bellVolume: number;
  ambientVolume: number;
  muted: boolean;
  ambientEnabled: boolean;
  effectSpeed: number;
  incenseSmoke: boolean;
  natureMotion: boolean;
  autostart: boolean;
  alwaysOnTop: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  masterVolume: 0.72,
  woodblockVolume: 0.8,
  bellVolume: 0.72,
  ambientVolume: 0.22,
  muted: false,
  ambientEnabled: false,
  effectSpeed: 1,
  incenseSmoke: true,
  natureMotion: true,
  autostart: false,
  alwaysOnTop: true
};
