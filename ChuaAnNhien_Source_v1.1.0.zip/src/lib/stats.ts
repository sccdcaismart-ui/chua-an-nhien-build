import type { DayHistory, SerenityData } from './types';

export const localDateKey = (date = new Date()): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const emptyDay = (date: string): DayHistory => ({
  date, points: 0, woodblockHits: 0, incenseCount: 0, meditationSeconds: 0, bellRings: 0
});

export function createDefaultData(today = localDateKey()): SerenityData {
  return {
    version: 1, today, todayPoints: 0, totalPoints: 0,
    totalWoodblockHits: 0, totalIncenseCount: 0, totalMeditationSeconds: 0,
    streakDays: 0, lastActiveDate: null, firstIncenseAwardedOn: null,
    firstOfferingAwardedOn: null, currentOffering: null,
    completedMeditations: [], history: [emptyDay(today)]
  };
}

const daysBetween = (a: string, b: string) =>
  Math.round((new Date(`${b}T12:00:00`).getTime() - new Date(`${a}T12:00:00`).getTime()) / 86_400_000);

export function rollover(data: SerenityData, today = localDateKey()): SerenityData {
  if (data.today === today) return data;
  const history = data.history.some((day) => day.date === today)
    ? data.history
    : [...data.history, emptyDay(today)].slice(-30);
  return { ...data, today, todayPoints: history.find((day) => day.date === today)?.points ?? 0, history };
}

export type Activity =
  | { type: 'woodblock'; points: number }
  | { type: 'bell' }
  | { type: 'incense'; sticks: 1 | 3; points: number }
  | { type: 'offering'; points: number }
  | { type: 'meditation'; seconds: number; points: number };

export function applyActivity(input: SerenityData, activity: Activity, today = localDateKey()): SerenityData {
  const data = rollover(input, today);
  let points = 0;
  let woodblock = 0;
  let incense = 0;
  let meditation = 0;
  let bell = 0;
  if (activity.type === 'woodblock') { points = activity.points; woodblock = 1; }
  if (activity.type === 'bell') bell = 1;
  if (activity.type === 'incense') { points = activity.points; incense = activity.sticks; }
  if (activity.type === 'offering') points = activity.points;
  if (activity.type === 'meditation') { points = activity.points; meditation = activity.seconds; }

  const history = data.history.map((day) => day.date === today ? {
    ...day,
    points: day.points + points,
    woodblockHits: day.woodblockHits + woodblock,
    incenseCount: day.incenseCount + incense,
    meditationSeconds: day.meditationSeconds + meditation,
    bellRings: day.bellRings + bell
  } : day);
  const firstToday = data.lastActiveDate !== today;
  const streakDays = firstToday
    ? (!data.lastActiveDate || daysBetween(data.lastActiveDate, today) !== 1 ? 1 : data.streakDays + 1)
    : data.streakDays;
  return {
    ...data, todayPoints: data.todayPoints + points, totalPoints: data.totalPoints + points,
    totalWoodblockHits: data.totalWoodblockHits + woodblock,
    totalIncenseCount: data.totalIncenseCount + incense,
    totalMeditationSeconds: data.totalMeditationSeconds + meditation,
    streakDays, lastActiveDate: today, history
  };
}

export function todayMeditation(data: SerenityData): number {
  return data.history.find((day) => day.date === data.today)?.meditationSeconds ?? 0;
}
