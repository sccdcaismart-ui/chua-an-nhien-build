import type { CSSProperties } from 'react';
import type { FruitOffering } from '../lib/types';

type RitualAnimation = 'incense' | 'offering' | null;

type Props = {
  mini?: boolean;
  gateOpening?: boolean;
  returning?: boolean;
  incenseSticks?: 0 | 1 | 3;
  ritualIncenseSticks?: 1 | 3;
  offering?: FruitOffering | null;
  ritualOffering?: FruitOffering;
  ritualAnimation?: RitualAnimation;
  smoke?: boolean;
  natureMotion?: boolean;
  onGate?: () => void;
  onBell?: () => void;
  onWoodblock?: () => void;
  onIncense?: () => void;
  onOffering?: () => void;
  onMeditation?: () => void;
  bellRinging?: boolean;
  woodblockHit?: boolean;
  incenseLit?: boolean;
  arriving?: boolean;
  leaving?: boolean;
};

export function TempleArtwork({
  mini = false,
  gateOpening,
  returning,
  incenseSticks = 0,
  ritualIncenseSticks = 1,
  offering = null,
  ritualOffering = 'five-fruit',
  ritualAnimation = null,
  smoke = true,
  natureMotion = true,
  onGate,
  onBell,
  onWoodblock,
  onIncense,
  onOffering,
  onMeditation,
  bellRinging,
  woodblockHit,
  incenseLit,
  arriving,
  leaving
}: Props) {
  const cls = [
    'temple-artwork',
    mini ? 'is-mini mini-altar-artwork' : 'is-full altar-room-artwork',
    natureMotion ? '' : 'motion-off',
    arriving ? 'is-arriving' : '',
    leaving ? 'is-leaving' : '',
    returning ? 'is-returning' : ''
  ].filter(Boolean).join(' ');

  if (mini) {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" className={cls} viewBox="0 0 300 360" role="img" aria-label="Bàn thờ Phật An Nhiên ở góc màn hình">
        <ArtworkDefs/>
        <MiniAltar
          opening={gateOpening}
          returning={returning}
          incenseSticks={incenseSticks}
          offering={offering}
          smoke={smoke}
          onOpen={onGate}
        />
      </svg>
    );
  }

  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={cls} viewBox="0 0 960 650" role="img" aria-label="Không gian bàn thờ Phật Chùa An Nhiên">
      <ArtworkDefs/>
      <AltarRoomBackground/>
      <FullAltar
        incenseSticks={ritualAnimation === 'incense' ? 0 : incenseSticks}
        offering={ritualAnimation === 'offering' ? null : offering}
        smoke={smoke}
        incenseLit={incenseLit}
        onIncense={onIncense}
        onOffering={onOffering}
      />
      <FlowerVase x={112} y={470} scale={1.12}/>
      <FlowerVase x={848} y={470} scale={1.12} mirrored/>
      <Bell ringing={bellRinging} onClick={onBell}/>
      <Woodblock hit={woodblockHit} onClick={onWoodblock}/>
      <MeditationMat onClick={onMeditation}/>
      <RitualHands animation={ritualAnimation} incenseSticks={ritualIncenseSticks} offering={ritualOffering}/>
    </svg>
  );
}

function ArtworkDefs() {
  return <defs>
    <linearGradient id="altarWall" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f3d9ad"/><stop offset=".58" stopColor="#c98f62"/><stop offset="1" stopColor="#7a4633"/></linearGradient>
    <linearGradient id="altarFloor" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#74402f"/><stop offset="1" stopColor="#2e211c"/></linearGradient>
    <linearGradient id="altarWood" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#8f4328"/><stop offset=".48" stopColor="#5d291f"/><stop offset="1" stopColor="#2f1715"/></linearGradient>
    <linearGradient id="altarWoodLight" x1="0" y1="0" x2="1" y2="0"><stop stopColor="#c56d35"/><stop offset=".5" stopColor="#8a3f27"/><stop offset="1" stopColor="#5b271e"/></linearGradient>
    <linearGradient id="altarGold" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#fff0a3"/><stop offset=".42" stopColor="#efbd4e"/><stop offset="1" stopColor="#b96721"/></linearGradient>
    <linearGradient id="altarCeramic" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f0d778"/><stop offset="1" stopColor="#96722e"/></linearGradient>
    <linearGradient id="robe" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#ffe77b"/><stop offset=".5" stopColor="#e9a92f"/><stop offset="1" stopColor="#a85a1e"/></linearGradient>
    <linearGradient id="skin" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f6c79f"/><stop offset="1" stopColor="#c97d5d"/></linearGradient>
    <radialGradient id="altarHalo"><stop stopColor="#fff8c5" stopOpacity=".95"/><stop offset=".45" stopColor="#f8cf64" stopOpacity=".42"/><stop offset="1" stopColor="#e28a2e" stopOpacity="0"/></radialGradient>
    <radialGradient id="lampGlow"><stop stopColor="#fff8b4"/><stop offset=".38" stopColor="#ffbd38"/><stop offset="1" stopColor="#e96619"/></radialGradient>
    <filter id="altarShadow" x="-30%" y="-30%" width="160%" height="180%"><feDropShadow dx="0" dy="9" stdDeviation="7" floodColor="#2b1110" floodOpacity=".42"/></filter>
    <filter id="miniShadow" x="-40%" y="-30%" width="180%" height="190%"><feDropShadow dx="0" dy="8" stdDeviation="7" floodColor="#20110d" floodOpacity=".48"/></filter>
    <filter id="goldGlow" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="10"/></filter>
    <filter id="emberGlow" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="4"/></filter>
  </defs>;
}

function MiniAltar({ opening, returning, incenseSticks, offering, smoke, onOpen }: {
  opening?: boolean;
  returning?: boolean;
  incenseSticks: 0 | 1 | 3;
  offering: FruitOffering | null;
  smoke?: boolean;
  onOpen?: () => void;
}) {
  return <g
    className={`mini-altar interactive ${opening ? 'opening' : ''} ${returning ? 'returning' : ''}`}
    role="button"
    tabIndex={0}
    onClick={onOpen}
    onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onOpen?.()}
    aria-label="Mở không gian Chùa An Nhiên"
  >
    <ellipse cx="150" cy="337" rx="112" ry="13" fill="#24140f" opacity=".34"/>
    <g className="mini-altar-glow"><ellipse cx="150" cy="155" rx="102" ry="123" fill="url(#altarHalo)" opacity=".48" filter="url(#goldGlow)"/></g>
    <g filter="url(#miniShadow)">
      <path d="M48 82Q150 12 252 82L269 93Q150 67 31 93Z" fill="url(#altarWood)"/>
      <path d="M38 84Q150 48 262 84L249 100Q150 76 51 100Z" fill="url(#altarGold)"/>
      <path d="M58 102H242V263H58Z" fill="url(#altarWood)" stroke="#e2a849" strokeWidth="4"/>
      <path d="M70 115H230V245H70Z" fill="#5a2b23" stroke="#f0c569" strokeWidth="3"/>
      <path d="M57 263H243L260 287H40Z" fill="url(#altarWoodLight)"/>
      <path d="M31 287H269V316H31Z" fill="url(#altarWood)" stroke="#c77b38" strokeWidth="3"/>
      <path d="M45 316H255L243 337H57Z" fill="#54251d"/>
      <rect x="104" y="91" width="92" height="28" rx="5" fill="url(#altarGold)"/>
      <text x="150" y="110" textAnchor="middle" fill="#4a241b" fontFamily="var(--font-display)" fontSize="13" fontWeight="700">AN NHIÊN</text>
      <MiniLamp x={76}/><MiniLamp x={224}/>
      <BuddhaFigure x={150} y={226} scale={.92}/>
      <FlowerVase x={82} y={264} scale={.48}/>
      <FlowerVase x={218} y={264} scale={.48} mirrored/>
      {offering && <OfferingPlate offering={offering} x={190} y={260} scale={.54}/>} 
      <IncenseBowl sticks={incenseSticks} x={150} y={278} scale={.52} smoke={smoke}/>
    </g>
    <g className="mini-sparkles" fill="#ffe389"><circle cx="42" cy="170" r="2"/><circle cx="263" cy="138" r="2.5"/><circle cx="247" cy="244" r="1.8"/></g>
  </g>;
}

function MiniLamp({ x }: { x: number }) {
  return <g transform={`translate(${x} 135)`} className="altar-lamp"><ellipse rx="25" ry="28" fill="#ffbc35" opacity=".16" filter="url(#goldGlow)"/><path d="M-7-12H7L11-4L8 12L0 19L-8 12L-11-4Z" fill="url(#lampGlow)"/><path d="M0 19V28" stroke="#d99837" strokeWidth="3"/></g>;
}

function AltarRoomBackground() {
  return <g className="altar-room-background">
    <rect width="960" height="650" fill="url(#altarWall)"/>
    <circle cx="480" cy="205" r="250" fill="url(#altarHalo)" opacity=".5"/>
    <g className="altar-clouds" fill="none" stroke="#f7dc9d" strokeWidth="7" strokeLinecap="round" opacity=".24">
      <path d="M55 168h82q10-30 36-17q24-32 55 2h58"/><path d="M687 180h64q14-33 43-12q31-29 60 6h52"/>
      <path d="M91 235h91q18-24 45-5h44"/><path d="M704 246h65q17-23 43-5h57"/>
    </g>
    <path d="M0 492H960V650H0Z" fill="url(#altarFloor)"/>
    <path d="M0 520H960" stroke="#d19a63" strokeWidth="3" opacity=".35"/>
    {[80, 250, 420, 590, 760, 930].map((x) => <path key={x} d={`M${x} 520L${x - 65} 650`} stroke="#d19a63" strokeWidth="2" opacity=".18"/>)}
    <path d="M0 0H104L72 650H0ZM960 0H856L888 650H960Z" fill="#4d251f" opacity=".64"/>
    <path d="M0 0H80L46 470H0ZM960 0H880L914 470H960Z" fill="#7f3229" opacity=".72"/>
  </g>;
}

function FullAltar({ incenseSticks, offering, smoke, incenseLit, onIncense, onOffering }: {
  incenseSticks: 0 | 1 | 3;
  offering: FruitOffering | null;
  smoke?: boolean;
  incenseLit?: boolean;
  onIncense?: () => void;
  onOffering?: () => void;
}) {
  return <g className="full-altar" filter="url(#altarShadow)">
    <ellipse cx="480" cy="514" rx="264" ry="24" fill="#2b1512" opacity=".3"/>
    <path d="M258 142Q480 28 702 142L731 157Q480 111 229 157Z" fill="url(#altarWood)"/>
    <path d="M236 142Q480 78 724 142L702 167Q480 126 258 167Z" fill="url(#altarGold)"/>
    <path d="M276 168H684V414H276Z" fill="url(#altarWood)" stroke="#d9943f" strokeWidth="6"/>
    <path d="M300 190H660V390H300Z" fill="#572922" stroke="#efc167" strokeWidth="4"/>
    <g className="altar-cloud-trim" fill="none" stroke="#eab553" strokeWidth="5" strokeLinecap="round">
      <path d="M326 218q20-28 41 0q19-31 43-2h25M525 216q22-29 43 1q20-28 42 1h24"/>
    </g>
    <path d="M252 414H708L743 448H217Z" fill="url(#altarWoodLight)"/>
    <path d="M213 448H747V491H213Z" fill="url(#altarWood)" stroke="#cf7d35" strokeWidth="4"/>
    <path d="M238 491H722L704 523H256Z" fill="#4b211b"/>
    <rect x="384" y="139" width="192" height="44" rx="6" fill="url(#altarGold)"/>
    <text x="480" y="168" fill="#4d261c" fontFamily="var(--font-display)" fontSize="23" fontWeight="700" textAnchor="middle">CHÙA AN NHIÊN</text>
    <g className="altar-pillars" fill="url(#altarWoodLight)"><rect x="258" y="157" width="31" height="280" rx="8"/><rect x="671" y="157" width="31" height="280" rx="8"/></g>
    <FullLamp x={311}/><FullLamp x={649}/>
    <BuddhaFigure x={480} y={374} scale={1.48}/>
    <FlowerVase x={350} y={414} scale={.7}/>
    <FlowerVase x={610} y={414} scale={.7} mirrored/>
    <g className="offering-spot interactive" role="button" tabIndex={0} onClick={onOffering} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onOffering?.()} aria-label="Dâng lễ trái cây">
      {offering ? <OfferingPlate offering={offering} x={568} y={435} scale={.78}/> : <g opacity=".45"><ellipse cx="568" cy="435" rx="46" ry="9" fill="#d9aa57"/><path d="M531 431Q568 447 605 431" fill="none" stroke="#ffe29a" strokeWidth="3"/></g>}
    </g>
    <IncenseBowl sticks={incenseSticks} x={480} y={464} scale={.88} smoke={smoke} lit={incenseLit} onClick={onIncense}/>
  </g>;
}

function FullLamp({ x }: { x: number }) {
  return <g transform={`translate(${x} 246)`} className="altar-lamp"><ellipse rx="42" ry="48" fill="#ffbc35" opacity=".15" filter="url(#goldGlow)"/><path d="M-12-21H12L19-8L14 22L0 35L-14 22L-19-8Z" fill="url(#lampGlow)"/><path d="M0 35V48" stroke="#da9734" strokeWidth="5"/></g>;
}

function BuddhaFigure({ x, y, scale }: { x: number; y: number; scale: number }) {
  return <g transform={`translate(${x} ${y}) scale(${scale})`} className="buddha-figure">
    <circle className="buddha-halo" cx="0" cy="-69" r="63" fill="url(#altarHalo)"/>
    <path d="M0-127C-42-112-62-78-54-39C-46-6-25 11 0 24C25 11 46-6 54-39C62-78 42-112 0-127Z" fill="none" stroke="#f4c858" strokeWidth="4" opacity=".9"/>
    <circle cx="0" cy="-74" r="21" fill="url(#altarGold)"/>
    <path d="M-16-82Q0-102 16-82Q9-96 0-101Q-9-96-16-82Z" fill="#9c541f"/>
    <circle cx="0" cy="-98" r="6" fill="#d58c29"/>
    <path d="M-33-14Q-29-59 0-59Q29-59 33-14L48 16H-48Z" fill="url(#robe)" stroke="#f7da77" strokeWidth="3"/>
    <path d="M-4-57Q-29-35-29-5M4-57Q18-39 29-5" fill="none" stroke="#fff0a0" strokeWidth="3" opacity=".65"/>
    <path d="M-28-8Q-12-23 0-8Q12-23 28-8" fill="none" stroke="#75401f" strokeWidth="3" strokeLinecap="round"/>
    <path d="M-57 21Q0 2 57 21L46 38H-46Z" fill="#db8728" stroke="#ffdc72" strokeWidth="4"/>
    <g fill="#ffd86b"><ellipse cx="-38" cy="22" rx="16" ry="7"/><ellipse cx="0" cy="17" rx="18" ry="8"/><ellipse cx="38" cy="22" rx="16" ry="7"/></g>
    <path d="M-9-75Q-5-71 0-75Q5-71 9-75M-6-66Q0-62 6-66" fill="none" stroke="#75401f" strokeWidth="1.5" strokeLinecap="round"/>
  </g>;
}

function FlowerVase({ x, y, scale = 1, mirrored = false }: { x: number; y: number; scale?: number; mirrored?: boolean }) {
  return <g transform={`translate(${x} ${y}) scale(${mirrored ? -scale : scale} ${scale})`} className="flower-vase">
    <g fill="none" stroke="#315c36" strokeWidth="5" strokeLinecap="round"><path d="M0-21L-20-95M0-21L18-107M0-21L42-78M0-21L-42-67"/></g>
    <g fill="#3b7c49"><ellipse cx="-29" cy="-71" rx="15" ry="8" transform="rotate(28 -29 -71)"/><ellipse cx="29" cy="-83" rx="16" ry="8" transform="rotate(-24 29 -83)"/><ellipse cx="-12" cy="-99" rx="14" ry="7"/></g>
    <g className="altar-flowers" fill="#d94764" stroke="#a3264a" strokeWidth="2">
      <circle cx="-22" cy="-105" r="15"/><circle cx="18" cy="-120" r="17"/><circle cx="45" cy="-91" r="15"/><circle cx="-46" cy="-81" r="14"/>
    </g>
    <path d="M-27-38H27L20 8Q0 25-20 8Z" fill="url(#altarCeramic)" stroke="#f1cf6b" strokeWidth="4"/>
    <path d="M-25-20L22 5M22-20L-20 5" stroke="#a6612b" strokeWidth="3" opacity=".65"/>
  </g>;
}

function OfferingPlate({ offering, x, y, scale = 1 }: { offering: FruitOffering; x: number; y: number; scale?: number }) {
  const fruit = offering === 'citrus'
    ? [{ x: -26, y: -18, c: '#f29b24' }, { x: 0, y: -24, c: '#ffb02e' }, { x: 27, y: -17, c: '#e9871f' }, { x: -8, y: -43, c: '#f5a42a' }]
    : offering === 'apples'
      ? [{ x: -26, y: -18, c: '#c8323d' }, { x: 0, y: -23, c: '#df3d47' }, { x: 27, y: -17, c: '#b92735' }, { x: 2, y: -44, c: '#ef5960' }]
      : [{ x: -31, y: -17, c: '#e09a28' }, { x: -7, y: -27, c: '#d84448' }, { x: 20, y: -18, c: '#6ea53d' }, { x: 3, y: -48, c: '#e6bd35' }, { x: 37, y: -34, c: '#a95aa4' }];
  return <g transform={`translate(${x} ${y}) scale(${scale})`} className="offering-plate">
    <ellipse cx="0" cy="1" rx="58" ry="12" fill="#64321f" opacity=".32"/>
    <path d="M-55-4Q0 23 55-4L47 11Q0 34-47 11Z" fill="url(#altarCeramic)" stroke="#f3d377" strokeWidth="4"/>
    {fruit.map((item, index) => <g key={index}><circle cx={item.x} cy={item.y} r="18" fill={item.c} stroke="#8a4a27" strokeWidth="2"/><path d={`M${item.x} ${item.y - 17}q8-11 16-5`} fill="none" stroke="#42743d" strokeWidth="3" strokeLinecap="round"/></g>)}
  </g>;
}

function IncenseBowl({ sticks, x, y, scale = 1, smoke, lit, onClick }: {
  sticks: 0 | 1 | 3;
  x: number;
  y: number;
  scale?: number;
  smoke?: boolean;
  lit?: boolean;
  onClick?: () => void;
}) {
  const positions = sticks === 3 ? [-14, 0, 14] : sticks === 1 ? [0] : [];
  return <g
    transform={`translate(${x} ${y}) scale(${scale})`}
    className={`incense-object interactive ${lit ? 'just-lit' : ''}`}
    role={onClick ? 'button' : undefined}
    tabIndex={onClick ? 0 : undefined}
    onClick={onClick}
    onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()}
    aria-label={onClick ? 'Thắp nhang' : undefined}
    aria-hidden={onClick ? undefined : true}
  >
    <ellipse cx="0" cy="16" rx="72" ry="15" fill="#25120e" opacity=".32"/>
    <path d="M-58-7Q0-29 58-7L48 39Q0 59-48 39Z" fill="url(#altarCeramic)" stroke="#f0ca64" strokeWidth="4"/>
    <ellipse cx="0" cy="-8" rx="58" ry="16" fill="#5c2d21"/>
    <ellipse cx="0" cy="-9" rx="45" ry="10" fill="#8f785c"/>
    {positions.map((offset) => <g key={offset} style={{ '--offset': offset } as CSSProperties}>
      <path d={`M${offset} -10V-105`} stroke="#9f3829" strokeWidth="4"/>
      <circle cx={offset} cy="-107" r="4" fill="#ffb035"/>
      <circle className="ember" cx={offset} cy="-107" r="10" fill="#ff7a2e" opacity=".3" filter="url(#emberGlow)"/>
      {smoke && <path className={`smoke smoke-${offset + 14}`} d={`M${offset} -113C${offset - 20} -133 ${offset + 17} -148 ${offset} -169S${offset - 15} -199 ${offset + 8} -222`} fill="none" stroke="#fff3d6" strokeWidth="5" strokeLinecap="round" opacity=".55"/>}
    </g>)}
  </g>;
}

function RitualHands({ animation, incenseSticks, offering }: { animation: RitualAnimation; incenseSticks: 1 | 3; offering: FruitOffering }) {
  if (!animation) return null;
  if (animation === 'incense') {
    const positions = incenseSticks === 3 ? [-13, 0, 13] : [0];
    return <g className="ritual-hands ritual-hands-incense" aria-hidden="true">
      <path className="ritual-sleeve sleeve-left" d="M274 650Q323 535 400 462L444 501Q368 573 350 650Z" fill="#8d4a28"/>
      <path className="ritual-sleeve sleeve-right" d="M686 650Q637 535 560 462L516 501Q592 573 610 650Z" fill="#8d4a28"/>
      <path d="M390 477Q418 438 449 431Q467 437 466 457Q449 485 425 506Z" fill="url(#skin)" stroke="#a65f49" strokeWidth="3"/>
      <path d="M570 477Q542 438 511 431Q493 437 494 457Q511 485 535 506Z" fill="url(#skin)" stroke="#a65f49" strokeWidth="3"/>
      <path d="M446 454Q480 469 514 454" fill="none" stroke="#a65f49" strokeWidth="4" strokeLinecap="round"/>
      <g className="ritual-held-incense">
        {positions.map((offset) => <g key={offset}><path d={`M${480 + offset} 452V342`} stroke="#a63d2d" strokeWidth="4"/><circle cx={480 + offset} cy="339" r="5" fill="#ffb13d"/><circle cx={480 + offset} cy="339" r="13" fill="#ff8b31" opacity=".24" filter="url(#emberGlow)"/></g>)}
      </g>
    </g>;
  }

  return <g className="ritual-hands ritual-hands-offering" aria-hidden="true">
    <path className="ritual-sleeve sleeve-left" d="M254 650Q322 552 393 456L444 485Q381 571 354 650Z" fill="#8d4a28"/>
    <path className="ritual-sleeve sleeve-right" d="M706 650Q638 552 567 456L516 485Q579 571 606 650Z" fill="#8d4a28"/>
    <path d="M381 472Q406 441 444 439L468 461Q433 487 397 498Z" fill="url(#skin)" stroke="#a65f49" strokeWidth="3"/>
    <path d="M579 472Q554 441 516 439L492 461Q527 487 563 498Z" fill="url(#skin)" stroke="#a65f49" strokeWidth="3"/>
    <OfferingPlate offering={offering} x={480} y={442} scale={1.02}/>
  </g>;
}

function Bell({ ringing, onClick }: { ringing?: boolean; onClick?: () => void }) {
  return <g className={`bell-object interactive ${ringing ? 'ringing' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Rung chuông">
    <ellipse cx="126" cy="553" rx="76" ry="14" fill="#281510" opacity=".3"/>
    <path d="M76 548V406Q126 371 176 406V548" fill="none" stroke="#6b3423" strokeWidth="16"/>
    <path d="M91 485Q96 428 126 419Q156 428 161 485L176 526Q126 545 76 526Z" fill="#b86a2d" stroke="#f0bd54" strokeWidth="4"/>
    <ellipse cx="126" cy="526" rx="50" ry="12" fill="#6f3a25"/><circle cx="126" cy="531" r="8" fill="#f2c75b"/>
    <g className="bell-waves" fill="none" stroke="#ffe694" strokeWidth="3"><circle cx="126" cy="486" r="64"/><circle cx="126" cy="486" r="82"/></g>
  </g>;
}

function Woodblock({ hit, onClick }: { hit?: boolean; onClick?: () => void }) {
  return <g className={`woodblock-object interactive ${hit ? 'hit' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Gõ mõ">
    <ellipse cx="827" cy="558" rx="78" ry="14" fill="#281510" opacity=".3"/>
    <path d="M793 534Q765 503 793 468Q829 444 865 470Q888 504 861 536Q827 553 793 534Z" fill="url(#altarWoodLight)" stroke="#efb650" strokeWidth="4"/>
    <path d="M809 470Q831 491 855 477" fill="none" stroke="#55251d" strokeWidth="7" strokeLinecap="round"/><circle cx="784" cy="504" r="7" fill="#2d1713"/>
    <g className="striker"><path d="M869 451L814 511" stroke="#783a25" strokeWidth="9" strokeLinecap="round"/><circle cx="877" cy="443" r="12" fill="#b66835"/></g>
  </g>;
}

function MeditationMat({ onClick }: { onClick?: () => void }) {
  return <g className="meditation-mat interactive" role="button" tabIndex={0} onClick={onClick} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Tĩnh tâm">
    <ellipse cx="688" cy="568" rx="64" ry="14" fill="#281510" opacity=".25"/>
    <path d="M631 548Q688 530 745 548L735 574Q688 590 641 574Z" fill="#6c7b47" stroke="#d2c277" strokeWidth="4"/>
    <path d="M659 553Q688 544 717 553" fill="none" stroke="#eee0a4" strokeWidth="3" opacity=".7"/>
  </g>;
}
