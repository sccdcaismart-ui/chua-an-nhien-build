# Trạng thái kiểm thử bản bàn giao

Ngày kiểm tra: 20/07/2026 (Asia/Ho_Chi_Minh)

## Đã chạy trong môi trường hiện tại

| Hạng mục | Kết quả |
|---|---|
| TypeScript strict check | Đạt |
| Vite production build | Đạt |
| Unit test logic điểm, chuỗi ngày, lịch sử | Đạt |
| Smoke test mini → toàn cảnh | Đạt |
| Số bài test | 6/6 đạt |
| Audit dependency production mức high | 0 lỗ hổng |
| Kiểm tra Tauri CLI/environment | Đã chạy |

Production frontend được tạo tại `dist/` với JS gzip khoảng 64 KB và CSS gzip khoảng 5 KB.

## Giới hạn môi trường hiện tại

Workspace hiện chạy Ubuntu và không có `rustc`, Cargo, WebKit2GTK hoặc Windows toolchain. Vì vậy không thể compile/khởi chạy lớp Rust hoặc tạo NSIS `.exe`/WiX `.msi` trong workspace này. Lệnh Tauri dừng đúng tại bước `cargo metadata` do không có Cargo; đây không phải lỗi của frontend.

Việc xác nhận tray thật, taskbar/DPI/multi-monitor, close-to-tray, single-instance, RAM và installer phải được chạy trên Windows 10/11. Checklist và lệnh build Windows có trong `README.md`; workflow Windows cũng nằm tại `.github/workflows/windows-build.yml`.

Không có file `.exe` hoặc `.msi` giả trong gói bàn giao.
