# Build status — Chùa An Nhiên 1.2.0

- Giao diện: Mẫu 2 — Zen hiện đại thanh tịnh.
- Mini mode: có tiêu đề, 4 lối tắt nghi thức, công đức và nút mở rộng.
- Full mode: thanh nghi thức bên trái, điện thờ ở giữa, bảng lời dạy/thiền/tiến trình/âm thanh bên phải.
- Dâng lễ: mâm lễ được lưu ngay khi bắt đầu nghi thức, xuất hiện cố định sau khi tay đặt xuống, giữ lại khi chuyển mini mode và sau khi mở lại app.
- Frontend tests: 9/9 passed.
- Production frontend build: passed.
- GitHub Actions Windows workflow: `.github/workflows/windows-build.yml`.
- Artifact đầu ra: `ChuaAnNhien_Portable_x64.exe` và `ChuaAnNhien_Setup_x64.exe`.
