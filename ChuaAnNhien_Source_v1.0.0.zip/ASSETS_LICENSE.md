# Danh sách asset và giấy phép

| Asset | Vị trí | Nguồn | Giấy phép |
|---|---|---|---|
| Cảnh cổng và sân chùa | `src/components/TempleArtwork.tsx` | SVG nguyên bản tạo riêng cho dự án | MIT, cùng dự án |
| Animation và hiệu ứng | `src/styles.css` | CSS nguyên bản tạo riêng cho dự án | MIT, cùng dự án |
| Icon ứng dụng | `src-tauri/icons/` | Thiết kế vector/hình học nguyên bản | MIT, cùng dự án |
| Âm mõ, chuông, nhang, gió | `src/lib/audio.ts` | Tổng hợp thời gian thực bằng Web Audio API; không chứa bản ghi | MIT, cùng dự án |
| Biểu tượng giao diện | package `lucide-react` | Lucide Contributors | ISC |
| Font | Segoe UI/system UI | Font hệ thống Windows, không phân phối kèm | Theo giấy phép Windows của máy người dùng |

Ứng dụng không chứa ảnh, nhạc, logo chùa hoặc tài nguyên bên thứ ba tải từ Internet trong lúc chạy.
