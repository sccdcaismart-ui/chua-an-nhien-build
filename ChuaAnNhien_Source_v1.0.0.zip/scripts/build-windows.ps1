$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

npm run tauri build

$release = Join-Path $root "release"
New-Item -ItemType Directory -Force -Path $release | Out-Null
$target = Join-Path $root "src-tauri\target\release"

Copy-Item (Join-Path $target "chua-an-nhien.exe") (Join-Path $release "ChuaAnNhien_Portable_x64.exe") -Force
$nsis = Get-ChildItem (Join-Path $target "bundle\nsis\*.exe") | Select-Object -First 1
if ($nsis) { Copy-Item $nsis.FullName (Join-Path $release "ChuaAnNhien_Setup_x64.exe") -Force }
$msi = Get-ChildItem (Join-Path $target "bundle\msi\*.msi") | Select-Object -First 1
if ($msi) { Copy-Item $msi.FullName (Join-Path $release "ChuaAnNhien_x64.msi") -Force }

Write-Host "Hoàn tất. Xem thư mục: $release"
