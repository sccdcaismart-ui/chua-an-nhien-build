$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

npm run tauri build

$release = Join-Path $root "release"
# Xóa kết quả cũ để không vô tình upload lại file MSI từ lần build trước.
if (Test-Path $release) { Remove-Item $release -Recurse -Force }
New-Item -ItemType Directory -Force -Path $release | Out-Null
$target = Join-Path $root "src-tauri\target\release"

Copy-Item (Join-Path $target "chua-an-nhien.exe") (Join-Path $release "ChuaAnNhien_Portable_x64.exe") -Force
$nsis = Get-ChildItem (Join-Path $target "bundle\nsis\*.exe") | Select-Object -First 1
if (-not $nsis) { throw "Không tìm thấy bộ cài NSIS .exe." }
Copy-Item $nsis.FullName (Join-Path $release "ChuaAnNhien_Setup_x64.exe") -Force

Write-Host "Hoàn tất: Portable EXE và Setup EXE tại $release"
