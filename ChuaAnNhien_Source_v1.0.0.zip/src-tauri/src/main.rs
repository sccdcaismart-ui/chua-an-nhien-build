#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    chua_an_nhien_lib::run();
}
