use tauri::{
    menu::{Menu, MenuItem, PredefinedMenuItem},
    tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent},
    Emitter, Manager, RunEvent, WindowEvent,
};
use tauri_plugin_autostart::MacosLauncher;

fn reveal(app: &tauri::AppHandle, event: &str, focus: bool) {
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.unminimize();
        let _ = window.show();
        let _ = app.emit(event, ());
        if focus {
            let _ = window.set_focus();
        }
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let builder = tauri::Builder::default()
        // Single-instance must be registered before every other plugin.
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
            reveal(app, "tray-open-full", true);
        }))
        .plugin(tauri_plugin_store::Builder::default().build())
        .plugin(tauri_plugin_autostart::init(
            MacosLauncher::LaunchAgent,
            Some(vec!["--autostart"]),
        ))
        .setup(|app| {
            let open_full = MenuItem::with_id(app, "open_full", "Mở ngôi chùa", true, None::<&str>)?;
            let open_mini = MenuItem::with_id(app, "open_mini", "Hiển thị cổng chùa mini", true, None::<&str>)?;
            let mute = MenuItem::with_id(app, "toggle_mute", "Bật / tắt âm thanh", true, None::<&str>)?;
            let always_on_top = MenuItem::with_id(app, "toggle_aot", "Bật / tắt luôn nổi trên cùng", true, None::<&str>)?;
            let autostart = MenuItem::with_id(app, "toggle_autostart", "Bật / tắt khởi động cùng Windows", true, None::<&str>)?;
            let settings = MenuItem::with_id(app, "settings", "Cài đặt", true, None::<&str>)?;
            let quit = MenuItem::with_id(app, "quit", "Thoát hoàn toàn", true, None::<&str>)?;
            let separator_1 = PredefinedMenuItem::separator(app)?;
            let separator_2 = PredefinedMenuItem::separator(app)?;
            let menu = Menu::with_items(app, &[
                &open_full, &open_mini, &separator_1, &mute, &always_on_top,
                &autostart, &settings, &separator_2, &quit,
            ])?;

            TrayIconBuilder::with_id("main-tray")
                .icon(app.default_window_icon().expect("application icon").clone())
                .tooltip("Chùa An Nhiên")
                .menu(&menu)
                .show_menu_on_left_click(false)
                .on_menu_event(|app, event| match event.id.as_ref() {
                    "open_full" => reveal(app, "tray-open-full", true),
                    "open_mini" => reveal(app, "tray-open-mini", false),
                    "toggle_mute" => { let _ = app.emit("tray-toggle-mute", ()); }
                    "toggle_aot" => { let _ = app.emit("tray-toggle-always-on-top", ()); }
                    "toggle_autostart" => { let _ = app.emit("tray-toggle-autostart", ()); }
                    "settings" => reveal(app, "tray-open-settings", true),
                    "quit" => app.exit(0),
                    _ => {}
                })
                .on_tray_icon_event(|tray, event| {
                    if let TrayIconEvent::Click {
                        button: MouseButton::Left,
                        button_state: MouseButtonState::Up,
                        ..
                    } = event {
                        reveal(tray.app_handle(), "tray-open-mini", false);
                    }
                })
                .build(app)?;
            Ok(())
        })
        .on_window_event(|window, event| {
            if let WindowEvent::CloseRequested { api, .. } = event {
                api.prevent_close();
                let _ = window.hide();
            }
        });

    builder
        .build(tauri::generate_context!())
        .expect("không thể khởi tạo Chùa An Nhiên")
        .run(|_app, event| {
            if let RunEvent::ExitRequested { api, code, .. } = event {
                if code.is_none() {
                    api.prevent_exit();
                }
            }
        });
}
