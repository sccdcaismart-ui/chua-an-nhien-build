# Build Chùa An Nhiên thành app Windows bằng GitHub

## 1. Chuẩn bị repository

1. Giải nén file source.
2. Tạo một repository GitHub mới.
3. Upload **toàn bộ nội dung bên trong thư mục source** lên nhánh `main`.
4. Kiểm tra repository có các mục sau:

```text
.github/workflows/windows-build.yml
src/
src-tauri/
scripts/
package.json
package-lock.json
```

Không upload riêng file ZIP vào repository vì GitHub Actions không tự giải nén source.

## 2. Chạy build

1. Mở tab **Actions** của repository.
2. Chọn workflow **Build Windows**.
3. Chọn **Run workflow** → **Run workflow**.
4. Chờ job hoàn thành và hiện dấu tích xanh.
5. Mở lần chạy vừa hoàn thành, kéo xuống phần **Artifacts**.
6. Tải `ChuaAnNhien-Windows-x64.zip`.

Bên trong artifact gồm:

- `ChuaAnNhien_Portable_x64.exe`: chạy trực tiếp, không cần cài đặt.
- `ChuaAnNhien_Setup_x64.exe`: bộ cài Windows.

## 3. Trường hợp workflow không xuất hiện

Kiểm tra file sau có nằm đúng đường dẫn hay không:

```text
.github/workflows/windows-build.yml
```

Sau đó vào **Actions**, bật workflow nếu GitHub đang yêu cầu xác nhận.

## 4. Lưu ý Windows SmartScreen

App chưa ký chứng thư số nên Windows SmartScreen có thể hiển thị cảnh báo. Chọn **More info** → **Run anyway** khi bạn đang chạy đúng file do repository của mình build ra.
