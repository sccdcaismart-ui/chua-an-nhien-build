import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { BarChart3, Bell, ChevronDown, CircleDot, Flame, Leaf, Maximize2, Minimize2, Settings as SettingsIcon, Sparkles, Timer, Volume2, VolumeX, X } from 'lucide-react';
import { TempleArtwork } from './components/TempleArtwork';
import { SettingsPanel } from './components/SettingsPanel';
import { MeditationOverlay } from './components/MeditationOverlay';
import { StatsPanel } from './components/StatsPanel';
import { templeAudio } from './lib/audio';
import { dailyQuote } from './lib/quotes';
import { applyActivity, createDefaultData, localDateKey, rollover } from './lib/stats';
import { clearState, loadState, saveData, saveSettings } from './lib/storage';
import { DEFAULT_SETTINGS, type SerenityData, type Settings, type WindowMode } from './lib/types';
import { applyInitialNativeSettings, applyNativeSettings, hideToTray, installPositionMemory, listenForNativeEvents, resetWindowPosition, setWindowMode } from './lib/native';

type MeditationState = { total: number; remaining: number; paused: boolean };
type TempleTool = 'incense' | 'woodblock' | 'meditation' | 'stats' | null;

export default function App() {
  const [ready, setReady] = useState(false);
  const [mode, setMode] = useState<WindowMode>('mini');
  const [data, setData] = useState<SerenityData>(() => createDefaultData());
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const settingsRef = useRef(settings);
  const modeRef = useRef(mode);
  const [gateOpening, setGateOpening] = useState(false);
  const [templeTransition, setTempleTransition] = useState<'idle' | 'arriving' | 'leaving'>('idle');
  const [miniReturning, setMiniReturning] = useState(false);
  const [activeTool, setActiveTool] = useState<TempleTool>(null);
  const [incenseChoice, setIncenseChoice] = useState<1 | 3>(1);
  const [incenseSticks, setIncenseSticks] = useState<0 | 1 | 3>(0);
  const [incenseLit, setIncenseLit] = useState(false);
  const [woodblockHit, setWoodblockHit] = useState(false);
  const [bellRinging, setBellRinging] = useState(false);
  const [autoWoodblock, setAutoWoodblock] = useState(false);
  const [pointFloat, setPointFloat] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [meditation, setMeditation] = useState<MeditationState | null>(null);
  const [meditationChoice, setMeditationChoice] = useState(60);
  const lastWoodblock = useRef(0);
  const quote = dailyQuote();
  const today = data.history.find((day) => day.date === localDateKey());
  const ritualDone = {
    incense: data.firstIncenseAwardedOn === localDateKey(),
    woodblock: (today?.woodblockHits ?? 0) > 0,
    meditation: (today?.meditationSeconds ?? 0) > 0
  };

  useEffect(() => { settingsRef.current = settings; }, [settings]);
  useEffect(() => { modeRef.current = mode; }, [mode]);
  useEffect(() => {
    const updateVisibility = () => { document.body.dataset.hidden = String(document.hidden); };
    document.addEventListener('visibilitychange', updateVisibility);
    updateVisibility();
    return () => document.removeEventListener('visibilitychange', updateVisibility);
  }, []);

  const openFull = useCallback(async () => {
    setGateOpening(true);
    window.setTimeout(async () => {
      await setWindowMode('full');
      setMode('full'); setGateOpening(false); setTempleTransition('arriving');
      window.setTimeout(() => setTempleTransition('idle'), 760);
    }, 560);
  }, []);
  const openMini = useCallback(async () => {
    setMeditation(null); setAutoWoodblock(false); setActiveTool(null); setTempleTransition('leaving');
    window.setTimeout(async () => {
      const saved = JSON.parse(localStorage.getItem('mini-window-position') ?? 'null') as { x: number; y: number } | null;
      await setWindowMode('mini', saved);
      setMode('mini'); setTempleTransition('idle'); setMiniReturning(true);
      window.setTimeout(() => setMiniReturning(false), 680);
    }, 620);
  }, []);

  const toggleMute = useCallback(() => {
    setSettings((current) => ({ ...current, muted: !current.muted }));
  }, []);

  useEffect(() => {
    let cleanupPosition: (() => void) | undefined;
    let cleanupEvents: (() => void)[] = [];
    void loadState().then(async (state) => {
      setData(state.data); setSettings(state.settings); settingsRef.current = state.settings;
      await applyInitialNativeSettings(state.settings);
      document.documentElement.style.setProperty('--motion-speed', String(1 / state.settings.effectSpeed));
      const saved = JSON.parse(localStorage.getItem('mini-window-position') ?? 'null') as { x: number; y: number } | null;
      await setWindowMode('mini', saved);
      cleanupPosition = await installPositionMemory((position) => {
        if (modeRef.current === 'mini') localStorage.setItem('mini-window-position', JSON.stringify(position));
      });
      cleanupEvents = await listenForNativeEvents({
        openFull, openMini, toggleMute,
        openSettings: () => { void openFull(); setShowSettings(true); },
        toggleAlwaysOnTop: () => setSettings((current) => {
          const next = { ...current, alwaysOnTop: !current.alwaysOnTop };
          void applyNativeSettings(current, next); settingsRef.current = next; return next;
        }),
        toggleAutostart: () => setSettings((current) => {
          const next = { ...current, autostart: !current.autostart };
          void applyNativeSettings(current, next); settingsRef.current = next; return next;
        })
      });
      setReady(true);
    });
    return () => { cleanupPosition?.(); cleanupEvents.forEach((fn) => fn()); };
  }, [openFull, openMini, toggleMute]);

  useEffect(() => { if (ready) void saveData(data); }, [data, ready]);
  useEffect(() => {
    if (!ready) return;
    void saveSettings(settings);
    templeAudio.setAmbient(settings);
    document.documentElement.style.setProperty('--motion-speed', String(1 / settings.effectSpeed));
  }, [settings, ready]);

  const updateSettings = (next: Settings) => {
    void applyNativeSettings(settingsRef.current, next);
    settingsRef.current = next;
    setSettings(next);
  };

  const showNotice = (message: string) => {
    setNotice(message); window.setTimeout(() => setNotice(null), 3600);
  };

  const hitWoodblock = useCallback((awardPoint = true) => {
    const now = performance.now();
    if (now - lastWoodblock.current < 300) return;
    lastWoodblock.current = now;
    templeAudio.woodblock(settingsRef.current);
    setWoodblockHit(true); window.setTimeout(() => setWoodblockHit(false), 260);
    if (awardPoint) {
      setData((current) => applyActivity(rollover(current), { type: 'woodblock', points: 1 }));
      setPointFloat(true); window.setTimeout(() => setPointFloat(false), 850);
    }
  }, []);

  const ringBell = useCallback((force = false) => {
    if (!templeAudio.bell(settingsRef.current, force)) return;
    setBellRinging(true); window.setTimeout(() => setBellRinging(false), 1350);
    setData((current) => applyActivity(rollover(current), { type: 'bell' }));
  }, []);

  const lightIncense = () => {
    const today = localDateKey();
    templeAudio.incense(settings);
    setIncenseSticks(incenseChoice); setIncenseLit(true); window.setTimeout(() => setIncenseLit(false), 900);
    setData((current) => {
      const fresh = rollover(current, today);
      const points = fresh.firstIncenseAwardedOn === today ? 0 : 10;
      const next = applyActivity(fresh, { type: 'incense', sticks: incenseChoice, points }, today);
      return { ...next, firstIncenseAwardedOn: today };
    });
  };

  const startMeditation = () => {
    ringBell(true); setMeditation({ total: meditationChoice, remaining: meditationChoice, paused: false });
  };

  const completeMeditation = useCallback((total: number) => {
    ringBell(true);
    const today = localDateKey();
    const completionKey = `${today}-${total}`;
    const pointMap: Record<number, number> = { 60: 5, 180: 12, 300: 20 };
    setData((current) => {
      const fresh = rollover(current, today);
      const alreadyAwarded = fresh.completedMeditations.includes(completionKey);
      const next = applyActivity(fresh, { type: 'meditation', seconds: total, points: alreadyAwarded ? 0 : pointMap[total] ?? 5 }, today);
      return { ...next, completedMeditations: alreadyAwarded ? next.completedMeditations : [...next.completedMeditations, completionKey].slice(-90) };
    });
    setMeditation(null); showNotice('Bạn vừa dành một khoảng thời gian thật đẹp cho chính mình.');
  }, [ringBell]);

  useEffect(() => {
    if (!meditation || meditation.paused) return;
    const id = window.setInterval(() => setMeditation((current) => {
      if (!current || current.paused) return current;
      if (current.remaining <= 1) { window.clearInterval(id); window.setTimeout(() => completeMeditation(current.total), 0); return current; }
      return { ...current, remaining: current.remaining - 1 };
    }), 1000);
    return () => window.clearInterval(id);
  }, [meditation?.paused, meditation?.total, completeMeditation]);

  useEffect(() => {
    if (!autoWoodblock || mode !== 'full' || meditation) return;
    const id = window.setInterval(() => { if (!document.hidden) hitWoodblock(false); }, 1600);
    return () => window.clearInterval(id);
  }, [autoWoodblock, mode, meditation, hitWoodblock]);

  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement)?.tagName;
      if (event.key === 'Escape' && modeRef.current === 'full') { if (showSettings) setShowSettings(false); else void openMini(); }
      if (event.code === 'Space' && modeRef.current === 'full' && !meditation && !['INPUT', 'BUTTON', 'SELECT'].includes(tag)) { event.preventDefault(); hitWoodblock(true); }
    };
    window.addEventListener('keydown', keydown); return () => window.removeEventListener('keydown', keydown);
  }, [hitWoodblock, meditation, openMini, showSettings]);

  if (!ready) return <div className="loading-screen"><LotusSeal/><span>Đang mở một khoảng an nhiên…</span></div>;
  return <main className={`app-shell mode-${mode} ${meditation ? 'is-meditating' : ''}`}>
    {mode === 'mini' ? <MiniView data={data} settings={settings} gateOpening={gateOpening} returning={miniReturning} onOpen={openFull} onMute={toggleMute} onHide={hideToTray}/> : <>
      <div className={`full-stage transition-${templeTransition} ${activeTool && !meditation ? 'has-ritual-panel' : ''}`}>
        <TempleArtwork incenseSticks={incenseSticks} smoke={settings.incenseSmoke} natureMotion={settings.natureMotion} onBell={() => ringBell()} onWoodblock={() => hitWoodblock(true)} onIncense={() => setActiveTool('incense')} onMeditation={() => setActiveTool('meditation')} bellRinging={bellRinging} woodblockHit={woodblockHit} incenseLit={incenseLit} arriving={templeTransition === 'arriving'} leaving={templeTransition === 'leaving'}/>
        <header className="sanctuary-bar" data-tauri-drag-region>
          <div className="brand"><LotusSeal/><div><strong>Chùa An Nhiên</strong><small>Một khoảng trú tâm giữa ngày</small></div></div>
          <p className="daily-reflection">“{quote}”</p>
          <div className="top-actions">
            <div className="merit-counter" aria-label={`${data.todayPoints} điểm tích phước hôm nay`}><Sparkles/><strong>{data.todayPoints}</strong><span>hôm nay</span></div>
            <button className="quiet-icon-button" onClick={toggleMute} aria-label={settings.muted ? 'Bật âm thanh' : 'Tắt âm thanh'}>{settings.muted ? <VolumeX/> : <Volume2/>}</button>
            <button className="quiet-icon-button" onClick={() => setShowSettings(true)} aria-label="Mở cài đặt"><SettingsIcon/></button>
            <button className="quiet-icon-button" onClick={() => void openMini()} aria-label="Trở về cổng chùa"><Minimize2/></button>
          </div>
        </header>

        {!meditation && <nav className="ritual-dock" aria-label="Các nghi thức an nhiên">
          <div className="ritual-dock-intro">
            <span>Gieo một khoảng yên</span>
            <div className="ritual-petals" aria-label={`${Object.values(ritualDone).filter(Boolean).length} trong 3 nghi thức đã thực hiện`}>
              <i className={ritualDone.incense ? 'complete' : ''}/><i className={ritualDone.woodblock ? 'complete' : ''}/><i className={ritualDone.meditation ? 'complete' : ''}/>
            </div>
          </div>
          <RitualButton label="Rung chuông" ariaLabel="Rung chuông chùa" icon={<Bell/>} onClick={() => ringBell()}/>
          <RitualButton label="Thắp nhang" icon={<Flame/>} active={activeTool === 'incense'} complete={ritualDone.incense} onClick={() => setActiveTool(activeTool === 'incense' ? null : 'incense')}/>
          <RitualButton label="Gõ mõ" icon={<CircleDot/>} active={activeTool === 'woodblock'} complete={ritualDone.woodblock} onClick={() => setActiveTool(activeTool === 'woodblock' ? null : 'woodblock')}/>
          <RitualButton label="Tĩnh tâm" icon={<Timer/>} active={activeTool === 'meditation'} complete={ritualDone.meditation} onClick={() => setActiveTool(activeTool === 'meditation' ? null : 'meditation')}/>
          <RitualButton label="Hành trình" icon={<BarChart3/>} active={activeTool === 'stats'} onClick={() => setActiveTool(activeTool === 'stats' ? null : 'stats')}/>
        </nav>}

        {!meditation && activeTool && <aside className={`ritual-panel ritual-panel-${activeTool}`} aria-label={`Bảng ${activeTool}`}>
          <button className="ritual-panel-close" onClick={() => setActiveTool(null)} aria-label="Đóng bảng nghi thức"><X/></button>
          {activeTool === 'incense' && <div className="ritual-panel-layout"><div className="ritual-panel-copy"><h2>Thắp nhang</h2><p>Dâng một hoặc ba nén nhang. Lần đầu mỗi ngày ghi nhận 10 điểm tích phước.</p></div><div className="ritual-panel-actions"><div className="segmented" aria-label="Chọn số nén nhang"><button aria-pressed={incenseChoice === 1} className={incenseChoice === 1 ? 'active' : ''} onClick={() => setIncenseChoice(1)}>1 nén</button><button aria-pressed={incenseChoice === 3} className={incenseChoice === 3 ? 'active' : ''} onClick={() => setIncenseChoice(3)}>3 nén</button></div><button className="primary-action" onClick={() => { lightIncense(); setActiveTool(null); }}>Thắp nhang</button></div></div>}
          {activeTool === 'woodblock' && <div className="ritual-panel-layout"><div className="ritual-panel-copy"><h2>Gõ mõ</h2><p>Mỗi tiếng mõ là một nhịp dừng. Bạn cũng có thể nhấn phím Space khi bảng này đóng.</p></div><div className="ritual-panel-actions"><button className="primary-action woodblock-action" onClick={() => hitWoodblock(true)}><CircleDot/>Gõ một tiếng mõ</button><button className={`auto-toggle ${autoWoodblock ? 'active' : ''}`} role="switch" aria-checked={autoWoodblock} onClick={() => setAutoWoodblock((v) => !v)}><i/>{autoWoodblock ? 'Đang gõ chậm tự động' : 'Bật nhịp mõ tự động'}</button></div></div>}
          {activeTool === 'meditation' && <div className="ritual-panel-layout"><div className="ritual-panel-copy"><h2>Tĩnh tâm</h2><p>Chọn một khoảng ngắn để rời mắt khỏi công việc và trở về với hơi thở.</p></div><div className="ritual-panel-actions"><div className="segmented" aria-label="Chọn thời gian tĩnh tâm">{[60,180,300].map((seconds) => <button key={seconds} aria-pressed={meditationChoice === seconds} className={meditationChoice === seconds ? 'active' : ''} onClick={() => setMeditationChoice(seconds)}>{seconds / 60} phút</button>)}</div><button className="primary-action calm" onClick={() => { startMeditation(); setActiveTool(null); }}>Bắt đầu tĩnh tâm</button></div></div>}
          {activeTool === 'stats' && <StatsPanel data={data}/>} 
        </aside>}
        {pointFloat && <div className="point-float">+1 Điểm tích phước</div>}
        {notice && <div className="toast"><Leaf/><span>{notice}</span></div>}
        {meditation && <MeditationOverlay remaining={meditation.remaining} total={meditation.total} paused={meditation.paused} quote={quote} onToggle={() => setMeditation((m) => m && ({ ...m, paused: !m.paused }))} onCancel={() => setMeditation(null)}/>} 
      </div>
      {showSettings && <SettingsPanel settings={settings} onChange={updateSettings} onClose={() => setShowSettings(false)} onResetPosition={() => { void resetWindowPosition(); showNotice('Đã đưa cửa sổ về vị trí mặc định.'); }} onResetData={() => { void clearState(); void applyNativeSettings(settingsRef.current, DEFAULT_SETTINGS); const fresh = createDefaultData(); setData(fresh); setSettings(DEFAULT_SETTINGS); settingsRef.current = DEFAULT_SETTINGS; showNotice('Dữ liệu đã được đặt lại.'); }}/>} 
    </>}
  </main>;
}

function MiniView({ data, settings, gateOpening, returning, onOpen, onMute, onHide }: { data: SerenityData; settings: Settings; gateOpening: boolean; returning: boolean; onOpen: () => void; onMute: () => void; onHide: () => void }) {
  return <section className={`mini-view ${gateOpening ? 'is-entering' : ''} ${returning ? 'is-returning' : ''}`}><div className="mini-drag" data-tauri-drag-region/><TempleArtwork mini gateOpening={gateOpening} returning={returning} natureMotion={settings.natureMotion} onGate={onOpen}/><div className="mini-score"><Sparkles/><span>Tích phước</span><strong>{data.todayPoints}</strong></div><div className="mini-actions"><button onClick={onMute} aria-label={settings.muted ? 'Bật âm thanh' : 'Tắt âm thanh'}>{settings.muted ? <VolumeX/> : <Volume2/>}</button><button onClick={onHide} aria-label="Thu vào khay hệ thống"><ChevronDown/></button></div><button className="open-hint" onClick={onOpen} aria-label="Ghé thăm chùa"><span>Bước qua cổng</span><Maximize2/></button></section>;
}

function RitualButton({ label, ariaLabel, icon, active = false, complete = false, onClick }: { label: string; ariaLabel?: string; icon: ReactNode; active?: boolean; complete?: boolean; onClick: () => void }) {
  return <button className={`ritual-button ${active ? 'active' : ''}`} aria-label={ariaLabel ?? label} aria-pressed={active} onClick={onClick}><span className="ritual-button-icon">{icon}</span><span>{label}</span>{complete && <i className="ritual-complete" aria-label="Đã thực hiện hôm nay"/>}</button>;
}

function LotusSeal() {
  return <span className="lotus-seal" aria-hidden="true"><svg viewBox="0 0 48 48"><path d="M24 38C15 34 10 27 11 18c6 1 11 4 13 10 2-6 7-9 13-10 1 9-4 16-13 20Z"/><path d="M24 29c-6-4-8-10-5-18 4 3 6 6 5 11 0-5 2-8 5-11 3 8 1 14-5 18Z"/><path d="M8 31c6 0 11 2 16 7 5-5 10-7 16-7"/></svg></span>;
}
