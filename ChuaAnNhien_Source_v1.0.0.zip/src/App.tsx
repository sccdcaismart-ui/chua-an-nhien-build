import { useCallback, useEffect, useRef, useState } from 'react';
import { Bell, ChevronDown, Flame, Leaf, Maximize2, Minimize2, Settings as SettingsIcon, Sparkles, Volume2, VolumeX } from 'lucide-react';
import { TempleArtwork } from './components/TempleArtwork';
import { SettingsPanel } from './components/SettingsPanel';
import { MeditationOverlay } from './components/MeditationOverlay';
import { StatsPanel } from './components/StatsPanel';
import { templeAudio } from './lib/audio';
import { dailyQuote } from './lib/quotes';
import { applyActivity, createDefaultData, localDateKey, rollover } from './lib/stats';
import { clearState, loadState, saveData, saveSettings } from './lib/storage';
import { DEFAULT_SETTINGS, type SerenityData, type Settings, type WindowMode } from './lib/types';
import { applyInitialNativeSettings, applyNativeSettings, hideToTray, installPositionMemory, listenForNativeEvents, resetWindowPosition, setWindowMode } from './lib/native';

type MeditationState = { total: number; remaining: number; paused: boolean };

export default function App() {
  const [ready, setReady] = useState(false);
  const [mode, setMode] = useState<WindowMode>('mini');
  const [data, setData] = useState<SerenityData>(() => createDefaultData());
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const settingsRef = useRef(settings);
  const modeRef = useRef(mode);
  const [gateOpening, setGateOpening] = useState(false);
  const [incenseChoice, setIncenseChoice] = useState<1 | 3>(1);
  const [incenseSticks, setIncenseSticks] = useState<0 | 1 | 3>(0);
  const [incenseLit, setIncenseLit] = useState(false);
  const [woodblockHit, setWoodblockHit] = useState(false);
  const [bellRinging, setBellRinging] = useState(false);
  const [autoWoodblock, setAutoWoodblock] = useState(false);
  const [pointFloat, setPointFloat] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [meditation, setMeditation] = useState<MeditationState | null>(null);
  const [meditationChoice, setMeditationChoice] = useState(60);
  const lastWoodblock = useRef(0);
  const quote = dailyQuote();

  useEffect(() => { settingsRef.current = settings; }, [settings]);
  useEffect(() => { modeRef.current = mode; }, [mode]);
  useEffect(() => {
    const updateVisibility = () => { document.body.dataset.hidden = String(document.hidden); };
    document.addEventListener('visibilitychange', updateVisibility);
    updateVisibility();
    return () => document.removeEventListener('visibilitychange', updateVisibility);
  }, []);

  const openFull = useCallback(async () => {
    setGateOpening(true);
    window.setTimeout(async () => {
      setMode('full'); setGateOpening(false); await setWindowMode('full');
    }, 520);
  }, []);
  const openMini = useCallback(async () => {
    setMeditation(null); setAutoWoodblock(false); setMode('mini');
    const saved = JSON.parse(localStorage.getItem('mini-window-position') ?? 'null') as { x: number; y: number } | null;
    await setWindowMode('mini', saved);
  }, []);

  const toggleMute = useCallback(() => {
    setSettings((current) => ({ ...current, muted: !current.muted }));
  }, []);

  useEffect(() => {
    let cleanupPosition: (() => void) | undefined;
    let cleanupEvents: (() => void)[] = [];
    void loadState().then(async (state) => {
      setData(state.data); setSettings(state.settings); settingsRef.current = state.settings;
      await applyInitialNativeSettings(state.settings);
      document.documentElement.style.setProperty('--motion-speed', String(1 / state.settings.effectSpeed));
      const saved = JSON.parse(localStorage.getItem('mini-window-position') ?? 'null') as { x: number; y: number } | null;
      await setWindowMode('mini', saved);
      cleanupPosition = await installPositionMemory((position) => {
        if (modeRef.current === 'mini') localStorage.setItem('mini-window-position', JSON.stringify(position));
      });
      cleanupEvents = await listenForNativeEvents({
        openFull, openMini, toggleMute,
        openSettings: () => { void openFull(); setShowSettings(true); },
        toggleAlwaysOnTop: () => setSettings((current) => {
          const next = { ...current, alwaysOnTop: !current.alwaysOnTop };
          void applyNativeSettings(current, next); settingsRef.current = next; return next;
        }),
        toggleAutostart: () => setSettings((current) => {
          const next = { ...current, autostart: !current.autostart };
          void applyNativeSettings(current, next); settingsRef.current = next; return next;
        })
      });
      setReady(true);
    });
    return () => { cleanupPosition?.(); cleanupEvents.forEach((fn) => fn()); };
  }, [openFull, openMini, toggleMute]);

  useEffect(() => { if (ready) void saveData(data); }, [data, ready]);
  useEffect(() => {
    if (!ready) return;
    void saveSettings(settings);
    templeAudio.setAmbient(settings);
    document.documentElement.style.setProperty('--motion-speed', String(1 / settings.effectSpeed));
  }, [settings, ready]);

  const updateSettings = (next: Settings) => {
    void applyNativeSettings(settingsRef.current, next);
    settingsRef.current = next;
    setSettings(next);
  };

  const showNotice = (message: string) => {
    setNotice(message); window.setTimeout(() => setNotice(null), 3600);
  };

  const hitWoodblock = useCallback((awardPoint = true) => {
    const now = performance.now();
    if (now - lastWoodblock.current < 300) return;
    lastWoodblock.current = now;
    templeAudio.woodblock(settingsRef.current);
    setWoodblockHit(true); window.setTimeout(() => setWoodblockHit(false), 260);
    if (awardPoint) {
      setData((current) => applyActivity(rollover(current), { type: 'woodblock', points: 1 }));
      setPointFloat(true); window.setTimeout(() => setPointFloat(false), 850);
    }
  }, []);

  const ringBell = useCallback((force = false) => {
    if (!templeAudio.bell(settingsRef.current, force)) return;
    setBellRinging(true); window.setTimeout(() => setBellRinging(false), 1350);
    setData((current) => applyActivity(rollover(current), { type: 'bell' }));
  }, []);

  const lightIncense = () => {
    const today = localDateKey();
    templeAudio.incense(settings);
    setIncenseSticks(incenseChoice); setIncenseLit(true); window.setTimeout(() => setIncenseLit(false), 900);
    setData((current) => {
      const fresh = rollover(current, today);
      const points = fresh.firstIncenseAwardedOn === today ? 0 : 10;
      const next = applyActivity(fresh, { type: 'incense', sticks: incenseChoice, points }, today);
      return { ...next, firstIncenseAwardedOn: today };
    });
    showNotice(currentIncenseMessage());
  };

  const currentIncenseMessage = () => {
    const options = ['Mong bạn giữ được một khoảng yên trong ngày.', 'Hãy để hơi thở đưa bạn trở về hiện tại.', 'Chúc bạn một ngày dịu dàng và sáng rõ.', quote];
    return options[(data.totalIncenseCount + incenseChoice) % options.length];
  };

  const startMeditation = () => {
    ringBell(true); setMeditation({ total: meditationChoice, remaining: meditationChoice, paused: false });
  };

  const completeMeditation = useCallback((total: number) => {
    ringBell(true);
    const today = localDateKey();
    const completionKey = `${today}-${total}`;
    const pointMap: Record<number, number> = { 60: 5, 180: 12, 300: 20 };
    setData((current) => {
      const fresh = rollover(current, today);
      const alreadyAwarded = fresh.completedMeditations.includes(completionKey);
      const next = applyActivity(fresh, { type: 'meditation', seconds: total, points: alreadyAwarded ? 0 : pointMap[total] ?? 5 }, today);
      return { ...next, completedMeditations: alreadyAwarded ? next.completedMeditations : [...next.completedMeditations, completionKey].slice(-90) };
    });
    setMeditation(null); showNotice('Bạn vừa dành một khoảng thời gian thật đẹp cho chính mình.');
  }, [ringBell]);

  useEffect(() => {
    if (!meditation || meditation.paused) return;
    const id = window.setInterval(() => setMeditation((current) => {
      if (!current || current.paused) return current;
      if (current.remaining <= 1) { window.clearInterval(id); window.setTimeout(() => completeMeditation(current.total), 0); return current; }
      return { ...current, remaining: current.remaining - 1 };
    }), 1000);
    return () => window.clearInterval(id);
  }, [meditation?.paused, meditation?.total, completeMeditation]);

  useEffect(() => {
    if (!autoWoodblock || mode !== 'full' || meditation) return;
    const id = window.setInterval(() => { if (!document.hidden) hitWoodblock(false); }, 1600);
    return () => window.clearInterval(id);
  }, [autoWoodblock, mode, meditation, hitWoodblock]);

  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement)?.tagName;
      if (event.key === 'Escape' && modeRef.current === 'full') { if (showSettings) setShowSettings(false); else void openMini(); }
      if (event.code === 'Space' && modeRef.current === 'full' && !meditation && !['INPUT', 'BUTTON', 'SELECT'].includes(tag)) { event.preventDefault(); hitWoodblock(true); }
    };
    window.addEventListener('keydown', keydown); return () => window.removeEventListener('keydown', keydown);
  }, [hitWoodblock, meditation, openMini, showSettings]);

  if (!ready) return <div className="loading-screen"><div className="loading-lotus">✦</div><span>Đang mở một khoảng an nhiên…</span></div>;
  return <main className={`app-shell mode-${mode} ${meditation ? 'is-meditating' : ''}`}>
    {mode === 'mini' ? <MiniView data={data} settings={settings} gateOpening={gateOpening} onOpen={openFull} onMute={toggleMute} onHide={hideToTray}/> : <>
      <div className="full-stage">
        <TempleArtwork incenseSticks={incenseSticks} smoke={settings.incenseSmoke} natureMotion={settings.natureMotion} onBell={() => ringBell()} onWoodblock={() => hitWoodblock(true)} bellRinging={bellRinging} woodblockHit={woodblockHit} incenseLit={incenseLit}/>
        <header className="topbar" data-tauri-drag-region><div className="brand"><span className="brand-mark">✦</span><div><strong>Chùa An Nhiên</strong><small>Một khoảng lặng giữa ngày</small></div></div><div className="top-actions"><div className="score-pill"><Sparkles/> <strong>{data.todayPoints}</strong><span>điểm tích phước</span></div><button className="icon-button glass" onClick={toggleMute} aria-label={settings.muted ? 'Bật âm thanh' : 'Tắt âm thanh'}>{settings.muted ? <VolumeX/> : <Volume2/>}</button><button className="icon-button glass" onClick={() => setShowSettings(true)} aria-label="Mở cài đặt"><SettingsIcon/></button><button className="icon-button glass" onClick={() => void openMini()} aria-label="Thu về cổng chùa"><Minimize2/></button></div></header>
        <div className="daily-message"><span>LỜI NHẮC HÔM NAY</span><p>{quote}</p></div>
        {pointFloat && <div className="point-float">+1 Điểm tích phước</div>}
        {notice && <div className="toast"><Leaf/><span>{notice}</span></div>}
        {meditation && <MeditationOverlay remaining={meditation.remaining} total={meditation.total} paused={meditation.paused} quote={quote} onToggle={() => setMeditation((m) => m && ({ ...m, paused: !m.paused }))} onCancel={() => setMeditation(null)}/>} 
      </div>
      {!meditation && <div className="control-deck">
        <section className="ritual-controls">
          <div className="control-card incense-card"><div className="control-icon flame"><Flame/></div><div className="control-copy"><span className="section-kicker">NHẸ LÒNG</span><h3>Thắp nhang</h3><p>Lần đầu mỗi ngày nhận 10 Điểm tích phước</p></div><div className="segmented small"><button className={incenseChoice === 1 ? 'active' : ''} onClick={() => setIncenseChoice(1)}>1 nén</button><button className={incenseChoice === 3 ? 'active' : ''} onClick={() => setIncenseChoice(3)}>3 nén</button></div><button className="primary-action" onClick={lightIncense}>Thắp nhang</button></div>
          <div className="control-card"><div className="control-icon wood">●</div><div className="control-copy"><span className="section-kicker">LẮNG NGHE</span><h3>Gõ mõ</h3><p>Nhấp vào mõ hoặc nhấn phím Space</p></div><button className={`auto-toggle ${autoWoodblock ? 'active' : ''}`} onClick={() => setAutoWoodblock((v) => !v)}><i/>{autoWoodblock ? 'Đang gõ tự động' : 'Gõ tự động chậm'}</button></div>
          <div className="control-card meditation-card"><div className="control-icon meditate">◌</div><div className="control-copy"><span className="section-kicker">TRỞ VỀ</span><h3>Tĩnh tâm</h3><p>Chọn khoảng thời gian phù hợp với bạn</p></div><div className="segmented">{[60,180,300].map((seconds) => <button key={seconds} className={meditationChoice === seconds ? 'active' : ''} onClick={() => setMeditationChoice(seconds)}>{seconds / 60} phút</button>)}</div><button className="primary-action calm" onClick={startMeditation}>Bắt đầu tĩnh tâm</button></div>
        </section>
        <StatsPanel data={data}/>
      </div>}
      {showSettings && <SettingsPanel settings={settings} onChange={updateSettings} onClose={() => setShowSettings(false)} onResetPosition={() => { void resetWindowPosition(); showNotice('Đã đưa cửa sổ về vị trí mặc định.'); }} onResetData={() => { void clearState(); void applyNativeSettings(settingsRef.current, DEFAULT_SETTINGS); const fresh = createDefaultData(); setData(fresh); setSettings(DEFAULT_SETTINGS); settingsRef.current = DEFAULT_SETTINGS; showNotice('Dữ liệu đã được đặt lại.'); }}/>} 
    </>}
  </main>;
}

function MiniView({ data, settings, gateOpening, onOpen, onMute, onHide }: { data: SerenityData; settings: Settings; gateOpening: boolean; onOpen: () => void; onMute: () => void; onHide: () => void }) {
  return <section className="mini-view"><div className="mini-drag" data-tauri-drag-region/><TempleArtwork mini gateOpening={gateOpening} natureMotion={settings.natureMotion} onGate={onOpen}/><div className="mini-score"><Sparkles/><span>Tích phước hôm nay</span><strong>{data.todayPoints}</strong></div><div className="mini-actions"><button onClick={onMute} aria-label={settings.muted ? 'Bật âm thanh' : 'Tắt âm thanh'}>{settings.muted ? <VolumeX/> : <Volume2/>}</button><button onClick={onHide} aria-label="Thu vào khay hệ thống"><ChevronDown/></button></div><button className="open-hint" onClick={onOpen}><span>Ghé thăm chùa</span><Maximize2/></button></section>;
}
