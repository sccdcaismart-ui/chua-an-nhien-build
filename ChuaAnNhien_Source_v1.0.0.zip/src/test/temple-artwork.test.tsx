import { render } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { TempleArtwork } from '../components/TempleArtwork';

describe('hoạt ảnh dâng lễ', () => {
  it('bàn giao mâm lễ từ tay sang vị trí cố định trên bàn thờ', () => {
    const { container, rerender } = render(
      <TempleArtwork
        offering="apples"
        ritualOffering="apples"
        ritualAnimation="offering"
        ritualOfferingPlaced={false}
      />
    );

    expect(container.querySelectorAll('.offering-plate')).toHaveLength(1);

    rerender(
      <TempleArtwork
        offering="apples"
        ritualOffering="apples"
        ritualAnimation="offering"
        ritualOfferingPlaced
      />
    );

    expect(container.querySelectorAll('.offering-plate')).toHaveLength(2);

    rerender(<TempleArtwork offering="apples" ritualAnimation={null} />);
    expect(container.querySelectorAll('.offering-plate')).toHaveLength(1);
  });
});
