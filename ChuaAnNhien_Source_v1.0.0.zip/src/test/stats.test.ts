import { describe, expect, it } from 'vitest';
import { applyActivity, createDefaultData, rollover } from '../lib/stats';

describe('hệ thống Điểm tích phước', () => {
  it('cộng điểm và thống kê gõ mõ chính xác', () => {
    const initial = createDefaultData('2026-07-20');
    const next = applyActivity(initial, { type: 'woodblock', points: 1 }, '2026-07-20');
    expect(next.todayPoints).toBe(1);
    expect(next.totalPoints).toBe(1);
    expect(next.totalWoodblockHits).toBe(1);
    expect(next.history[0].woodblockHits).toBe(1);
    expect(next.streakDays).toBe(1);
  });

  it('duy trì chuỗi ngày liên tiếp và ngắt chuỗi khi bỏ ngày', () => {
    const dayOne = applyActivity(createDefaultData('2026-07-18'), { type: 'bell' }, '2026-07-18');
    const dayTwo = applyActivity(rollover(dayOne, '2026-07-19'), { type: 'bell' }, '2026-07-19');
    expect(dayTwo.streakDays).toBe(2);
    const dayFour = applyActivity(rollover(dayTwo, '2026-07-21'), { type: 'bell' }, '2026-07-21');
    expect(dayFour.streakDays).toBe(1);
  });

  it('chỉ giữ lịch sử 30 ngày gần nhất', () => {
    let data = createDefaultData('2026-06-01');
    for (let day = 1; day <= 35; day += 1) {
      const date = new Date(2026, 5, day);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
      data = applyActivity(rollover(data, key), { type: 'bell' }, key);
    }
    expect(data.history).toHaveLength(30);
  });

  it('ghi nhận thời gian tĩnh tâm vào ngày hiện tại', () => {
    const next = applyActivity(createDefaultData('2026-07-20'), { type: 'meditation', seconds: 180, points: 12 }, '2026-07-20');
    expect(next.totalMeditationSeconds).toBe(180);
    expect(next.history[0].meditationSeconds).toBe(180);
    expect(next.todayPoints).toBe(12);
  });
});
