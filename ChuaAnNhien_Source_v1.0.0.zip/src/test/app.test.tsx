import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import App from '../App';

describe('luồng cửa sổ chính', () => {
  it('mở từ cổng mini sang toàn cảnh mà không tạo trang khác', async () => {
    render(<App />);
    const open = await screen.findByRole('button', { name: /ghé vào chùa/i });
    expect(screen.getByLabelText(/cổng chùa an nhiên/i)).toBeInTheDocument();
    fireEvent.click(open);
    await waitFor(() => expect(screen.getByRole('heading', { name: 'Thắp nhang' })).toBeInTheDocument(), { timeout: 1200 });
    expect(screen.getByRole('button', { name: 'Gõ mõ' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Rung chuông' })).toBeInTheDocument();
  });
});
