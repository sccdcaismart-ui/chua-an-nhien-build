import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import App from '../App';

describe('luồng cửa sổ chính', () => {
  it('mở từ cổng mini sang toàn cảnh mà không tạo trang khác', async () => {
    render(<App />);
    const open = await screen.findByRole('button', { name: /ghé thăm chùa/i });
    expect(screen.getByLabelText(/cổng chùa an nhiên/i)).toBeInTheDocument();
    fireEvent.click(open);
    const incenseActions = await screen.findAllByRole('button', { name: 'Thắp nhang' }, { timeout: 1500 });
    fireEvent.click(incenseActions[0]);
    expect(screen.getByRole('heading', { name: 'Thắp nhang' })).toBeInTheDocument();
    expect(screen.getAllByRole('button', { name: /Gõ mõ/ }).length).toBeGreaterThan(0);
    expect(screen.getByRole('button', { name: 'Rung chuông' })).toBeInTheDocument();
  });
});
