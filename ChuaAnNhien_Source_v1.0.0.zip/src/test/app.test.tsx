import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import App from '../App';

describe('luồng cửa sổ chính', () => {
  it('mở từ bàn thờ mini sang toàn cảnh mà không tạo trang khác', async () => {
    render(<App />);
    const open = await screen.findByRole('button', { name: /ghé thăm chùa/i });
    expect(screen.getByLabelText(/bàn thờ phật an nhiên/i)).toBeInTheDocument();
    fireEvent.click(open);
    const incenseActions = await screen.findAllByRole('button', { name: 'Thắp nhang' }, { timeout: 1500 });
    fireEvent.click(incenseActions[0]);
    expect(screen.getByRole('heading', { name: 'Thắp nhang' })).toBeInTheDocument();
    expect(screen.getAllByRole('button', { name: /Gõ mõ/ }).length).toBeGreaterThan(0);
    expect(screen.getByRole('button', { name: 'Rung chuông' })).toBeInTheDocument();
  });

  it('có lựa chọn dâng 1 hoặc 3 nén hương và dâng lễ trái cây', async () => {
    render(<App />);
    fireEvent.click(await screen.findByRole('button', { name: /ghé thăm chùa/i }));
    const incenseActions = await screen.findAllByRole('button', { name: 'Thắp nhang' }, { timeout: 1500 });
    fireEvent.click(incenseActions[0]);
    expect(screen.getByRole('button', { name: '1 nén' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '3 nén' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: /đóng bảng nghi thức/i }));
    fireEvent.click(screen.getByRole('button', { name: 'Dâng lễ' }));
    expect(screen.getByRole('button', { name: 'Ngũ quả' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Cam quýt' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Táo đỏ' })).toBeInTheDocument();
  });
});
