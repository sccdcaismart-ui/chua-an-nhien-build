import { describe, expect, it } from 'vitest';
import { dailyQuote, QUOTES } from '../lib/quotes';

describe('câu nhắc hằng ngày', () => {
  it('có ít nhất 30 câu và ổn định trong cùng ngày', () => {
    expect(QUOTES.length).toBeGreaterThanOrEqual(30);
    const morning = dailyQuote(new Date(2026, 6, 20, 8));
    const evening = dailyQuote(new Date(2026, 6, 20, 21));
    expect(morning).toBe(evening);
  });
});
