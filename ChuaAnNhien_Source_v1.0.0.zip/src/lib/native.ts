import { invoke } from '@tauri-apps/api/core';
import { emit, listen, type UnlistenFn } from '@tauri-apps/api/event';
import { availableMonitors, getCurrentWindow, LogicalSize, PhysicalPosition } from '@tauri-apps/api/window';
import { enable, disable } from '@tauri-apps/plugin-autostart';
import type { Settings, WindowMode } from './types';

export const isTauri = () => '__TAURI_INTERNALS__' in window;

export async function setWindowMode(mode: WindowMode, savedPosition?: { x: number; y: number } | null) {
  document.body.dataset.mode = mode;
  if (!isTauri()) return;
  const window = getCurrentWindow();
  const size = mode === 'mini' ? new LogicalSize(300, 360) : new LogicalSize(960, 650);
  await window.setSize(size);
  await window.setResizable(false);
  const monitors = await availableMonitors();
  const outer = await window.outerSize();
  const currentPosition = await window.outerPosition().catch(() => new PhysicalPosition(0, 0));
  const current = monitors.find((monitor) => {
    const a = monitor.workArea;
    return currentPosition.x >= a.position.x && currentPosition.x < a.position.x + a.size.width && currentPosition.y >= a.position.y && currentPosition.y < a.position.y + a.size.height;
  }) ?? monitors[0];
  if (current) {
    const area = current.workArea;
    let x: number;
    let y: number;
    if (mode === 'full') {
      x = area.position.x + Math.round((area.size.width - outer.width) / 2);
      y = area.position.y + Math.round((area.size.height - outer.height) / 2);
    } else {
      const savedMonitor = savedPosition && monitors.find((monitor) => {
        const a = monitor.workArea;
        return savedPosition.x + 40 >= a.position.x && savedPosition.x < a.position.x + a.size.width && savedPosition.y + 40 >= a.position.y && savedPosition.y < a.position.y + a.size.height;
      });
      const target = savedMonitor?.workArea ?? area;
      x = savedPosition && savedMonitor ? savedPosition.x : target.position.x + target.size.width - outer.width - 16;
      y = savedPosition && savedMonitor ? savedPosition.y : target.position.y + target.size.height - outer.height - 16;
      x = Math.max(target.position.x, Math.min(x, target.position.x + target.size.width - outer.width));
      y = Math.max(target.position.y, Math.min(y, target.position.y + target.size.height - outer.height));
    }
    await window.setPosition(new PhysicalPosition(x, y));
  }
  await window.show();
  if (mode === 'full') await window.setFocus();
}

export async function hideToTray() {
  if (isTauri()) await getCurrentWindow().hide();
}

export async function resetWindowPosition() {
  localStorage.removeItem('mini-window-position');
}

export async function applyNativeSettings(previous: Settings, next: Settings) {
  if (!isTauri()) return;
  if (previous.alwaysOnTop !== next.alwaysOnTop) {
    await getCurrentWindow().setAlwaysOnTop(next.alwaysOnTop);
  }
  if (previous.autostart !== next.autostart) {
    if (next.autostart) await enable(); else await disable();
  }
  await emit('settings-changed', next);
}

export async function applyInitialNativeSettings(settings: Settings) {
  if (isTauri()) await getCurrentWindow().setAlwaysOnTop(settings.alwaysOnTop);
}

export function listenForNativeEvents(callbacks: {
  openFull: () => void;
  openMini: () => void;
  toggleMute: () => void;
  openSettings: () => void;
  toggleAlwaysOnTop: () => void;
  toggleAutostart: () => void;
}): Promise<UnlistenFn[]> {
  if (!isTauri()) return Promise.resolve([]);
  return Promise.all([
    listen('tray-open-full', callbacks.openFull),
    listen('tray-open-mini', callbacks.openMini),
    listen('tray-toggle-mute', callbacks.toggleMute),
    listen('tray-open-settings', callbacks.openSettings)
    ,listen('tray-toggle-always-on-top', callbacks.toggleAlwaysOnTop)
    ,listen('tray-toggle-autostart', callbacks.toggleAutostart)
  ]);
}

export async function installPositionMemory(onPosition: (position: { x: number; y: number }) => void) {
  if (!isTauri()) return () => undefined;
  let timer: number | undefined;
  return getCurrentWindow().onMoved(({ payload }) => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => onPosition({ x: payload.x, y: payload.y }), 250);
  });
}
