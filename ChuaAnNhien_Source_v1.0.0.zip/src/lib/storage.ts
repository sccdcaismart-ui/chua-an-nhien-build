import { load } from '@tauri-apps/plugin-store';
import { DEFAULT_SETTINGS, type SerenityData, type Settings } from './types';
import { createDefaultData, rollover } from './stats';

const isTauri = () => '__TAURI_INTERNALS__' in window;
const KEYS = { data: 'serenity-data', settings: 'settings' } as const;

async function read<T>(key: string): Promise<T | null> {
  if (isTauri()) {
    const store = await load('an-nhien.json', { autoSave: 120 });
    return (await store.get<T>(key)) ?? null;
  }
  const raw = localStorage.getItem(key);
  return raw ? JSON.parse(raw) as T : null;
}

async function write<T>(key: string, value: T): Promise<void> {
  if (isTauri()) {
    const store = await load('an-nhien.json', { autoSave: 120 });
    await store.set(key, value);
    await store.save();
  } else localStorage.setItem(key, JSON.stringify(value));
}

export async function loadState(): Promise<{ data: SerenityData; settings: Settings }> {
  const [storedData, storedSettings] = await Promise.all([
    read<SerenityData>(KEYS.data), read<Settings>(KEYS.settings)
  ]);
  return {
    data: rollover(storedData ?? createDefaultData()),
    settings: { ...DEFAULT_SETTINGS, ...(storedSettings ?? {}) }
  };
}

export const saveData = (data: SerenityData) => write(KEYS.data, data);
export const saveSettings = (settings: Settings) => write(KEYS.settings, settings);
export async function clearState() {
  if (isTauri()) {
    const store = await load('an-nhien.json', { autoSave: 120 });
    await store.clear();
    await store.save();
  } else {
    localStorage.removeItem(KEYS.data);
    localStorage.removeItem(KEYS.settings);
  }
}
