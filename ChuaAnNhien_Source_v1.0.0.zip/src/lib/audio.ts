import type { Settings } from './types';

class TempleAudio {
  private context: AudioContext | null = null;
  private ambient: { source: AudioBufferSourceNode; gain: GainNode } | null = null;
  private bellBusyUntil = 0;

  private ctx() {
    this.context ??= new AudioContext();
    if (this.context.state === 'suspended') void this.context.resume();
    return this.context;
  }

  private volume(settings: Settings, channel = 1) {
    return settings.muted ? 0 : settings.masterVolume * channel;
  }

  woodblock(settings: Settings) {
    const ctx = this.ctx();
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    const osc = ctx.createOscillator();
    const overtone = ctx.createOscillator();
    osc.type = 'sine'; osc.frequency.setValueAtTime(245, now); osc.frequency.exponentialRampToValueAtTime(135, now + 0.16);
    overtone.type = 'triangle'; overtone.frequency.setValueAtTime(680, now); overtone.frequency.exponentialRampToValueAtTime(320, now + 0.08);
    const level = this.volume(settings, settings.woodblockVolume);
    gain.gain.setValueAtTime(Math.max(0.0001, level * 0.34), now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);
    osc.connect(gain); overtone.connect(gain); gain.connect(ctx.destination);
    osc.start(now); overtone.start(now); osc.stop(now + 0.23); overtone.stop(now + 0.12);
  }

  bell(settings: Settings, force = false) {
    const ctx = this.ctx();
    const now = ctx.currentTime;
    if (!force && now < this.bellBusyUntil) return false;
    this.bellBusyUntil = now + 1.3;
    const master = ctx.createGain();
    const level = this.volume(settings, settings.bellVolume);
    master.gain.setValueAtTime(Math.max(0.0001, level * 0.2), now);
    master.gain.exponentialRampToValueAtTime(0.0001, now + 4.4);
    [196, 293.7, 392, 510].forEach((frequency, index) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = index % 2 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(frequency, now);
      g.gain.value = 1 / (index + 1);
      osc.connect(g); g.connect(master); osc.start(now); osc.stop(now + 4.5);
    });
    master.connect(ctx.destination);
    return true;
  }

  incense(settings: Settings) {
    const ctx = this.ctx();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(520, now); osc.frequency.exponentialRampToValueAtTime(820, now + 0.12);
    gain.gain.setValueAtTime(Math.max(0.0001, this.volume(settings, 0.1)), now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.36);
  }

  setAmbient(settings: Settings) {
    const shouldPlay = settings.ambientEnabled && !settings.muted && settings.ambientVolume > 0;
    if (!shouldPlay) {
      if (this.ambient) {
        this.ambient.gain.gain.linearRampToValueAtTime(0.0001, this.ctx().currentTime + 0.4);
        this.ambient.source.stop(this.ctx().currentTime + 0.45);
        this.ambient = null;
      }
      return;
    }
    if (this.ambient) {
      this.ambient.gain.gain.setTargetAtTime(this.volume(settings, settings.ambientVolume) * 0.16, this.ctx().currentTime, 0.2);
      return;
    }
    const ctx = this.ctx();
    const length = ctx.sampleRate * 3;
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let last = 0;
    for (let i = 0; i < length; i += 1) {
      const white = Math.random() * 2 - 1;
      last = last * 0.997 + white * 0.003;
      data[i] = last * 3.2;
    }
    const source = ctx.createBufferSource();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();
    filter.type = 'lowpass'; filter.frequency.value = 900;
    gain.gain.value = this.volume(settings, settings.ambientVolume) * 0.16;
    source.buffer = buffer; source.loop = true;
    source.connect(filter); filter.connect(gain); gain.connect(ctx.destination); source.start();
    this.ambient = { source, gain };
  }
}

export const templeAudio = new TempleAudio();
