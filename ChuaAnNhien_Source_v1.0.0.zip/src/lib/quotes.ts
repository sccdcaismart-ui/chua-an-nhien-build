export const QUOTES = [
  'Tâm an thì mọi việc sẽ dần sáng rõ.',
  'Chậm lại một chút để lắng nghe chính mình.',
  'Buông điều không thể giữ, trân trọng điều đang có.',
  'Một phút bình tâm cũng là một bước trở về.',
  'Hôm nay hãy đối xử dịu dàng với chính mình.',
  'Thở sâu, rồi để lòng mình nhẹ thêm một chút.',
  'Bình yên bắt đầu từ một khoảnh khắc có mặt.',
  'Mỗi ngày mới là một cơ hội để sống hiền hòa hơn.',
  'Không cần vội, hoa nở đúng mùa của hoa.',
  'Hãy giữ lòng ấm ngay cả trong ngày nhiều mây.',
  'Lắng nghe là một cách trao nhau sự bình yên.',
  'Đi chậm không có nghĩa là dừng lại.',
  'Một hơi thở sâu có thể mở ra khoảng trời rộng.',
  'Điều giản dị hôm nay cũng đáng được biết ơn.',
  'Cho mình nghỉ một chút cũng là đang tiến về phía trước.',
  'Sự dịu dàng luôn có chỗ trong một ngày bận rộn.',
  'Giữ tâm sáng, bước chân sẽ tự nhiên vững vàng.',
  'Không phải mọi câu hỏi đều cần lời đáp ngay.',
  'Thảnh thơi là khi ta thôi chống lại phút giây này.',
  'Hãy để ngày hôm nay đủ đầy theo cách riêng của nó.',
  'Yên lặng một chút để nghe điều lòng mình đang nói.',
  'Mỗi việc nhỏ làm bằng sự chú tâm đều có ý nghĩa.',
  'Nhẹ với người cũng là nhẹ với mình.',
  'Bầu trời vẫn rộng sau những ngày nhiều lo nghĩ.',
  'Hít vào bình an, thở ra những điều nặng lòng.',
  'Tử tế với chính mình là khởi đầu của bình yên.',
  'Mọi cảm xúc đều có thể đi qua khi ta cho chúng thời gian.',
  'Giữa bộn bề, mình vẫn có thể chọn một nhịp thở chậm.',
  'Bình tâm không phải đứng yên, mà là bước đi sáng rõ.',
  'Hôm nay, chỉ cần làm tốt điều đang ở trước mắt.',
  'Sự hiện diện trọn vẹn là món quà giản dị nhất.',
  'Một tâm hồn nhẹ nhàng nhìn đâu cũng thấy khoảng thở.'
] as const;

export function dailyQuote(date = new Date()): string {
  const stamp = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
  return QUOTES[Math.floor(stamp / 86_400_000) % QUOTES.length];
}
