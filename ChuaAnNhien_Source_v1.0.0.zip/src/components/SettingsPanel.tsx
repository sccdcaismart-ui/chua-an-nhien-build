import { Bell, CloudSun, Flame, Leaf, MonitorUp, RotateCcw, Settings as SettingsIcon, Volume2, VolumeX, X } from 'lucide-react';
import type { Settings } from '../lib/types';

type Props = {
  settings: Settings;
  onChange: (next: Settings) => void;
  onClose: () => void;
  onResetPosition: () => void;
  onResetData: () => void;
};

function Slider({ label, value, icon, onChange }: { label: string; value: number; icon: React.ReactNode; onChange: (value: number) => void }) {
  return <label className="setting-row slider-row"><span className="setting-label">{icon}<span>{label}</span></span><span className="slider-wrap"><input type="range" min="0" max="1" step="0.01" value={value} onChange={(e) => onChange(Number(e.target.value))}/><output>{Math.round(value * 100)}%</output></span></label>;
}

function Toggle({ label, description, checked, icon, onChange }: { label: string; description?: string; checked: boolean; icon: React.ReactNode; onChange: (value: boolean) => void }) {
  return <label className="setting-row toggle-row"><span className="setting-label">{icon}<span>{label}{description && <small>{description}</small>}</span></span><span className={`switch ${checked ? 'on' : ''}`}><input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)}/><i/></span></label>;
}

export function SettingsPanel({ settings, onChange, onClose, onResetPosition, onResetData }: Props) {
  const set = <K extends keyof Settings>(key: K, value: Settings[K]) => onChange({ ...settings, [key]: value });
  const confirmReset = () => {
    if (window.confirm('Đặt lại toàn bộ Điểm an nhiên và lịch sử? Hành động này không thể hoàn tác.')) onResetData();
  };
  return <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
    <section className="settings-panel" role="dialog" aria-modal="true" aria-labelledby="settings-title">
      <header><div><span className="section-kicker">KHÔNG GIAN CỦA BẠN</span><h2 id="settings-title"><SettingsIcon size={22}/> Cài đặt</h2></div><button className="icon-button" onClick={onClose} aria-label="Đóng cài đặt"><X/></button></header>
      <div className="settings-scroll">
        <h3>Âm thanh</h3>
        <Slider label="Âm lượng tổng" value={settings.masterVolume} icon={settings.muted ? <VolumeX/> : <Volume2/>} onChange={(v) => set('masterVolume', v)}/>
        <Slider label="Âm lượng mõ" value={settings.woodblockVolume} icon={<span className="mini-symbol">●</span>} onChange={(v) => set('woodblockVolume', v)}/>
        <Slider label="Âm lượng chuông" value={settings.bellVolume} icon={<Bell/>} onChange={(v) => set('bellVolume', v)}/>
        <Slider label="Âm thanh môi trường" value={settings.ambientVolume} icon={<Leaf/>} onChange={(v) => set('ambientVolume', v)}/>
        <Toggle label="Tắt toàn bộ âm thanh" checked={settings.muted} icon={<VolumeX/>} onChange={(v) => set('muted', v)}/>
        <Toggle label="Gió và tiếng thiên nhiên" description="Chỉ phát sau khi bạn bật" checked={settings.ambientEnabled} icon={<CloudSun/>} onChange={(v) => set('ambientEnabled', v)}/>

        <h3>Hình ảnh</h3>
        <label className="setting-row slider-row"><span className="setting-label"><MonitorUp/><span>Tốc độ hiệu ứng</span></span><span className="slider-wrap"><input type="range" min="0.5" max="1.5" step="0.1" value={settings.effectSpeed} onChange={(e) => set('effectSpeed', Number(e.target.value))}/><output>{settings.effectSpeed.toFixed(1)}×</output></span></label>
        <Toggle label="Khói nhang" checked={settings.incenseSmoke} icon={<Flame/>} onChange={(v) => set('incenseSmoke', v)}/>
        <Toggle label="Mây và lá chuyển động" checked={settings.natureMotion} icon={<Leaf/>} onChange={(v) => set('natureMotion', v)}/>

        <h3>Windows</h3>
        <Toggle label="Khởi động cùng Windows" checked={settings.autostart} icon={<MonitorUp/>} onChange={(v) => set('autostart', v)}/>
        <Toggle label="Luôn nổi trên cùng" checked={settings.alwaysOnTop} icon={<MonitorUp/>} onChange={(v) => set('alwaysOnTop', v)}/>
        <button className="setting-action" onClick={onResetPosition}><RotateCcw/> Đặt lại vị trí cửa sổ</button>
        <button className="setting-action danger" onClick={confirmReset}><RotateCcw/> Đặt lại dữ liệu và điểm</button>
      </div>
    </section>
  </div>;
}
