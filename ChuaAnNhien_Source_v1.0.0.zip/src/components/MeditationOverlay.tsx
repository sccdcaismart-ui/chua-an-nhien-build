import { Pause, Play, X } from 'lucide-react';

type Props = {
  remaining: number;
  total: number;
  paused: boolean;
  quote: string;
  onToggle: () => void;
  onCancel: () => void;
};

const clock = (seconds: number) => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;

export function MeditationOverlay({ remaining, total, paused, quote, onToggle, onCancel }: Props) {
  const progress = Math.max(0, Math.min(1, 1 - remaining / total));
  return <div className="meditation-overlay" role="timer" aria-live="polite">
    <div className="breathing-orb"><div className="orbit" style={{ '--progress': progress } as React.CSSProperties}/><div className="breathing-core"><span>{paused ? 'Đang tạm dừng' : 'Hít thở nhẹ nhàng'}</span><strong>{clock(remaining)}</strong><small>Đã hoàn thành {Math.round(progress * 100)}%</small></div></div>
    <blockquote>“{quote}”</blockquote>
    <div className="meditation-actions"><button onClick={onToggle}>{paused ? <Play/> : <Pause/>}{paused ? 'Tiếp tục' : 'Tạm dừng'}</button><button className="ghost" onClick={onCancel}><X/> Kết thúc sớm</button></div>
  </div>;
}
