import { Pause, Play, X } from 'lucide-react';

type Props = {
  remaining: number;
  total: number;
  paused: boolean;
  quote: string;
  onToggle: () => void;
  onCancel: () => void;
};

const clock = (seconds: number) => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;

export function MeditationOverlay({ remaining, total, paused, quote, onToggle, onCancel }: Props) {
  const progress = Math.max(0, Math.min(1, 1 - remaining / total));
  return <div className="meditation-overlay" role="timer" aria-live="polite">
    <div className={`meditation-focus ${paused ? 'is-paused' : ''}`}>
      <svg className="breathing-lotus" viewBox="0 0 160 112" aria-hidden="true">
        <path className="lotus-petal lotus-petal-center" d="M80 91C60 70 61 43 80 19c19 24 20 51 0 72Z"/>
        <path className="lotus-petal lotus-petal-left" d="M76 94C49 91 31 73 28 45c27 6 44 22 48 49Z"/>
        <path className="lotus-petal lotus-petal-right" d="M84 94c27-3 45-21 48-49-27 6-44 22-48 49Z"/>
        <path className="lotus-petal lotus-petal-low" d="M80 97C54 104 29 94 17 72c29-2 50 6 63 25Zm0 0c26 7 51-3 63-25-29-2-50 6-63 25Z"/>
        <path className="lotus-waterline" d="M27 103h106"/>
      </svg>
      <span>{paused ? 'Đang tạm dừng' : 'Thở vào · thở ra'}</span>
      <strong>{clock(remaining)}</strong>
      <div className="meditation-progress" aria-label={`Đã hoàn thành ${Math.round(progress * 100)}%`}><i style={{ transform: `scaleX(${progress})` }}/></div>
      <small>Đã hoàn thành {Math.round(progress * 100)}%</small>
    </div>
    <blockquote>“{quote}”</blockquote>
    <div className="meditation-actions"><button onClick={onToggle}>{paused ? <Play/> : <Pause/>}{paused ? 'Tiếp tục' : 'Tạm dừng'}</button><button className="ghost" onClick={onCancel}><X/> Kết thúc sớm</button></div>
  </div>;
}
