import { Clock3, Flame, Sparkles } from 'lucide-react';
import type { SerenityData } from '../lib/types';
import { todayMeditation } from '../lib/stats';

const minutes = (seconds: number) => seconds < 60 ? `${seconds} giây` : `${Math.floor(seconds / 60)} phút`;

export function StatsPanel({ data }: { data: SerenityData }) {
  return <div className="stats-panel">
    <div className="stats-heading"><div><h2>Hành trình an nhiên</h2><p>Những khoảng dừng bạn đã dành cho chính mình.</p></div><div className="lotus-mark"><Sparkles/></div></div>
    <div className="score-hero"><span>Hôm nay</span><strong>{data.todayPoints}</strong><small>điểm tích phước</small></div>
    <div className="stat-grid">
      <div><Sparkles/><span>Tổng điểm tích phước</span><strong>{data.totalPoints}</strong></div>
      <div><Flame/><span>Chuỗi ngày ghé chùa</span><strong>{data.streakDays} ngày</strong></div>
      <div className="wide"><Clock3/><span>Thời gian tĩnh tâm hôm nay</span><strong>{minutes(todayMeditation(data))}</strong></div>
    </div>
    <div className="tiny-history"><span>30 ngày gần nhất</span><div>{Array.from({ length: 30 }, (_, index) => {
      const item = data.history[data.history.length - 30 + index];
      const intensity = item ? Math.min(4, Math.ceil(item.points / 6)) : 0;
      return <i key={index} data-level={intensity} title={item ? `${item.date}: ${item.points} Điểm tích phước` : 'Chưa có hoạt động'}/>;
    })}</div></div>
  </div>;
}
