import { Clock3, Flame, Sparkles } from 'lucide-react';
import type { SerenityData } from '../lib/types';
import { todayMeditation } from '../lib/stats';

const minutes = (seconds: number) => seconds < 60 ? `${seconds} giây` : `${Math.floor(seconds / 60)} phút`;

export function StatsPanel({ data }: { data: SerenityData }) {
  return <aside className="stats-panel">
    <div className="stats-heading"><div><span className="section-kicker">HÀNH TRÌNH BÌNH TÂM</span><h2>Điểm an nhiên</h2></div><div className="lotus-mark">✦</div></div>
    <div className="score-hero"><span>Hôm nay</span><strong>{data.todayPoints}</strong><small>điểm</small></div>
    <div className="stat-grid">
      <div><Sparkles/><span>Tổng điểm</span><strong>{data.totalPoints}</strong></div>
      <div><Flame/><span>Chuỗi ngày</span><strong>{data.streakDays} ngày</strong></div>
      <div className="wide"><Clock3/><span>Tĩnh tâm hôm nay</span><strong>{minutes(todayMeditation(data))}</strong></div>
    </div>
    <div className="tiny-history"><span>30 ngày gần nhất</span><div>{Array.from({ length: 30 }, (_, index) => {
      const item = data.history[data.history.length - 30 + index];
      const intensity = item ? Math.min(4, Math.ceil(item.points / 6)) : 0;
      return <i key={index} data-level={intensity} title={item ? `${item.date}: ${item.points} điểm` : 'Chưa có hoạt động'}/>;
    })}</div></div>
  </aside>;
}
