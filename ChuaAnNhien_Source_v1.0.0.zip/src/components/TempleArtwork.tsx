import type { CSSProperties } from 'react';
import type { FruitOffering } from '../lib/types';

type RitualAnimation = 'incense' | 'offering' | null;

type Props = {
  mini?: boolean;
  gateOpening?: boolean;
  returning?: boolean;
  incenseSticks?: 0 | 1 | 3;
  ritualIncenseSticks?: 1 | 3;
  offering?: FruitOffering | null;
  ritualOffering?: FruitOffering;
  ritualAnimation?: RitualAnimation;
  smoke?: boolean;
  natureMotion?: boolean;
  onGate?: () => void;
  onBell?: () => void;
  onWoodblock?: () => void;
  onIncense?: () => void;
  onOffering?: () => void;
  onMeditation?: () => void;
  bellRinging?: boolean;
  woodblockHit?: boolean;
  incenseLit?: boolean;
  arriving?: boolean;
  leaving?: boolean;
};

export function TempleArtwork({
  mini = false,
  gateOpening,
  returning,
  incenseSticks = 0,
  ritualIncenseSticks = 1,
  offering = null,
  ritualOffering = 'five-fruit',
  ritualAnimation = null,
  smoke = true,
  natureMotion = true,
  onGate,
  onBell,
  onWoodblock,
  onIncense,
  onOffering,
  onMeditation,
  bellRinging,
  woodblockHit,
  incenseLit,
  arriving,
  leaving
}: Props) {
  const cls = [
    'temple-artwork',
    mini ? 'is-mini mini-altar-artwork' : 'is-full altar-room-artwork',
    natureMotion ? '' : 'motion-off',
    arriving ? 'is-arriving' : '',
    leaving ? 'is-leaving' : '',
    returning ? 'is-returning' : ''
  ].filter(Boolean).join(' ');

  if (mini) {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" className={cls} viewBox="0 0 300 360" role="img" aria-label="Bàn thờ Phật An Nhiên ở góc màn hình">
        <ArtworkDefs/>
        <MiniAltar
          opening={gateOpening}
          returning={returning}
          incenseSticks={incenseSticks}
          offering={offering}
          smoke={smoke}
          onOpen={onGate}
        />
      </svg>
    );
  }

  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={cls} viewBox="0 0 960 650" role="img" aria-label="Không gian bàn thờ Phật Chùa An Nhiên">
      <ArtworkDefs/>
      <AltarRoomBackground/>
      <FullAltar
        incenseSticks={ritualAnimation === 'incense' ? 0 : incenseSticks}
        offering={ritualAnimation === 'offering' ? null : offering}
        smoke={smoke}
        incenseLit={incenseLit}
        onIncense={onIncense}
        onOffering={onOffering}
      />
      <Bell ringing={bellRinging} onClick={onBell}/>
      <Woodblock hit={woodblockHit} onClick={onWoodblock}/>
      <MeditationMat onClick={onMeditation}/>
      <RitualHands animation={ritualAnimation} incenseSticks={ritualIncenseSticks} offering={ritualOffering}/>
    </svg>
  );
}

function ArtworkDefs() {
  return <defs>
    <linearGradient id="altarWall" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f3d9ad"/><stop offset=".58" stopColor="#c98f62"/><stop offset="1" stopColor="#7a4633"/></linearGradient>
    <linearGradient id="altarFloor" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#74402f"/><stop offset="1" stopColor="#2e211c"/></linearGradient>
    <linearGradient id="altarWood" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#8f4328"/><stop offset=".48" stopColor="#5d291f"/><stop offset="1" stopColor="#2f1715"/></linearGradient>
    <linearGradient id="altarWoodLight" x1="0" y1="0" x2="1" y2="0"><stop stopColor="#c56d35"/><stop offset=".5" stopColor="#8a3f27"/><stop offset="1" stopColor="#5b271e"/></linearGradient>
    <linearGradient id="altarGold" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#fff0a3"/><stop offset=".42" stopColor="#efbd4e"/><stop offset="1" stopColor="#b96721"/></linearGradient>
    <linearGradient id="altarCeramic" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f0d778"/><stop offset="1" stopColor="#96722e"/></linearGradient>
    <linearGradient id="robe" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#ffe77b"/><stop offset=".5" stopColor="#e9a92f"/><stop offset="1" stopColor="#a85a1e"/></linearGradient>
    <linearGradient id="skin" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f6c79f"/><stop offset="1" stopColor="#c97d5d"/></linearGradient>
    <linearGradient id="buddhaSkin" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f8d183"/><stop offset="1" stopColor="#d8943e"/></linearGradient>
    <radialGradient id="altarHalo"><stop stopColor="#fff8c5" stopOpacity=".95"/><stop offset=".45" stopColor="#f8cf64" stopOpacity=".42"/><stop offset="1" stopColor="#e28a2e" stopOpacity="0"/></radialGradient>
    <radialGradient id="lampGlow"><stop stopColor="#fff8b4"/><stop offset=".38" stopColor="#ffbd38"/><stop offset="1" stopColor="#e96619"/></radialGradient>
    <filter id="altarShadow" x="-30%" y="-30%" width="160%" height="180%"><feDropShadow dx="0" dy="9" stdDeviation="7" floodColor="#2b1110" floodOpacity=".42"/></filter>
    <filter id="miniShadow" x="-40%" y="-30%" width="180%" height="190%"><feDropShadow dx="0" dy="8" stdDeviation="7" floodColor="#20110d" floodOpacity=".48"/></filter>
    <filter id="goldGlow" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="10"/></filter>
    <filter id="emberGlow" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="4"/></filter>
  </defs>;
}

function MiniAltar({ opening, returning, incenseSticks, offering, smoke, onOpen }: {
  opening?: boolean;
  returning?: boolean;
  incenseSticks: 0 | 1 | 3;
  offering: FruitOffering | null;
  smoke?: boolean;
  onOpen?: () => void;
}) {
  return <g
    className={`mini-altar interactive ${opening ? 'opening' : ''} ${returning ? 'returning' : ''}`}
    role="button"
    tabIndex={0}
    onClick={onOpen}
    onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onOpen?.()}
    aria-label="Mở không gian Chùa An Nhiên"
  >
    <ellipse cx="150" cy="337" rx="112" ry="13" fill="#24140f" opacity=".34"/>
    <g className="mini-altar-glow"><ellipse cx="150" cy="155" rx="102" ry="123" fill="url(#altarHalo)" opacity=".48" filter="url(#goldGlow)"/></g>
    <g filter="url(#miniShadow)">
      <path d="M48 82Q150 12 252 82L269 93Q150 67 31 93Z" fill="url(#altarWood)"/>
      <path d="M38 84Q150 48 262 84L249 100Q150 76 51 100Z" fill="url(#altarGold)"/>
      <path d="M58 102H242V263H58Z" fill="url(#altarWood)" stroke="#e2a849" strokeWidth="4"/>
      <path d="M70 115H230V245H70Z" fill="#5a2b23" stroke="#f0c569" strokeWidth="3"/>
      <path d="M57 263H243L260 287H40Z" fill="url(#altarWoodLight)"/>
      <path d="M31 287H269V316H31Z" fill="url(#altarWood)" stroke="#c77b38" strokeWidth="3"/>
      <path d="M45 316H255L243 337H57Z" fill="#54251d"/>
      <rect x="104" y="91" width="92" height="28" rx="5" fill="url(#altarGold)"/>
      <text x="150" y="110" textAnchor="middle" fill="#4a241b" fontFamily="var(--font-display)" fontSize="13" fontWeight="700">AN NHIÊN</text>
      <MiniLamp x={76}/><MiniLamp x={224}/>
      <BuddhaFigure x={150} y={221} scale={.82}/>
      <FlowerVase x={82} y={260} scale={.44}/>
      <FlowerVase x={218} y={260} scale={.44} mirrored/>
      {offering && <OfferingPlate offering={offering} x={150} y={258} scale={.43}/>} 
      <IncenseBowl sticks={incenseSticks} x={150} y={280} scale={.49} smoke={smoke}/>
    </g>
    <g className="mini-sparkles" fill="#ffe389"><circle cx="42" cy="170" r="2"/><circle cx="263" cy="138" r="2.5"/><circle cx="247" cy="244" r="1.8"/></g>
  </g>;
}

function MiniLamp({ x }: { x: number }) {
  return <g transform={`translate(${x} 135)`} className="altar-lamp"><ellipse rx="25" ry="28" fill="#ffbc35" opacity=".16" filter="url(#goldGlow)"/><path d="M-7-12H7L11-4L8 12L0 19L-8 12L-11-4Z" fill="url(#lampGlow)"/><path d="M0 19V28" stroke="#d99837" strokeWidth="3"/></g>;
}

function AltarRoomBackground() {
  return <g className="altar-room-background">
    <rect width="960" height="650" fill="url(#altarWall)"/>
    <circle cx="480" cy="205" r="250" fill="url(#altarHalo)" opacity=".5"/>
    <g className="altar-clouds" fill="none" stroke="#f7dc9d" strokeWidth="7" strokeLinecap="round" opacity=".24">
      <path d="M55 168h82q10-30 36-17q24-32 55 2h58"/><path d="M687 180h64q14-33 43-12q31-29 60 6h52"/>
      <path d="M91 235h91q18-24 45-5h44"/><path d="M704 246h65q17-23 43-5h57"/>
    </g>
    <path d="M0 492H960V650H0Z" fill="url(#altarFloor)"/>
    <path d="M0 520H960" stroke="#d19a63" strokeWidth="3" opacity=".35"/>
    {[80, 250, 420, 590, 760, 930].map((x) => <path key={x} d={`M${x} 520L${x - 65} 650`} stroke="#d19a63" strokeWidth="2" opacity=".18"/>)}
    <path d="M0 0H104L72 650H0ZM960 0H856L888 650H960Z" fill="#4d251f" opacity=".64"/>
    <path d="M0 0H80L46 470H0ZM960 0H880L914 470H960Z" fill="#7f3229" opacity=".72"/>
  </g>;
}

function FullAltar({ incenseSticks, offering, smoke, incenseLit, onIncense, onOffering }: {
  incenseSticks: 0 | 1 | 3;
  offering: FruitOffering | null;
  smoke?: boolean;
  incenseLit?: boolean;
  onIncense?: () => void;
  onOffering?: () => void;
}) {
  return <g className="full-altar" filter="url(#altarShadow)">
    <ellipse cx="480" cy="514" rx="264" ry="24" fill="#2b1512" opacity=".3"/>
    <path d="M258 142Q480 28 702 142L731 157Q480 111 229 157Z" fill="url(#altarWood)"/>
    <path d="M236 142Q480 78 724 142L702 167Q480 126 258 167Z" fill="url(#altarGold)"/>
    <path d="M276 168H684V414H276Z" fill="url(#altarWood)" stroke="#d9943f" strokeWidth="6"/>
    <path d="M300 190H660V390H300Z" fill="#572922" stroke="#efc167" strokeWidth="4"/>
    <g className="altar-cloud-trim" fill="none" stroke="#eab553" strokeWidth="5" strokeLinecap="round">
      <path d="M326 218q20-28 41 0q19-31 43-2h25M525 216q22-29 43 1q20-28 42 1h24"/>
    </g>
    <path d="M252 414H708L743 448H217Z" fill="url(#altarWoodLight)"/>
    <path d="M213 448H747V491H213Z" fill="url(#altarWood)" stroke="#cf7d35" strokeWidth="4"/>
    <path d="M238 491H722L704 523H256Z" fill="#4b211b"/>
    <rect x="384" y="139" width="192" height="44" rx="6" fill="url(#altarGold)"/>
    <text x="480" y="168" fill="#4d261c" fontFamily="var(--font-display)" fontSize="23" fontWeight="700" textAnchor="middle">CHÙA AN NHIÊN</text>
    <g className="altar-pillars" fill="url(#altarWoodLight)"><rect x="258" y="157" width="31" height="280" rx="8"/><rect x="671" y="157" width="31" height="280" rx="8"/></g>
    <FullLamp x={311}/><FullLamp x={649}/>
    <BuddhaFigure x={480} y={369} scale={1.38}/>
    <FlowerVase x={342} y={420} scale={.66}/>
    <FlowerVase x={618} y={420} scale={.66} mirrored/>
    <g className="offering-spot interactive" role="button" tabIndex={0} onClick={onOffering} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onOffering?.()} aria-label="Dâng lễ trái cây">
      {offering ? <OfferingPlate offering={offering} x={480} y={424} scale={.76}/> : <g className="empty-offering-place" opacity=".42"><ellipse cx="480" cy="426" rx="45" ry="8" fill="#d9aa57"/><path d="M443 422Q480 438 517 422" fill="none" stroke="#ffe29a" strokeWidth="3"/></g>}
    </g>
    <IncenseBowl sticks={incenseSticks} x={480} y={471} scale={.82} smoke={smoke} lit={incenseLit} onClick={onIncense}/>
  </g>;
}

function FullLamp({ x }: { x: number }) {
  return <g transform={`translate(${x} 246)`} className="altar-lamp"><ellipse rx="42" ry="48" fill="#ffbc35" opacity=".15" filter="url(#goldGlow)"/><path d="M-12-21H12L19-8L14 22L0 35L-14 22L-19-8Z" fill="url(#lampGlow)"/><path d="M0 35V48" stroke="#da9734" strokeWidth="5"/></g>;
}

function BuddhaFigure({ x, y, scale }: { x: number; y: number; scale: number }) {
  return <g transform={`translate(${x} ${y}) scale(${scale})`} className="buddha-figure">
    <circle className="buddha-halo" cx="0" cy="-53" r="76" fill="url(#altarHalo)"/>
    <circle cx="0" cy="-64" r="57" fill="none" stroke="#f7ce64" strokeWidth="3" opacity=".72"/>

    <g className="lotus-throne">
      <ellipse cx="0" cy="45" rx="64" ry="11" fill="#7c3b22" opacity=".46"/>
      <path d="M-61 33Q-45 14-27 34Q-11 9 0 34Q13 8 29 34Q47 14 62 33Q49 57 0 60Q-49 57-61 33Z" fill="#f5be43" stroke="#ffe783" strokeWidth="3"/>
      <path d="M-48 43Q-26 29 0 47Q26 29 48 43Q31 61 0 62Q-31 61-48 43Z" fill="#c56d25" opacity=".72"/>
    </g>

    <path d="M-51 29Q-43 2-18-8Q0-16 19-8Q44 3 51 29Q32 44 0 46Q-32 44-51 29Z" fill="url(#robe)" stroke="#ffd96b" strokeWidth="3"/>
    <path d="M-37 22Q-18 5 0 23Q18 5 37 22" fill="none" stroke="#fff0a1" strokeWidth="3" strokeLinecap="round" opacity=".82"/>
    <path d="M-29 8Q-34-35-13-45Q8-55 29-35L35 11Q14 22 0 22Q-15 22-29 8Z" fill="url(#robe)" stroke="#f9d064" strokeWidth="3"/>
    <path d="M-12-43Q-31-25-28 7M6-45Q23-29 28 6" fill="none" stroke="#fff0a1" strokeWidth="3" opacity=".65"/>
    <path d="M-28-31Q-39-11-20 9M28-29Q37-9 20 9" fill="none" stroke="#d98529" strokeWidth="7" strokeLinecap="round"/>

    <rect x="-8" y="-52" width="16" height="14" rx="7" fill="url(#buddhaSkin)"/>
    <ellipse cx="-21" cy="-73" rx="4.5" ry="11" fill="url(#buddhaSkin)" stroke="#a96131" strokeWidth="1.5"/>
    <ellipse cx="21" cy="-73" rx="4.5" ry="11" fill="url(#buddhaSkin)" stroke="#a96131" strokeWidth="1.5"/>
    <ellipse cx="0" cy="-75" rx="21" ry="25" fill="url(#buddhaSkin)" stroke="#ad6834" strokeWidth="2"/>
    <path d="M-21-82Q-15-104 0-103Q16-103 21-82Q11-91 0-91Q-11-91-21-82Z" fill="#734526"/>
    <circle cx="0" cy="-105" r="8" fill="#8c5527" stroke="#d58c29" strokeWidth="2"/>
    <g fill="none" stroke="#70402f" strokeLinecap="round">
      <path d="M-12-76Q-7-72-2-76M2-76Q7-72 12-76" strokeWidth="2"/>
      <path d="M0-72L-2-65Q0-63 3-65" strokeWidth="1.4"/>
      <path d="M-7-59Q0-54 7-59" strokeWidth="1.8"/>
    </g>
    <circle cx="0" cy="-83" r="2" fill="#9b442f"/>

    <g className="buddha-mudra" fill="url(#buddhaSkin)" stroke="#9f5c31" strokeWidth="1.6">
      <path d="M-25-2Q-13-10 0 2Q-7 12-22 8Q-29 5-25-2Z"/>
      <path d="M25-2Q13-10 0 2Q7 12 22 8Q29 5 25-2Z"/>
    </g>
    <path d="M-14 3Q0 10 14 3" fill="none" stroke="#96513e" strokeWidth="1.7" strokeLinecap="round"/>
  </g>;
}

function FlowerVase({ x, y, scale = 1, mirrored = false }: { x: number; y: number; scale?: number; mirrored?: boolean }) {
  return <g transform={`translate(${x} ${y}) scale(${mirrored ? -scale : scale} ${scale})`} className="flower-vase">
    <g fill="none" stroke="#356840" strokeWidth="4" strokeLinecap="round">
      <path d="M0-25L-24-100M0-25L12-116M0-25L40-91M0-25L-43-78M0-25L-3-82"/>
    </g>
    <g fill="#4a8a50" stroke="#2d6339" strokeWidth="1.5">
      <ellipse cx="-30" cy="-78" rx="15" ry="7" transform="rotate(28 -30 -78)"/>
      <ellipse cx="26" cy="-87" rx="16" ry="7" transform="rotate(-25 26 -87)"/>
      <ellipse cx="-8" cy="-97" rx="14" ry="6" transform="rotate(18 -8 -97)"/>
      <ellipse cx="-37" cy="-66" rx="13" ry="6" transform="rotate(-18 -37 -66)"/>
    </g>
    <g className="altar-flowers">
      <FlowerBloom x={-24} y={-104} scale={.92} color="#ef7090"/>
      <FlowerBloom x={12} y={-121} scale={1.04} color="#f18aa2"/>
      <FlowerBloom x={42} y={-94} scale={.9} color="#e85f82"/>
      <FlowerBloom x={-45} y={-81} scale={.82} color="#f49aad"/>
      <FlowerBloom x={-3} y={-83} scale={.72} color="#f7b0be"/>
    </g>
    <path d="M-29-40H29L23 9Q0 27-23 9Z" fill="url(#altarCeramic)" stroke="#f6d97d" strokeWidth="4"/>
    <path d="M-25-25Q0-12 25-25M-23-7Q0 8 23-7" fill="none" stroke="#9f652d" strokeWidth="3" opacity=".7"/>
    <path d="M-22 10Q0 22 22 10" fill="none" stroke="#fff0a0" strokeWidth="2" opacity=".7"/>
  </g>;
}

function FlowerBloom({ x, y, scale, color }: { x: number; y: number; scale: number; color: string }) {
  return <g transform={`translate(${x} ${y}) scale(${scale})`}>
    <ellipse cx="0" cy="-7" rx="7" ry="12" fill={color} stroke="#a93455" strokeWidth="1.7"/>
    <ellipse cx="8" cy="-2" rx="7" ry="12" transform="rotate(58 8 -2)" fill={color} stroke="#a93455" strokeWidth="1.7"/>
    <ellipse cx="5" cy="7" rx="7" ry="12" transform="rotate(122 5 7)" fill={color} stroke="#a93455" strokeWidth="1.7"/>
    <ellipse cx="-5" cy="7" rx="7" ry="12" transform="rotate(-122 -5 7)" fill={color} stroke="#a93455" strokeWidth="1.7"/>
    <ellipse cx="-8" cy="-2" rx="7" ry="12" transform="rotate(-58 -8 -2)" fill={color} stroke="#a93455" strokeWidth="1.7"/>
    <circle r="5" fill="#ffd66b" stroke="#b56c30" strokeWidth="1.5"/>
  </g>;
}

function OfferingPlate({ offering, x, y, scale = 1 }: { offering: FruitOffering; x: number; y: number; scale?: number }) {
  const fruit = offering === 'citrus'
    ? [{ x: -26, y: -18, c: '#f29b24' }, { x: 0, y: -24, c: '#ffb02e' }, { x: 27, y: -17, c: '#e9871f' }, { x: -8, y: -43, c: '#f5a42a' }]
    : offering === 'apples'
      ? [{ x: -26, y: -18, c: '#c8323d' }, { x: 0, y: -23, c: '#df3d47' }, { x: 27, y: -17, c: '#b92735' }, { x: 2, y: -44, c: '#ef5960' }]
      : [{ x: -31, y: -17, c: '#e09a28' }, { x: -7, y: -27, c: '#d84448' }, { x: 20, y: -18, c: '#6ea53d' }, { x: 3, y: -48, c: '#e6bd35' }, { x: 37, y: -34, c: '#a95aa4' }];
  return <g transform={`translate(${x} ${y}) scale(${scale})`} className="offering-plate">
    <ellipse cx="0" cy="1" rx="58" ry="12" fill="#64321f" opacity=".32"/>
    <path d="M-55-4Q0 23 55-4L47 11Q0 34-47 11Z" fill="url(#altarCeramic)" stroke="#f3d377" strokeWidth="4"/>
    {fruit.map((item, index) => <g key={index}><circle cx={item.x} cy={item.y} r="18" fill={item.c} stroke="#8a4a27" strokeWidth="2"/><path d={`M${item.x} ${item.y - 17}q8-11 16-5`} fill="none" stroke="#42743d" strokeWidth="3" strokeLinecap="round"/></g>)}
  </g>;
}

function IncenseBowl({ sticks, x, y, scale = 1, smoke, lit, onClick }: {
  sticks: 0 | 1 | 3;
  x: number;
  y: number;
  scale?: number;
  smoke?: boolean;
  lit?: boolean;
  onClick?: () => void;
}) {
  const positions = sticks === 3 ? [-14, 0, 14] : sticks === 1 ? [0] : [];
  return <g
    transform={`translate(${x} ${y}) scale(${scale})`}
    className={`incense-object interactive ${lit ? 'just-lit' : ''}`}
    role={onClick ? 'button' : undefined}
    tabIndex={onClick ? 0 : undefined}
    onClick={onClick}
    onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()}
    aria-label={onClick ? 'Thắp nhang' : undefined}
    aria-hidden={onClick ? undefined : true}
  >
    <ellipse cx="0" cy="16" rx="72" ry="15" fill="#25120e" opacity=".32"/>
    <path d="M-58-7Q0-29 58-7L48 39Q0 59-48 39Z" fill="url(#altarCeramic)" stroke="#f0ca64" strokeWidth="4"/>
    <ellipse cx="0" cy="-8" rx="58" ry="16" fill="#5c2d21"/>
    <ellipse cx="0" cy="-9" rx="45" ry="10" fill="#8f785c"/>
    {positions.map((offset) => <g key={offset} style={{ '--offset': offset } as CSSProperties}>
      <path d={`M${offset} -10V-105`} stroke="#9f3829" strokeWidth="4"/>
      <circle cx={offset} cy="-107" r="4" fill="#ffb035"/>
      <circle className="ember" cx={offset} cy="-107" r="10" fill="#ff7a2e" opacity=".3" filter="url(#emberGlow)"/>
      {smoke && <path className={`smoke smoke-${offset + 14}`} d={`M${offset} -113C${offset - 20} -133 ${offset + 17} -148 ${offset} -169S${offset - 15} -199 ${offset + 8} -222`} fill="none" stroke="#fff3d6" strokeWidth="5" strokeLinecap="round" opacity=".55"/>}
    </g>)}
  </g>;
}

function RitualHands({ animation, incenseSticks, offering }: { animation: RitualAnimation; incenseSticks: 1 | 3; offering: FruitOffering }) {
  if (!animation) return null;
  if (animation === 'incense') {
    const positions = incenseSticks === 3 ? [-13, 0, 13] : [0];
    return <g className="ritual-hands ritual-hands-incense" aria-hidden="true">
      <g className="ritual-incense-arm ritual-incense-arm-left">
        <path className="ritual-sleeve sleeve-left" d="M282 650Q325 548 407 475L449 519Q376 584 355 650Z" fill="#8d4a28"/>
        <path className="ritual-palm ritual-palm-left" d="M401 486Q423 446 452 427Q465 424 472 438L468 479Q451 503 428 515Z" fill="url(#skin)" stroke="#a65f49" strokeWidth="3"/>
        <path d="M440 447Q451 437 468 438M438 457Q452 448 469 450M440 468Q454 461 469 462" fill="none" stroke="#b96c53" strokeWidth="2" strokeLinecap="round"/>
      </g>
      <g className="ritual-incense-arm ritual-incense-arm-right">
        <path className="ritual-sleeve sleeve-right" d="M678 650Q635 548 553 475L511 519Q584 584 605 650Z" fill="#8d4a28"/>
        <path className="ritual-palm ritual-palm-right" d="M559 486Q537 446 508 427Q495 424 488 438L492 479Q509 503 532 515Z" fill="url(#skin)" stroke="#a65f49" strokeWidth="3"/>
        <path d="M520 447Q509 437 492 438M522 457Q508 448 491 450M520 468Q506 461 491 462" fill="none" stroke="#b96c53" strokeWidth="2" strokeLinecap="round"/>
      </g>
      <path className="ritual-prayer-touch" d="M468 478Q480 487 492 478" fill="none" stroke="#9f5845" strokeWidth="3" strokeLinecap="round"/>
      <g className="ritual-held-incense">
        {positions.map((offset) => <g key={offset}><path d={`M${480 + offset} 465V337`} stroke="#a63d2d" strokeWidth="4"/><circle cx={480 + offset} cy="334" r="5" fill="#ffb13d"/><circle cx={480 + offset} cy="334" r="13" fill="#ff8b31" opacity=".24" filter="url(#emberGlow)"/></g>)}
      </g>
    </g>;
  }

  return <g className="ritual-hands ritual-hands-offering" aria-hidden="true">
    <g className="ritual-offering-arm ritual-offering-arm-left">
      <path className="ritual-sleeve sleeve-left" d="M242 650Q307 555 387 469L438 504Q371 578 344 650Z" fill="#8d4a28"/>
      <path className="ritual-palm ritual-palm-left" d="M374 479Q401 451 443 456L474 473Q444 494 398 503Q378 501 374 479Z" fill="url(#skin)" stroke="#a65f49" strokeWidth="3"/>
      <path d="M398 475Q427 472 454 482M395 485Q424 483 445 490" fill="none" stroke="#b96c53" strokeWidth="2" strokeLinecap="round"/>
    </g>
    <g className="ritual-offering-arm ritual-offering-arm-right">
      <path className="ritual-sleeve sleeve-right" d="M718 650Q653 555 573 469L522 504Q589 578 616 650Z" fill="#8d4a28"/>
      <path className="ritual-palm ritual-palm-right" d="M586 479Q559 451 517 456L486 473Q516 494 562 503Q582 501 586 479Z" fill="url(#skin)" stroke="#a65f49" strokeWidth="3"/>
      <path d="M562 475Q533 472 506 482M565 485Q536 483 515 490" fill="none" stroke="#b96c53" strokeWidth="2" strokeLinecap="round"/>
    </g>
    <g className="ritual-offering-tray"><OfferingPlate offering={offering} x={480} y={453} scale={1.02}/></g>
  </g>;
}

function Bell({ ringing, onClick }: { ringing?: boolean; onClick?: () => void }) {
  return <g className={`bell-object interactive ${ringing ? 'ringing' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Rung chuông">
    <ellipse cx="126" cy="553" rx="76" ry="14" fill="#281510" opacity=".3"/>
    <path d="M76 548V406Q126 371 176 406V548" fill="none" stroke="#6b3423" strokeWidth="16"/>
    <path d="M91 485Q96 428 126 419Q156 428 161 485L176 526Q126 545 76 526Z" fill="#b86a2d" stroke="#f0bd54" strokeWidth="4"/>
    <ellipse cx="126" cy="526" rx="50" ry="12" fill="#6f3a25"/><circle cx="126" cy="531" r="8" fill="#f2c75b"/>
    <g className="bell-waves" fill="none" stroke="#ffe694" strokeWidth="3"><circle cx="126" cy="486" r="64"/><circle cx="126" cy="486" r="82"/></g>
  </g>;
}

function Woodblock({ hit, onClick }: { hit?: boolean; onClick?: () => void }) {
  return <g className={`woodblock-object interactive ${hit ? 'hit' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Gõ mõ">
    <ellipse cx="827" cy="558" rx="78" ry="14" fill="#281510" opacity=".3"/>
    <path d="M793 534Q765 503 793 468Q829 444 865 470Q888 504 861 536Q827 553 793 534Z" fill="url(#altarWoodLight)" stroke="#efb650" strokeWidth="4"/>
    <path d="M809 470Q831 491 855 477" fill="none" stroke="#55251d" strokeWidth="7" strokeLinecap="round"/><circle cx="784" cy="504" r="7" fill="#2d1713"/>
    <g className="striker"><path d="M869 451L814 511" stroke="#783a25" strokeWidth="9" strokeLinecap="round"/><circle cx="877" cy="443" r="12" fill="#b66835"/></g>
  </g>;
}

function MeditationMat({ onClick }: { onClick?: () => void }) {
  return <g className="meditation-mat interactive" role="button" tabIndex={0} onClick={onClick} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Tĩnh tâm">
    <ellipse cx="688" cy="568" rx="64" ry="14" fill="#281510" opacity=".25"/>
    <path d="M631 548Q688 530 745 548L735 574Q688 590 641 574Z" fill="#6c7b47" stroke="#d2c277" strokeWidth="4"/>
    <path d="M659 553Q688 544 717 553" fill="none" stroke="#eee0a4" strokeWidth="3" opacity=".7"/>
  </g>;
}
