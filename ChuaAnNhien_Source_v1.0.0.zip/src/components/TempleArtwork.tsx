import type { CSSProperties } from 'react';

type Props = {
  mini?: boolean;
  gateOpening?: boolean;
  returning?: boolean;
  incenseSticks?: 0 | 1 | 3;
  smoke?: boolean;
  natureMotion?: boolean;
  onGate?: () => void;
  onBell?: () => void;
  onWoodblock?: () => void;
  bellRinging?: boolean;
  woodblockHit?: boolean;
  incenseLit?: boolean;
  arriving?: boolean;
  leaving?: boolean;
  onIncense?: () => void;
  onMeditation?: () => void;
};

export function TempleArtwork({ mini = false, gateOpening, returning, incenseSticks = 0, smoke = true,
  natureMotion = true, onGate, onBell, onWoodblock, bellRinging, woodblockHit, incenseLit,
  arriving, leaving, onIncense, onMeditation }: Props) {
  const cls = [
    'temple-artwork', mini ? 'is-mini' : 'is-full', natureMotion ? '' : 'motion-off',
    arriving ? 'is-arriving' : '', leaving ? 'is-leaving' : '', returning ? 'is-returning' : ''
  ].filter(Boolean).join(' ');

  return (
    <svg className={cls} viewBox={mini ? '0 0 520 380' : '0 0 960 650'} role="img" aria-label={mini ? 'Cổng Chùa An Nhiên trong buổi chiều thanh tịnh' : 'Sân Chùa An Nhiên với mái chùa, hồ sen và cây bồ đề'}>
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop stopColor="var(--scene-sky-high)"/><stop offset="1" stopColor="var(--scene-sky-low)"/></linearGradient>
        <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1"><stop stopColor="var(--scene-ground-high)"/><stop offset="1" stopColor="var(--scene-ground-low)"/></linearGradient>
        <linearGradient id="roof" x1="0" y1="0" x2="1" y2="1"><stop stopColor="var(--scene-roof-high)"/><stop offset="1" stopColor="var(--scene-roof-low)"/></linearGradient>
        <linearGradient id="wood" x1="0" y1="0" x2="1" y2="0"><stop stopColor="var(--scene-wood-deep)"/><stop offset="1" stopColor="var(--scene-wood)"/></linearGradient>
        <linearGradient id="water" x1="0" y1="0" x2="0" y2="1"><stop stopColor="var(--scene-water-high)"/><stop offset="1" stopColor="var(--scene-water-low)"/></linearGradient>
        <radialGradient id="lantern"><stop stopColor="var(--scene-light)"/><stop offset="1" stopColor="var(--scene-lantern)"/></radialGradient>
        <radialGradient id="sun"><stop stopColor="var(--scene-sun)"/><stop offset="1" stopColor="var(--scene-sun-fade)" stopOpacity="0"/></radialGradient>
        <filter id="softGlow"><feGaussianBlur stdDeviation="7"/></filter>
        <filter id="shadow"><feDropShadow dx="0" dy="8" stdDeviation="7" floodColor="var(--scene-shadow)" floodOpacity=".34"/></filter>
        <clipPath id="gatePortal"><rect x="170" y="219" width="180" height="111" rx="4"/></clipPath>
      </defs>

      <rect width="100%" height="100%" fill="url(#sky)"/>
      <circle className="sun-glow" cx={mini ? 414 : 780} cy={mini ? 72 : 104} r={mini ? 98 : 142} fill="url(#sun)"/>
      <g className="cloud cloud-one" fill="var(--scene-cloud)" opacity=".28"><ellipse cx={mini ? 98 : 176} cy={mini ? 68 : 116} rx="61" ry="17"/><ellipse cx={mini ? 139 : 225} cy={mini ? 60 : 106} rx="43" ry="21"/></g>
      <g className="cloud cloud-two" fill="var(--scene-cloud)" opacity=".18"><ellipse cx={mini ? 352 : 670} cy={mini ? 119 : 157} rx="57" ry="15"/><ellipse cx={mini ? 393 : 722} cy={mini ? 110 : 149} rx="42" ry="20"/></g>

      <g className="mountain-layers">
        <path d={mini ? 'M0 221Q86 148 176 212Q275 122 366 210Q445 155 520 215V380H0Z' : 'M0 342Q135 225 282 325Q430 172 585 326Q752 205 960 330V650H0Z'} fill="var(--scene-hill-far)"/>
        <path d={mini ? 'M0 267Q110 199 224 254Q354 178 520 256V380H0Z' : 'M0 404Q177 308 356 389Q625 268 960 397V650H0Z'} fill="var(--scene-hill-near)"/>
      </g>
      <g className="mist-bands" fill="none" stroke="var(--scene-mist)" strokeLinecap="round">
        <path d={mini ? 'M18 226Q128 205 238 224T500 220' : 'M24 351Q220 318 414 351T936 343'} strokeWidth={mini ? 9 : 13} opacity=".2"/>
        <path d={mini ? 'M-10 245Q127 226 267 246T540 239' : 'M-30 378Q205 350 438 380T990 370'} strokeWidth={mini ? 5 : 8} opacity=".16"/>
      </g>
      <path d={mini ? 'M0 271Q126 224 252 262Q392 211 520 266V380H0Z' : 'M0 425Q202 347 384 411Q659 302 960 420V650H0Z'} fill="url(#ground)"/>

      {mini ? <MiniGate gateOpening={gateOpening} returning={returning} onGate={onGate}/> : <>
        <Courtyard/>
        <FullTemple/>
        <BodhiTree/>
        <Bell ringing={bellRinging} onClick={onBell}/>
        <Woodblock hit={woodblockHit} onClick={onWoodblock}/>
        <Incense sticks={incenseSticks} smoke={smoke} lit={incenseLit} onClick={onIncense}/>
        <MeditationMat onClick={onMeditation}/>
      </>}

      <g className="birds" fill="none" stroke="var(--scene-bird)" strokeWidth="3" strokeLinecap="round"><path d={mini ? 'M344 54q8-8 16 0q8-8 16 0' : 'M704 72q9-9 18 0q9-9 18 0'}/><path d={mini ? 'M391 42q6-6 12 0q6-6 12 0' : 'M760 56q7-7 14 0q7-7 14 0'}/></g>
    </svg>
  );
}

function MiniGate({ gateOpening, returning, onGate }: { gateOpening?: boolean; returning?: boolean; onGate?: () => void }) {
  return <g className={`mini-gate ${gateOpening ? 'opening' : ''} ${returning ? 'returning' : ''}`} role="button" tabIndex={0} onClick={onGate} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onGate?.()} aria-label="Mở cổng chùa">
    <ellipse cx="260" cy="347" rx="174" ry="22" fill="var(--scene-shadow)" opacity=".3"/>
    <g className="gate-depth" clipPath="url(#gatePortal)">
      <rect x="170" y="219" width="180" height="112" fill="var(--scene-sky-low)"/>
      <path d="M183 331Q260 270 337 331" fill="var(--scene-stone-light)" opacity=".8"/>
      <path d="M220 283Q260 248 300 283L291 292H229Z" fill="var(--scene-roof-high)"/>
      <rect x="235" y="290" width="50" height="34" fill="var(--scene-wood-deep)"/>
      <circle cx="260" cy="264" r="26" fill="var(--scene-sun)" opacity=".16"/>
    </g>
    <g filter="url(#shadow)">
      <path d="M87 176Q260 76 433 176L407 198H113Z" fill="url(#roof)"/>
      <path d="M70 175Q260 113 450 175L419 187Q260 146 101 187Z" fill="var(--scene-gold)"/>
      <path d="M103 193H417V213H103Z" fill="var(--scene-wood-deep)"/>
      <path d="M124 210H396V334H124Z" fill="var(--scene-plaster)"/>
      <rect x="153" y="211" width="214" height="123" fill="var(--scene-wood-deep)"/>
      <rect x="103" y="194" width="32" height="151" rx="5" fill="url(#wood)"/>
      <rect x="385" y="194" width="32" height="151" rx="5" fill="url(#wood)"/>
      <path d="M184 189H336V224H184Z" fill="var(--scene-gold)"/>
      <text x="260" y="214" fill="var(--scene-sign-ink)" fontFamily="var(--font-display)" fontSize="22" fontWeight="700" textAnchor="middle">AN NHIÊN</text>
      <g className="gate-ridge" fill="none" stroke="var(--scene-gold)" strokeWidth="5" strokeLinecap="round"><path d="M87 176q-18 7-24-4"/><path d="M433 176q18 7 24-4"/></g>
    </g>
    <g className="gate-doors">
      <path className="door-left" d="M154 224H260V334H154Z" fill="var(--scene-door)" stroke="var(--scene-gold-muted)" strokeWidth="4"/>
      <path className="door-right" d="M260 224H366V334H260Z" fill="var(--scene-door)" stroke="var(--scene-gold-muted)" strokeWidth="4"/>
      {[176,205,234,286,315,344].map((x) => <circle key={x} cx={x} cy="276" r="4" fill="var(--scene-gold)"/>)}
    </g>
    <Lantern x={121} y={237}/><Lantern x={399} y={237}/>
    <path d="M184 351Q260 301 336 351" fill="var(--scene-stone)"/><path d="M216 363Q260 333 304 363" fill="var(--scene-stone-light)"/>
  </g>;
}

function Courtyard() {
  return <g className="courtyard">
    <path d="M337 650Q480 430 623 650Z" fill="var(--scene-stone)" opacity=".88"/>
    <path d="M376 650Q480 472 584 650Z" fill="var(--scene-stone-light)" opacity=".5"/>
    <g className="lotus-pond" opacity=".9">
      <path d="M0 545Q134 505 270 548L252 650H0Z" fill="url(#water)"/>
      <path d="M690 548Q826 505 960 545V650H708Z" fill="url(#water)"/>
      {[{x:79,y:579},{x:190,y:559},{x:755,y:574},{x:877,y:552}].map(({x,y}) => <g key={`${x}-${y}`} transform={`translate(${x} ${y})`}><ellipse rx="27" ry="8" fill="var(--scene-lily)"/><path d="M0-2C-17-15-12-32 0-39c12 7 17 24 0 37Z" fill="var(--scene-lotus)"/><path d="M0-2C-9-13-5-23 0-28c5 5 9 15 0 26Z" fill="var(--scene-lotus-light)"/></g>)}
      <g className="water-lines" fill="none" stroke="var(--scene-water-line)" strokeLinecap="round"><path d="M18 606h178"/><path d="M734 614h190"/><path d="M48 628h128"/><path d="M777 638h117"/></g>
    </g>
  </g>;
}

function FullTemple() {
  return <g className="main-hall" filter="url(#shadow)">
    <ellipse cx="480" cy="539" rx="323" ry="35" fill="var(--scene-shadow)" opacity=".28"/>
    <g className="roof-tiers">
      <path d="M270 251Q480 114 690 251L657 278H303Z" fill="url(#roof)"/>
      <path d="M246 248Q480 162 714 248L680 263Q480 205 280 263Z" fill="var(--scene-gold)"/>
      <path d="M176 319Q480 153 784 319L742 348H218Z" fill="url(#roof)"/>
      <path d="M143 315Q480 218 817 315L774 334Q480 267 186 334Z" fill="var(--scene-gold-muted)"/>
      <g className="roof-finials" fill="none" stroke="var(--scene-gold)" strokeWidth="7" strokeLinecap="round"><path d="M176 319q-31 13-43-8"/><path d="M784 319q31 13 43-8"/><path d="M270 251q-20 8-29-7"/><path d="M690 251q20 8 29-7"/></g>
    </g>
    <path d="M226 340H734V500H226Z" fill="var(--scene-plaster)"/>
    <path d="M254 351H706V500H254Z" fill="var(--scene-wood-deep)"/>
    <g className="veranda" fill="url(#wood)">{[236,302,624,690].map((x) => <rect key={x} x={x} y="328" width="30" height="184" rx="5"/>)}</g>
    <rect x="365" y="283" width="230" height="48" rx="4" fill="var(--scene-gold)"/>
    <text x="480" y="313" fill="var(--scene-sign-ink)" fontFamily="var(--font-display)" fontSize="23" fontWeight="700" textAnchor="middle">CHÙA AN NHIÊN</text>
    <g className="hall-doors" fill="var(--scene-door)" stroke="var(--scene-gold-muted)" strokeWidth="4">
      <rect x="326" y="366" width="154" height="134"/><rect x="480" y="366" width="154" height="134"/>
      <circle cx="445" cy="433" r="18"/><circle cx="515" cy="433" r="18"/>
    </g>
    <g className="door-lattice" stroke="var(--scene-gold-muted)" strokeWidth="2" opacity=".7"><path d="M350 387h106M350 411h106M504 387h106M504 411h106"/><path d="M377 366v67M429 366v67M531 366v67M583 366v67"/></g>
    <path d="M278 513H682L724 552H236Z" fill="var(--scene-stone)"/><path d="M316 500H644L672 526H288Z" fill="var(--scene-stone-light)"/>
    <path d="M337 528H623L646 548H314Z" fill="none" stroke="var(--scene-stone-line)" strokeWidth="3"/>
    <Lantern x={247} y={372}/><Lantern x={713} y={372}/>
  </g>;
}

function Lantern({ x, y }: { x: number; y: number }) {
  return <g transform={`translate(${x} ${y})`}><g className="lantern"><ellipse r="30" fill="var(--scene-light)" opacity=".2" filter="url(#softGlow)"/><path d="M-10-23H10L16-12L13 14L6 24H-6L-13 14L-16-12Z" fill="url(#lantern)"/><path d="M0 24V34" stroke="var(--scene-wood-deep)" strokeWidth="3"/></g></g>;
}

function BodhiTree() {
  return <g className="bodhi-tree"><path d="M830 478Q824 334 876 244Q848 360 865 490" fill="none" stroke="var(--scene-trunk)" strokeWidth="29" strokeLinecap="round"/><path d="M856 350q-38-66-85-72M861 328q45-70 92-82" fill="none" stroke="var(--scene-trunk)" strokeWidth="12" strokeLinecap="round"/><g fill="var(--scene-leaf)"><circle cx="800" cy="260" r="63"/><circle cx="868" cy="232" r="70"/><circle cx="924" cy="260" r="68"/><circle cx="858" cy="190" r="57"/><circle cx="952" cy="211" r="43"/></g><g className="tree-leaves" fill="var(--scene-leaf-light)"><circle cx="773" cy="226" r="17"/><circle cx="890" cy="174" r="19"/><circle cx="968" cy="242" r="16"/><circle cx="846" cy="278" r="18"/><circle cx="928" cy="187" r="14"/></g></g>;
}

function Bell({ ringing, onClick }: { ringing?: boolean; onClick?: () => void }) {
  return <g className={`bell-object interactive ${ringing ? 'ringing' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Rung chuông">
    <ellipse cx="139" cy="549" rx="79" ry="15" fill="var(--scene-shadow)" opacity=".26"/><path d="M84 543V385Q139 350 194 385V543" fill="none" stroke="var(--scene-wood)" strokeWidth="16"/>
    <path d="M104 467Q108 410 139 401Q170 410 174 467L190 510Q139 529 88 510Z" fill="var(--scene-bronze)" stroke="var(--scene-gold)" strokeWidth="4"/><ellipse cx="139" cy="510" rx="51" ry="12" fill="var(--scene-bronze-deep)"/><circle cx="139" cy="515" r="8" fill="var(--scene-gold)"/>
    <g className="bell-waves" fill="none" stroke="var(--scene-light)" strokeWidth="3"><circle cx="139" cy="470" r="65"/><circle cx="139" cy="470" r="84"/></g>
  </g>;
}

function Woodblock({ hit, onClick }: { hit?: boolean; onClick?: () => void }) {
  return <g className={`woodblock-object interactive ${hit ? 'hit' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Gõ mõ">
    <ellipse cx="814" cy="555" rx="82" ry="15" fill="var(--scene-shadow)" opacity=".27"/><path d="M779 529Q752 498 779 463Q818 438 856 466Q878 499 852 531Q817 550 779 529Z" fill="url(#wood)" stroke="var(--scene-gold-muted)" strokeWidth="4"/><path d="M797 465Q820 484 846 472" fill="none" stroke="var(--scene-wood-deep)" strokeWidth="7" strokeLinecap="round"/><circle cx="770" cy="500" r="7" fill="var(--scene-ink)"/>
    <g className="striker"><path d="M858 447L802 506" stroke="var(--scene-wood)" strokeWidth="9" strokeLinecap="round"/><circle cx="866" cy="439" r="12" fill="var(--scene-wood-light)"/></g>
  </g>;
}

function Incense({ sticks, smoke, lit, onClick }: { sticks: 0 | 1 | 3; smoke?: boolean; lit?: boolean; onClick?: () => void }) {
  const positions = sticks === 3 ? [-14, 0, 14] : sticks === 1 ? [0] : [];
  return <g className={`incense-object interactive ${lit ? 'just-lit' : ''}`} role="button" tabIndex={0} onClick={onClick} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Thắp nhang">
    <ellipse cx="480" cy="567" rx="96" ry="20" fill="var(--scene-shadow)" opacity=".22"/><path d="M407 511Q480 486 553 511L542 565Q480 589 418 565Z" fill="var(--scene-ceramic)" stroke="var(--scene-gold-muted)" strokeWidth="4"/><ellipse cx="480" cy="511" rx="73" ry="21" fill="var(--scene-wood-deep)"/><ellipse cx="480" cy="509" rx="60" ry="13" fill="var(--scene-ash)"/>
    {positions.map((offset) => <g key={offset} style={{ '--offset': offset } as CSSProperties}><path d={`M${480 + offset} 507V410`} stroke="var(--scene-incense)" strokeWidth="4"/><circle cx={480 + offset} cy="408" r="4" fill="var(--scene-ember)"/><circle className="ember" cx={480 + offset} cy="408" r="9" fill="var(--scene-ember-fade)" opacity=".32"/>{smoke && <path className={`smoke smoke-${offset + 14}`} d={`M${480 + offset} 402C${463 + offset} 384 ${500 + offset} 369 ${480 + offset} 350S${464 + offset} 321 ${485 + offset} 297`} fill="none" stroke="var(--scene-smoke)" strokeWidth="5" strokeLinecap="round" opacity=".5"/>}</g>)}
  </g>;
}

function MeditationMat({ onClick }: { onClick?: () => void }) {
  return <g className="meditation-mat interactive" role="button" tabIndex={0} onClick={onClick} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Tĩnh tâm">
    <ellipse cx="667" cy="568" rx="62" ry="15" fill="var(--scene-shadow)" opacity=".22"/>
    <path d="M614 548Q667 533 720 548L711 573Q667 586 623 573Z" fill="var(--scene-mat)" stroke="var(--scene-mat-edge)" strokeWidth="4"/>
    <path d="M642 553Q667 545 692 553" fill="none" stroke="var(--scene-mat-detail)" strokeWidth="3" opacity=".7"/>
  </g>;
}
