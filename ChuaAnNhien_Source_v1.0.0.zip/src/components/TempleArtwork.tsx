import type { CSSProperties } from 'react';
import type { FruitOffering } from '../lib/types';

type RitualAnimation = 'incense' | 'offering' | null;

type Props = {
  mini?: boolean;
  gateOpening?: boolean;
  returning?: boolean;
  incenseSticks?: 0 | 1 | 3;
  ritualIncenseSticks?: 1 | 3;
  offering?: FruitOffering | null;
  ritualOffering?: FruitOffering;
  ritualAnimation?: RitualAnimation;
  ritualOfferingPlaced?: boolean;
  smoke?: boolean;
  natureMotion?: boolean;
  onGate?: () => void;
  onBell?: () => void;
  onWoodblock?: () => void;
  onIncense?: () => void;
  onOffering?: () => void;
  onMeditation?: () => void;
  bellRinging?: boolean;
  woodblockHit?: boolean;
  incenseLit?: boolean;
  arriving?: boolean;
  leaving?: boolean;
};

export function TempleArtwork({
  mini = false,
  gateOpening,
  returning,
  incenseSticks = 0,
  ritualIncenseSticks = 1,
  offering = null,
  ritualOffering = 'five-fruit',
  ritualAnimation = null,
  ritualOfferingPlaced = false,
  smoke = true,
  natureMotion = true,
  onGate,
  onBell,
  onWoodblock,
  onIncense,
  onOffering,
  onMeditation,
  bellRinging,
  woodblockHit,
  incenseLit,
  arriving,
  leaving
}: Props) {
  const cls = [
    'temple-artwork',
    mini ? 'is-mini mini-altar-artwork' : 'is-full altar-room-artwork',
    natureMotion ? '' : 'motion-off',
    arriving ? 'is-arriving' : '',
    leaving ? 'is-leaving' : '',
    returning ? 'is-returning' : ''
  ].filter(Boolean).join(' ');

  if (mini) {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" className={cls} viewBox="0 0 300 360" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Bàn thờ Phật An Nhiên ở góc màn hình">
        <ArtworkDefs/>
        <MiniAltar
          opening={gateOpening}
          returning={returning}
          incenseSticks={incenseSticks}
          offering={offering}
          smoke={smoke}
          onOpen={onGate}
        />
      </svg>
    );
  }

  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={cls} viewBox="0 0 960 650" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Không gian bàn thờ Phật Chùa An Nhiên">
      <ArtworkDefs/>
      <ZenBackground/>
      <FullAltar
        incenseSticks={ritualAnimation === 'incense' ? 0 : incenseSticks}
        offering={ritualAnimation === 'offering' && !ritualOfferingPlaced ? null : offering}
        smoke={smoke}
        incenseLit={incenseLit}
        onIncense={onIncense}
        onOffering={onOffering}
      />
      <Bell ringing={bellRinging} onClick={onBell}/>
      <Woodblock hit={woodblockHit} onClick={onWoodblock}/>
      <MeditationMat onClick={onMeditation}/>
      <RitualHands animation={ritualAnimation} incenseSticks={ritualIncenseSticks} offering={ritualOffering}/>
    </svg>
  );
}

function ArtworkDefs() {
  return <defs>
    <linearGradient id="skyWash" x1="0" y1="0" x2="0" y2="1">
      <stop stopColor="#f7f4e9"/>
      <stop offset=".58" stopColor="#d8e2d2"/>
      <stop offset="1" stopColor="#b8cab7"/>
    </linearGradient>
    <linearGradient id="mistFloor" x1="0" y1="0" x2="0" y2="1">
      <stop stopColor="#d8e1d7"/>
      <stop offset="1" stopColor="#a5b3a7"/>
    </linearGradient>
    <linearGradient id="altarWood" x1="0" y1="0" x2="1" y2="1">
      <stop stopColor="#6f5a45"/>
      <stop offset=".5" stopColor="#4f3d2f"/>
      <stop offset="1" stopColor="#34261e"/>
    </linearGradient>
    <linearGradient id="altarWoodLight" x1="0" y1="0" x2="1" y2="0">
      <stop stopColor="#8a7359"/>
      <stop offset=".5" stopColor="#6b5843"/>
      <stop offset="1" stopColor="#4d3e31"/>
    </linearGradient>
    <linearGradient id="jade" x1="0" y1="0" x2="1" y2="1">
      <stop stopColor="#8db3a3"/>
      <stop offset=".55" stopColor="#5f8f81"/>
      <stop offset="1" stopColor="#3e675c"/>
    </linearGradient>
    <linearGradient id="jadeSoft" x1="0" y1="0" x2="0" y2="1">
      <stop stopColor="#dfeadf"/>
      <stop offset="1" stopColor="#b8cbba"/>
    </linearGradient>
    <linearGradient id="stone" x1="0" y1="0" x2="0" y2="1">
      <stop stopColor="#f5f1e9"/>
      <stop offset="1" stopColor="#cfd1ca"/>
    </linearGradient>
    <linearGradient id="stoneDeep" x1="0" y1="0" x2="0" y2="1">
      <stop stopColor="#e8e7dd"/>
      <stop offset="1" stopColor="#b9bcb3"/>
    </linearGradient>
    <linearGradient id="bronze" x1="0" y1="0" x2="1" y2="1">
      <stop stopColor="#f2ddb0"/>
      <stop offset=".42" stopColor="#c3a56a"/>
      <stop offset="1" stopColor="#86663e"/>
    </linearGradient>
    <linearGradient id="skin" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f6d4bf"/><stop offset="1" stopColor="#d8a48d"/></linearGradient>
    <radialGradient id="halo"><stop stopColor="#fff6d6" stopOpacity=".98"/><stop offset=".48" stopColor="#e6e4c1" stopOpacity=".52"/><stop offset="1" stopColor="#f0eede" stopOpacity="0"/></radialGradient>
    <radialGradient id="ringGlow"><stop stopColor="#fdfbf1" stopOpacity=".96"/><stop offset="1" stopColor="#ded9be" stopOpacity="0"/></radialGradient>
    <radialGradient id="lampGlow"><stop stopColor="#fff6d1"/><stop offset=".38" stopColor="#edd59d"/><stop offset="1" stopColor="#d4b26f"/></radialGradient>
    <filter id="altarShadow" x="-30%" y="-30%" width="160%" height="180%"><feDropShadow dx="0" dy="10" stdDeviation="10" floodColor="#31463d" floodOpacity=".18"/></filter>
    <filter id="softShadow" x="-40%" y="-30%" width="180%" height="190%"><feDropShadow dx="0" dy="8" stdDeviation="8" floodColor="#2f423a" floodOpacity=".16"/></filter>
    <filter id="emberGlow" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="4"/></filter>
  </defs>;
}

function MiniAltar({ opening, returning, incenseSticks, offering, smoke, onOpen }: {
  opening?: boolean;
  returning?: boolean;
  incenseSticks: 0 | 1 | 3;
  offering: FruitOffering | null;
  smoke?: boolean;
  onOpen?: () => void;
}) {
  return <g
    className={`mini-altar interactive ${opening ? 'opening' : ''} ${returning ? 'returning' : ''}`}
    role="button"
    tabIndex={0}
    onClick={onOpen}
    onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onOpen?.()}
    aria-label="Mở không gian Chùa An Nhiên"
  >
    <rect width="300" height="360" rx="24" fill="url(#skyWash)"/>
    <g opacity=".35">
      <path d="M0 300Q58 252 118 296T240 300T300 285V360H0Z" fill="#b5c8b5"/>
      <path d="M0 270Q32 248 60 256T132 266T205 245T300 258" fill="none" stroke="#d7ded0" strokeWidth="4" className="water-lines"/>
    </g>
    <g className="mini-gate">
      <path className="door-left" d="M37 50Q89 36 128 56V289Q81 302 37 288Z" fill="#dfe6da" opacity=".72"/>
      <path className="door-right" d="M172 56Q211 36 263 50V288Q219 302 172 289Z" fill="#dfe6da" opacity=".72"/>
      <ellipse className="gate-depth" cx="150" cy="160" rx="86" ry="104" fill="url(#ringGlow)" opacity=".55"/>
    </g>
    <g filter="url(#softShadow)">
      <circle cx="150" cy="130" r="72" fill="url(#halo)" opacity=".76"/>
      <circle cx="150" cy="130" r="70" fill="none" stroke="#ece8d0" strokeWidth="4" opacity=".92"/>
      <BambooCluster x={38} y={18} mini/>
      <BambooCluster x={248} y={28} mini mirrored/>
      <BuddhaFigure x={150} y={183} scale={.84} stone/>
      <AltarTable x={150} y={242} width={152} mini/>
      <FlowerVase x={84} y={233} scale={.43}/>
      <FlowerVase x={216} y={233} scale={.43} mirrored/>
      {offering && <OfferingPlate offering={offering} x={150} y={231} scale={.42}/>}
      <IncenseBowl sticks={incenseSticks} x={150} y={282} scale={.52} smoke={smoke}/>
    </g>
  </g>;
}

function ZenBackground() {
  return <g className="altar-room-background">
    <rect width="960" height="650" fill="url(#skyWash)"/>
    <rect y="470" width="960" height="180" fill="url(#mistFloor)" opacity=".72"/>
    <circle cx="480" cy="186" r="170" fill="url(#halo)" opacity=".82" className="sun-glow"/>
    <circle cx="480" cy="186" r="150" fill="none" stroke="#ece7d1" strokeWidth="5" opacity=".94"/>
    <circle cx="480" cy="186" r="164" fill="none" stroke="#c3c7b5" strokeWidth="1.5" opacity=".5"/>
    <path d="M320 255Q390 175 480 204T640 255T800 242" fill="none" stroke="#d7ddd1" strokeWidth="8" opacity=".35" className="cloud"/>
    <path d="M160 287Q240 260 320 278T475 288" fill="none" stroke="#d9e0d5" strokeWidth="6" opacity=".28" className="cloud cloud-two"/>
    <g opacity=".38">
      <path d="M0 314Q95 238 180 262T335 256T480 224T661 261T809 244T960 302V470H0Z" fill="#d7ddd0"/>
      <path d="M0 352Q114 312 233 331T457 321T671 343T960 324V470H0Z" fill="#c6d1c5" opacity=".78"/>
    </g>
    <BambooCluster x={46} y={18}/>
    <BambooCluster x={890} y={10} mirrored/>
    <g opacity=".55">
      <LotusPad x={58} y={587} scale={1.14}/><LotusPad x={128} y={617} scale={.8}/><LotusPad x={876} y={600} scale={1.06}/><LotusPad x={808} y={625} scale={.74}/>
      <LotusBloom x={98} y={596} scale={.76}/><LotusBloom x={844} y={609} scale={.7}/>
    </g>
    <g className="birds" fill="#748376" opacity=".55"><path d="M416 104q9-13 18 0M448 110q8-10 16 0M520 118q9-12 18 0" fill="none" stroke="#788577" strokeWidth="2.5" strokeLinecap="round"/></g>
  </g>;
}

function BambooCluster({ x, y, mirrored = false, mini = false }: { x: number; y: number; mirrored?: boolean; mini?: boolean }) {
  const sx = mirrored ? -1 : 1;
  return <g transform={`translate(${x} ${y}) scale(${sx} 1)`} className="tree-leaves" opacity={mini ? .52 : .66}>
    <path d="M0 0V270M32 0V250M63 18V235" fill="none" stroke="#8ba492" strokeWidth={mini ? 4 : 6} strokeLinecap="round"/>
    {[18, 34, 49, 62, 78, 94, 112, 128, 146, 164].map((py, index) => <g key={index} fill="#90b19b" opacity=".9"><path d={`M4 ${py}q30 -18 52 -4q-28 3 -52 17Z`}/><path d={`M28 ${py + 10}q28 -12 44 0q-23 0 -44 12Z`} opacity=".78"/></g>)}
  </g>;
}

function AltarTable({ x, y, width, mini = false }: { x: number; y: number; width: number; mini?: boolean }) {
  const h = mini ? 18 : 28;
  const legH = mini ? 58 : 96;
  const half = width / 2;
  return <g transform={`translate(${x} ${y})`}>
    <ellipse cx="0" cy={legH + h + 10} rx={half - 8} ry={mini ? 8 : 10} fill="#2c3832" opacity=".13"/>
    <rect x={-half} y={0} width={width} height={h} rx="4" fill="url(#altarWoodLight)" stroke="#786550" strokeWidth={mini ? 2 : 3}/>
    <rect x={-half + 12} y={h} width="14" height={legH} rx="2" fill="url(#altarWood)"/>
    <rect x={half - 26} y={h} width="14" height={legH} rx="2" fill="url(#altarWood)"/>
    {!mini && <path d={`M${-half + 12} ${h + 18}Q0 ${h + 3} ${half - 12} ${h + 18}`} fill="none" stroke="#6d5943" strokeWidth="7" strokeLinecap="round" opacity=".55"/>}
  </g>;
}

function FullAltar({ incenseSticks, offering, smoke, incenseLit, onIncense, onOffering }: {
  incenseSticks: 0 | 1 | 3;
  offering: FruitOffering | null;
  smoke?: boolean;
  incenseLit?: boolean;
  onIncense?: () => void;
  onOffering?: () => void;
}) {
  return <g className="full-altar" filter="url(#altarShadow)">
    <BuddhaFigure x={480} y={250} scale={1.34} stone/>
    <FlowerVase x={316} y={304} scale={.62}/>
    <FlowerVase x={644} y={304} scale={.62} mirrored/>
    <AltarTable x={480} y={315} width={330}/>
    <g className="offering-spot interactive" role="button" tabIndex={0} onClick={onOffering} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onOffering?.()} aria-label="Dâng lễ trái cây">
      {offering ? <OfferingPlate offering={offering} x={480} y={299} scale={.88}/> : <g className="empty-offering-place" opacity=".58"><ellipse cx="480" cy="306" rx="58" ry="11" fill="#d9cfb1"/><path d="M434 305Q480 320 526 305" fill="none" stroke="#f2ece0" strokeWidth="3"/></g>}
    </g>
    <LotusLantern x={286} y={403}/><LotusLantern x={674} y={403}/>
    <StoneLantern x={222} y={356}/><StoneLantern x={738} y={356}/>
    <IncensePlatform/>
    <IncenseBowl sticks={incenseSticks} x={480} y={516} scale={1.05} smoke={smoke} lit={incenseLit} onClick={onIncense}/>
  </g>;
}

function BuddhaFigure({ x, y, scale, stone = false }: { x: number; y: number; scale: number; stone?: boolean }) {
  const bodyFill = stone ? 'url(#stone)' : 'url(#bronze)';
  const bodyStroke = stone ? '#c4c8be' : '#9e7f49';
  return <g transform={`translate(${x} ${y}) scale(${scale})`} className="buddha-figure">
    <circle className="buddha-halo" cx="0" cy="-48" r="72" fill="url(#halo)" opacity=".9"/>
    <circle cx="0" cy="-48" r="68" fill="none" stroke="#ece7cf" strokeWidth="3" opacity=".86"/>
    <circle cx="0" cy="-48" r="80" fill="none" stroke="#d8d7c7" strokeWidth="1.4" opacity=".42"/>

    <g className="lotus-throne">
      <ellipse cx="0" cy="50" rx="66" ry="12" fill="#7c8b85" opacity=".18"/>
      <path d="M-61 37Q-45 15-27 36Q-11 10 0 35Q13 10 29 36Q47 15 62 37Q49 61 0 64Q-49 61-61 37Z" fill="#efe3bf" stroke="#ceb984" strokeWidth="3" opacity=".9"/>
      <path d="M-48 46Q-25 31 0 50Q25 31 48 46Q30 64 0 65Q-30 64-48 46Z" fill="#d6b67c" opacity=".75"/>
    </g>

    <path d="M-50 28Q-42 2-18-8Q0-16 18-8Q43 2 50 28Q31 43 0 45Q-31 43-50 28Z" fill={bodyFill} stroke={bodyStroke} strokeWidth="2.7"/>
    <path d="M-28 7Q-33-35-13-46Q8-55 29-36L35 11Q14 22 0 22Q-15 22-28 7Z" fill={bodyFill} stroke={bodyStroke} strokeWidth="2.7"/>
    <path d="M-38 21Q-17 4 0 22Q17 4 38 21" fill="none" stroke="#ffffff" strokeOpacity=".48" strokeWidth="2.4" strokeLinecap="round"/>
    <path d="M-28-31Q-39-11-20 8M28-29Q37-9 20 8" fill="none" stroke={stone ? '#cdd1c7' : '#b18448'} strokeWidth="6.5" strokeLinecap="round"/>
    <g className="buddha-mudra" fill={bodyFill} stroke={bodyStroke} strokeWidth="1.5">
      <path d="M-25-3Q-13-10 0 2Q-7 12-22 8Q-29 5-25-3Z"/>
      <path d="M25-3Q13-10 0 2Q7 12 22 8Q29 5 25-3Z"/>
    </g>
    <path d="M-14 2Q0 10 14 2" fill="none" stroke={stone ? '#aeb5ad' : '#b88d55'} strokeWidth="1.5" strokeLinecap="round"/>

    <rect x="-8" y="-52" width="16" height="14" rx="7" fill={bodyFill}/>
    <ellipse cx="-21" cy="-74" rx="4.5" ry="11" fill={bodyFill} stroke={bodyStroke} strokeWidth="1.3"/>
    <ellipse cx="21" cy="-74" rx="4.5" ry="11" fill={bodyFill} stroke={bodyStroke} strokeWidth="1.3"/>
    <ellipse cx="0" cy="-75" rx="21" ry="25" fill={bodyFill} stroke={bodyStroke} strokeWidth="1.8"/>
    <path d="M-21-82Q-15-104 0-103Q16-103 21-82Q11-91 0-91Q-11-91-21-82Z" fill={stone ? '#d9dbd4' : '#9f7b48'}/>
    <circle cx="0" cy="-105" r="8" fill={stone ? '#d9dbd4' : '#ab8247'} stroke={bodyStroke} strokeWidth="1.6"/>
    <g fill="none" stroke={stone ? '#959c96' : '#88633b'} strokeLinecap="round">
      <path d="M-12-76Q-7-72-2-76M2-76Q7-72 12-76" strokeWidth="1.8"/>
      <path d="M0-72L-2-65Q0-63 3-65" strokeWidth="1.2"/>
      <path d="M-7-59Q0-54 7-59" strokeWidth="1.6"/>
    </g>
  </g>;
}

function FlowerVase({ x, y, scale = 1, mirrored = false }: { x: number; y: number; scale?: number; mirrored?: boolean }) {
  return <g transform={`translate(${x} ${y}) scale(${mirrored ? -scale : scale} ${scale})`} className="flower-vase">
    <g fill="none" stroke="#8ca996" strokeWidth="3.5" strokeLinecap="round">
      <path d="M0-24L-22-98M0-24L12-112M0-24L39-88M0-24L-41-73M0-24L-2-78"/>
    </g>
    <g fill="#8cb29c" stroke="#60816e" strokeWidth="1.2">
      <ellipse cx="-22" cy="-100" rx="12" ry="7" transform="rotate(-12 -22 -100)"/>
      <ellipse cx="13" cy="-112" rx="13" ry="7" transform="rotate(16 13 -112)"/>
      <ellipse cx="39" cy="-89" rx="13" ry="7" transform="rotate(26 39 -89)"/>
      <ellipse cx="-41" cy="-73" rx="13" ry="7" transform="rotate(-32 -41 -73)"/>
      <ellipse cx="-3" cy="-79" rx="11" ry="6" transform="rotate(-5 -3 -79)"/>
    </g>
    <g className="vase-flowers">
      <FlowerBloom x={-24} y={-104} scale={.88} color="#f2bac7"/>
      <FlowerBloom x={12} y={-121} scale={1.02} color="#f5ced6"/>
      <FlowerBloom x={42} y={-94} scale={.86} color="#ebb4c4"/>
      <FlowerBloom x={-45} y={-81} scale={.8} color="#f4d0da"/>
      <FlowerBloom x={-3} y={-83} scale={.7} color="#f7dde2"/>
    </g>
    <path d="M-29-40H29L23 9Q0 27-23 9Z" fill="url(#jadeSoft)" stroke="#9eb6a4" strokeWidth="3.5"/>
    <path d="M-25-25Q0-12 25-25M-23-7Q0 8 23-7" fill="none" stroke="#6d907c" strokeWidth="2.4" opacity=".72"/>
    <path d="M-20 8Q0 18 20 8" fill="none" stroke="#f5f4ea" strokeWidth="1.8" opacity=".75"/>
  </g>;
}

function FlowerBloom({ x, y, scale, color }: { x: number; y: number; scale: number; color: string }) {
  return <g transform={`translate(${x} ${y}) scale(${scale})`}>
    <ellipse cx="0" cy="-7" rx="7" ry="12" fill={color} stroke="#cf9eae" strokeWidth="1.2"/>
    <ellipse cx="8" cy="-2" rx="7" ry="12" transform="rotate(58 8 -2)" fill={color} stroke="#cf9eae" strokeWidth="1.2"/>
    <ellipse cx="5" cy="7" rx="7" ry="12" transform="rotate(122 5 7)" fill={color} stroke="#cf9eae" strokeWidth="1.2"/>
    <ellipse cx="-5" cy="7" rx="7" ry="12" transform="rotate(-122 -5 7)" fill={color} stroke="#cf9eae" strokeWidth="1.2"/>
    <ellipse cx="-8" cy="-2" rx="7" ry="12" transform="rotate(-58 -8 -2)" fill={color} stroke="#cf9eae" strokeWidth="1.2"/>
    <circle r="5" fill="#fff1b7" stroke="#cba56a" strokeWidth="1"/>
  </g>;
}

function LotusPad({ x, y, scale = 1 }: { x: number; y: number; scale?: number }) {
  return <g transform={`translate(${x} ${y}) scale(${scale})`}>
    <ellipse cx="0" cy="0" rx="28" ry="18" fill="#a0bea4"/>
    <path d="M0-1L13-5" fill="none" stroke="#7fa081" strokeWidth="2" strokeLinecap="round"/>
  </g>;
}

function LotusBloom({ x, y, scale = 1 }: { x: number; y: number; scale?: number }) {
  return <g transform={`translate(${x} ${y}) scale(${scale})`}>
    <path d="M0 0C-8-8 -7-19 0-29C7-19 8-8 0 0Z" fill="#f4d9df" stroke="#d1a8b0" strokeWidth="1.3"/>
    <path d="M-1 1C-14 0 -21-9 -23-22C-11-18 -4-10 -1 1Z" fill="#f7e5e7" stroke="#d8b2b8" strokeWidth="1.3"/>
    <path d="M1 1C14 0 21-9 23-22C11-18 4-10 1 1Z" fill="#f7e5e7" stroke="#d8b2b8" strokeWidth="1.3"/>
    <circle r="3.6" fill="#f5edb1"/>
  </g>;
}

function StoneLantern({ x, y }: { x: number; y: number }) {
  return <g transform={`translate(${x} ${y})`} className="altar-lamp">
    <ellipse rx="22" ry="24" fill="#fff6da" opacity=".16"/>
    <path d="M-10-8H10L14 2V16H-14V2Z" fill="url(#stoneDeep)" stroke="#aab2a8" strokeWidth="2"/>
    <path d="M-7 0H7V12H-7Z" fill="url(#lampGlow)" opacity=".88"/>
    <path d="M0 16V23" stroke="#97a49a" strokeWidth="3"/>
    <ellipse cx="0" cy="25" rx="13" ry="3.5" fill="#98a497"/>
  </g>;
}

function LotusLantern({ x, y }: { x: number; y: number }) {
  return <g transform={`translate(${x} ${y})`} className="altar-lamp">
    <ellipse rx="28" ry="16" fill="#f1eee0" opacity=".14"/>
    <path d="M-24 6Q-16 -10 -4 2Q0 -14 8 2Q18 -10 24 6Q16 20 0 18Q-16 20 -24 6Z" fill="#f4ddb0" stroke="#d6b77f" strokeWidth="2"/>
    <path d="M0 -2C-4 2 -4 8 0 12C4 8 4 2 0 -2Z" fill="#fff3cc"/>
  </g>;
}

function OfferingPlate({ offering, x, y, scale = 1 }: { offering: FruitOffering; x: number; y: number; scale?: number }) {
  const fruit = offering === 'citrus'
    ? [{ x: -26, y: -18, c: '#f2b057' }, { x: 0, y: -24, c: '#efc36f' }, { x: 27, y: -17, c: '#eaa153' }, { x: -8, y: -43, c: '#f5bc65' }]
    : offering === 'apples'
      ? [{ x: -26, y: -18, c: '#d67774' }, { x: 0, y: -23, c: '#dc8884' }, { x: 27, y: -17, c: '#c86567' }, { x: 2, y: -44, c: '#e09b95' }]
      : [{ x: -31, y: -17, c: '#cba763' }, { x: -7, y: -27, c: '#d97d78' }, { x: 20, y: -18, c: '#8eb071' }, { x: 3, y: -48, c: '#ead189' }, { x: 37, y: -34, c: '#c5a3c7' }];
  return <g transform={`translate(${x} ${y}) scale(${scale})`} className="offering-plate">
    <ellipse cx="0" cy="3" rx="58" ry="12" fill="#5a4d3d" opacity=".24"/>
    <path d="M-55-4Q0 22 55-4L47 10Q0 33-47 10Z" fill="#efe5c7" stroke="#c5b182" strokeWidth="3.2"/>
    {fruit.map((item, index) => <g key={index}><circle cx={item.x} cy={item.y} r="18" fill={item.c} stroke="#9b8864" strokeWidth="1.7"/><path d={`M${item.x} ${item.y - 17}q8-11 16-5`} fill="none" stroke="#6e9b6d" strokeWidth="2.6" strokeLinecap="round"/></g>)}
  </g>;
}

function IncensePlatform() {
  return <g>
    <ellipse cx="480" cy="545" rx="128" ry="28" fill="#5c695f" opacity=".16"/>
    <circle cx="480" cy="536" r="86" fill="none" stroke="#d8d5bf" strokeWidth="10" opacity=".56"/>
    <circle cx="480" cy="536" r="66" fill="none" stroke="#c1c6b8" strokeWidth="2.4" opacity=".56"/>
  </g>;
}

function IncenseBowl({ sticks, x, y, scale = 1, smoke, lit, onClick }: {
  sticks: 0 | 1 | 3;
  x: number;
  y: number;
  scale?: number;
  smoke?: boolean;
  lit?: boolean;
  onClick?: () => void;
}) {
  const positions = sticks === 3 ? [-14, 0, 14] : sticks === 1 ? [0] : [];
  return <g
    transform={`translate(${x} ${y}) scale(${scale})`}
    className={`incense-object interactive ${lit ? 'just-lit' : ''}`}
    role={onClick ? 'button' : undefined}
    tabIndex={onClick ? 0 : undefined}
    onClick={onClick}
    onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()}
    aria-label={onClick ? 'Thắp nhang' : undefined}
    aria-hidden={onClick ? undefined : true}
  >
    <ellipse cx="0" cy="18" rx="72" ry="15" fill="#314038" opacity=".22"/>
    <path d="M-58-7Q0-29 58-7L48 39Q0 59-48 39Z" fill="url(#jade)" stroke="#d6c996" strokeWidth="4"/>
    <ellipse cx="0" cy="-8" rx="58" ry="16" fill="#476e63"/>
    <ellipse cx="0" cy="-9" rx="45" ry="10" fill="#d1cec1" opacity=".88"/>
    <path d="M-10 20Q0 12 10 20" fill="none" stroke="#eadfbc" strokeWidth="3" opacity=".75"/>
    {positions.map((offset) => <g key={offset} style={{ '--offset': offset } as CSSProperties}>
      <path d={`M${offset} -10V-105`} stroke="#9c4c42" strokeWidth="4"/>
      <circle cx={offset} cy="-107" r="4" fill="#ffc981"/>
      <circle className="ember" cx={offset} cy="-107" r="10" fill="#f8aa6c" opacity=".34" filter="url(#emberGlow)"/>
      {smoke && <path className={`smoke smoke-${offset + 14}`} d={`M${offset} -113C${offset - 20} -133 ${offset + 17} -148 ${offset} -169S${offset - 15} -199 ${offset + 8} -222`} fill="none" stroke="#fbfaf2" strokeWidth="5" strokeLinecap="round" opacity=".58"/>}
    </g>)}
  </g>;
}

function RitualHands({ animation, incenseSticks, offering }: { animation: RitualAnimation; incenseSticks: 1 | 3; offering: FruitOffering }) {
  if (!animation) return null;
  if (animation === 'incense') {
    const positions = incenseSticks === 3 ? [-13, 0, 13] : [0];
    return <g className="ritual-hands ritual-hands-incense" aria-hidden="true">
      <g className="ritual-incense-arm ritual-incense-arm-left">
        <path className="ritual-sleeve sleeve-left" d="M282 650Q325 548 407 475L449 519Q376 584 355 650Z" fill="#7b9b8c"/>
        <path className="ritual-palm ritual-palm-left" d="M401 486Q423 446 452 427Q465 424 472 438L468 479Q451 503 428 515Z" fill="url(#skin)" stroke="#b98a74" strokeWidth="3"/>
      </g>
      <g className="ritual-incense-arm ritual-incense-arm-right">
        <path className="ritual-sleeve sleeve-right" d="M678 650Q635 548 553 475L511 519Q584 584 605 650Z" fill="#7b9b8c"/>
        <path className="ritual-palm ritual-palm-right" d="M559 486Q537 446 508 427Q495 424 488 438L492 479Q509 503 532 515Z" fill="url(#skin)" stroke="#b98a74" strokeWidth="3"/>
      </g>
      <path className="ritual-prayer-touch" d="M468 478Q480 487 492 478" fill="none" stroke="#b48777" strokeWidth="3" strokeLinecap="round"/>
      <g className="ritual-held-incense">
        {positions.map((offset) => <g key={offset}><path d={`M${480 + offset} 465V337`} stroke="#a45448" strokeWidth="4"/><circle cx={480 + offset} cy="334" r="5" fill="#f8cb8a"/><circle cx={480 + offset} cy="334" r="13" fill="#efb46a" opacity=".24" filter="url(#emberGlow)"/></g>)}
      </g>
    </g>;
  }

  return <g className="ritual-hands ritual-hands-offering" aria-hidden="true">
    <g className="ritual-offering-arm ritual-offering-arm-left">
      <path className="ritual-sleeve sleeve-left" d="M218 650Q286 563 385 490L438 518Q360 583 327 650Z" fill="#7b9b8c"/>
      <path className="ritual-palm ritual-palm-left" d="M369 493Q398 466 439 468L476 486Q444 508 397 516Q376 512 369 493Z" fill="url(#skin)" stroke="#b98a74" strokeWidth="3"/>
    </g>
    <g className="ritual-offering-arm ritual-offering-arm-right">
      <path className="ritual-sleeve sleeve-right" d="M742 650Q674 563 575 490L522 518Q600 583 633 650Z" fill="#7b9b8c"/>
      <path className="ritual-palm ritual-palm-right" d="M591 493Q562 466 521 468L484 486Q516 508 563 516Q584 512 591 493Z" fill="url(#skin)" stroke="#b98a74" strokeWidth="3"/>
    </g>
    <g className="ritual-offering-tray">
      <ellipse cx="480" cy="468" rx="82" ry="14" fill="#56655c" opacity=".26"/>
      <path d="M397 457Q480 484 563 457L553 474Q480 499 407 474Z" fill="url(#altarWoodLight)" stroke="#d0c090" strokeWidth="3"/>
      <OfferingPlate offering={offering} x={480} y={450} scale={1.02}/>
    </g>
  </g>;
}

function Bell({ ringing, onClick }: { ringing?: boolean; onClick?: () => void }) {
  return <g className={`bell-object interactive ${ringing ? 'ringing' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Rung chuông">
    <ellipse cx="146" cy="552" rx="76" ry="14" fill="#51635a" opacity=".18"/>
    <path d="M96 548V414Q146 382 196 414V548" fill="none" stroke="#6d7f73" strokeWidth="14"/>
    <path d="M112 488Q117 433 146 424Q175 433 180 488L196 526Q146 544 96 526Z" fill="url(#bronze)" stroke="#d7c088" strokeWidth="3.5"/>
    <ellipse cx="146" cy="526" rx="50" ry="12" fill="#7f7359"/><circle cx="146" cy="531" r="8" fill="#efe4bc"/>
    <g className="bell-waves" fill="none" stroke="#e9dfb5" strokeWidth="3"><circle cx="146" cy="486" r="64"/><circle cx="146" cy="486" r="82"/></g>
  </g>;
}

function Woodblock({ hit, onClick }: { hit?: boolean; onClick?: () => void }) {
  return <g className={`woodblock-object interactive ${hit ? 'hit' : ''}`} onClick={onClick} role="button" tabIndex={0} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Gõ mõ">
    <ellipse cx="816" cy="558" rx="78" ry="14" fill="#51635a" opacity=".18"/>
    <path d="M782 534Q754 503 782 468Q818 444 854 470Q877 504 850 536Q816 553 782 534Z" fill="url(#altarWoodLight)" stroke="#c7b281" strokeWidth="4"/>
    <path d="M798 470Q820 491 844 477" fill="none" stroke="#524235" strokeWidth="6" strokeLinecap="round"/><circle cx="773" cy="504" r="7" fill="#3b3028"/>
    <g className="striker"><path d="M858 451L803 511" stroke="#9ca88f" strokeWidth="8" strokeLinecap="round"/><circle cx="866" cy="443" r="12" fill="#dbcaa2"/></g>
  </g>;
}

function MeditationMat({ onClick }: { onClick?: () => void }) {
  return <g className="meditation-mat interactive" role="button" tabIndex={0} onClick={onClick} onKeyDown={(event) => (event.key === 'Enter' || event.key === ' ') && onClick?.()} aria-label="Tĩnh tâm">
    <ellipse cx="688" cy="568" rx="64" ry="14" fill="#51635a" opacity=".16"/>
    <path d="M631 548Q688 530 745 548L735 574Q688 590 641 574Z" fill="url(#jade)" stroke="#d2cfb5" strokeWidth="4"/>
    <path d="M659 553Q688 544 717 553" fill="none" stroke="#f2f1e4" strokeWidth="3" opacity=".8"/>
  </g>;
}
