# Chùa An Nhiên

Ứng dụng desktop Windows nhỏ, thanh tịnh và hoạt động ngoại tuyến. Cổng chùa mini nằm ở góc màn hình; khi mở rộng, người dùng có thể thắp nhang, gõ mõ, rung chuông và tĩnh tâm trong 1, 3 hoặc 5 phút.

## Tính năng đã triển khai

- Cửa sổ mini 260 × 190 px, trong suốt, không viền, bo góc, luôn nổi và tự đặt trong `workArea` để không bị taskbar che.
- Cửa sổ toàn cảnh 960 × 650 px, căn giữa đúng màn hình hiện tại.
- Hỗ trợ nhiều màn hình, taskbar ở mọi cạnh và tự đưa cửa sổ về vùng hiển thị khi màn hình cũ bị tháo.
- Ghi nhớ vị trí cửa sổ mini.
- Một cửa sổ duy nhất; mở lại ứng dụng sẽ đưa cửa sổ đang chạy lên trước.
- Nút đóng chuyển ứng dụng về System Tray; chỉ mục “Thoát hoàn toàn” mới kết thúc tiến trình.
- System Tray: mở toàn cảnh, mở mini, bật/tắt âm thanh, luôn nổi, autostart, cài đặt và thoát.
- Cảnh chùa SVG/CSS tự tạo, không dùng ảnh/CDN hoặc tài nguyên mạng.
- Âm thanh mõ, chuông, nhang và gió được tổng hợp bằng Web Audio API; không có autoplay khi cài mới.
- 32 câu nhắc tích cực bằng tiếng Việt.
- Điểm tích phước hôm nay, tổng điểm, chuỗi ngày, số lần gõ mõ/thắp nhang, thời gian tĩnh tâm và lịch sử 30 ngày.
- Lưu JSON cục bộ bằng Tauri Store. Không telemetry, không máy chủ, không mở cổng mạng.
- CSP chặt và danh sách quyền Tauri tối thiểu theo từng API được sử dụng.
- Tôn trọng `prefers-reduced-motion`, dừng animation khi cửa sổ bị ẩn và giảm hoạt động tự động khi tab không hiển thị.

## Cấu trúc

```text
.
├── src/
│   ├── components/          # Cảnh SVG, cài đặt, thống kê, tĩnh tâm
│   ├── lib/                 # Âm thanh, lưu trữ, native bridge, điểm
│   ├── test/                # Unit test
│   ├── App.tsx
│   └── styles.css
├── src-tauri/
│   ├── capabilities/        # Quyền native được phép
│   ├── icons/               # Icon tự tạo
│   ├── src/                 # Tray, single-instance, close-to-tray
│   ├── Cargo.toml
│   └── tauri.conf.json
├── scripts/build-windows.ps1
├── config.example.json
└── ASSETS_LICENSE.md
```

## Cài môi trường trên Windows 10/11

1. Cài [Node.js LTS](https://nodejs.org/) (khuyến nghị 22 trở lên).
2. Cài Rust stable bằng `rustup` theo hướng dẫn chính thức của Tauri.
3. Cài Visual Studio 2022 Build Tools, chọn workload **Desktop development with C++** và Windows 10/11 SDK.
4. Mở PowerShell trong thư mục dự án:

```powershell
npm install
npm run tauri dev
```

Ứng dụng đóng gói WebView2 offline trong installer, vì vậy file cài đặt lớn hơn cấu hình tải WebView2 qua mạng nhưng có thể cài khi không có Internet.

## Build Windows

Build tiêu chuẩn:

```powershell
npm install
npm test
npm run tauri build
```

Đường dẫn output mặc định:

- Portable: `src-tauri\target\release\chua-an-nhien.exe`
- NSIS: `src-tauri\target\release\bundle\nsis\*.exe`
- MSI: `src-tauri\target\release\bundle\msi\*.msi`

Để build và sao chép sang tên bàn giao thống nhất:

```powershell
npm run release:windows
```

Kết quả trong `release\`:

- `ChuaAnNhien_Setup_x64.exe`
- `ChuaAnNhien_x64.msi`
- `ChuaAnNhien_Portable_x64.exe`

MSI phụ thuộc WiX/Tauri bundler trên Windows. Nếu máy build không hỗ trợ MSI, NSIS và portable vẫn là hai phương án phân phối chính.

> Windows SmartScreen có thể cảnh báo với file `.exe` chưa được ký số. Đây là hành vi bình thường đối với ứng dụng mới chưa có uy tín chữ ký. Dự án không tự mua hoặc yêu cầu chứng thư ký số.

## Dữ liệu cục bộ

Trên Windows, Tauri Store lưu `an-nhien.json` dưới thư mục AppData của định danh `vn.chuaannhien.desktop`. Vị trí cửa sổ mini nằm trong kho WebView cục bộ. Xóa/đặt lại dữ liệu chỉ thực hiện sau khi người dùng xác nhận trong Cài đặt.

Các trường chính:

- `todayPoints`, `totalPoints`
- `totalWoodblockHits`, `totalIncenseCount`
- `totalMeditationSeconds`, `streakDays`, `lastActiveDate`
- `history` tối đa 30 ngày
- `completedMeditations` chống cộng lại điểm khi lặp cùng mốc thời gian trong ngày

## Chỉnh giao diện, asset và tên ứng dụng

- Cảnh chùa: sửa `src/components/TempleArtwork.tsx` và `src/styles.css`.
- Icon nguồn: `src-tauri/icons/app-icon.svg`; tạo lại bộ icon bằng `npm run tauri icon src-tauri/icons/app-icon.svg` trên máy đã đủ Tauri prerequisites.
- Âm thanh: sửa bộ tổng hợp trong `src/lib/audio.ts`. Nếu thay bằng file âm thanh, đặt file trong `public/audio/`, cập nhật `ASSETS_LICENSE.md`, và không tham chiếu URL mạng.
- Tên hiển thị: sửa `productName`, `title` trong `src-tauri/tauri.conf.json`, tên ở `src/App.tsx`, tên package trong `src-tauri/Cargo.toml` và script build nếu đổi tên executable.
- Màu sắc và tốc độ animation: các biến đầu file `src/styles.css`.

## Chỉnh logic Điểm tích phước

Logic tổng hợp nằm trong `src/lib/stats.ts`; quy tắc trao Điểm tích phước theo thao tác nằm trong `src/App.tsx`. Đây chỉ là điểm ghi nhận hoạt động trong ứng dụng, không phải khẳng định về công đức hay giá trị tâm linh thực tế:

- Thắp nhang lần đầu trong ngày: 10 điểm.
- Gõ mõ thủ công: 1 điểm/lần, cooldown 300 ms.
- Gõ mõ tự động: không cộng điểm.
- Tĩnh tâm: 1 phút = 5, 3 phút = 12, 5 phút = 20 điểm; mỗi mốc chỉ được thưởng một lần/ngày.
- Rung chuông: không cộng điểm.

Sau khi chỉnh, chạy:

```powershell
npm test
npm run build
```

## Kiểm thử thủ công trên Windows

1. Mở app, xác nhận mini nằm cách góc `workArea` 16 px và không bị taskbar che.
2. Kéo mini sang màn hình khác, đóng/mở lại và kiểm tra vị trí được nhớ.
3. Click cổng, kiểm tra animation rồi cửa sổ 960 × 650 được căn giữa.
4. Thắp 1/3 nén, kiểm tra đầu nhang, khói, âm báo và chỉ lần đầu/ngày được +10.
5. Click mõ và nhấn Space; kiểm tra cooldown và +1. Bật tự động, xác nhận không cộng điểm.
6. Click chuông liên tục; xác nhận âm không chồng quá mức.
7. Hoàn thành timer 1/3/5 phút; kiểm tra chuông đầu/cuối, điểm và lưu thời gian.
8. Tắt âm hoàn toàn; thử mọi thao tác.
9. Nhấn Esc để về mini. Nhấn nút X của Windows/Alt+F4, xác nhận app còn trong Tray.
10. Mở executable lần hai, xác nhận không sinh tiến trình/cửa sổ thứ hai.
11. Tắt mạng rồi chạy toàn bộ thao tác; kiểm tra không có request ngoài.

## Bảo mật và riêng tư

- Không khai báo plugin HTTP, shell, filesystem tổng quát, updater hoặc analytics.
- Frontend không thể chạy lệnh hệ thống tùy ý.
- Chỉ `self`, Tauri IPC, `data:` và `blob:` cần thiết được cho phép bởi CSP.
- Không lưu thông tin nhạy cảm và không yêu cầu Administrator; NSIS cài theo `currentUser`.

## Giấy phép

Mã nguồn dùng giấy phép MIT. Asset và cách tạo được ghi tại [ASSETS_LICENSE.md](ASSETS_LICENSE.md).
